"""The control bot (BOT_TOKEN): the ONLY door into the multi-account system.

* OWNER (HAPOYI_OWNER_ID, or the main account from .env): creates licenses (buttons, or just TYPE a duration
  like `30s`, `12h`, `3d`, `1m` [+ name]), sees them, switches them off / on, deletes them (which also logs
  the account out), and can log ANY account in himself with phone / code / 2FA - no license code needed.
* EVERYBODY ELSE: the bot asks for a license first. A valid license binds to that Telegram user, and
  only then can they log in - and only into THE SAME account they are chatting from. No license, no
  login; a stranger can never put an account on your server.
* A licensed user can switch their own userbot off/on, or log out completely, from the bot.

The logic lives in ControlBot (no Telethon types in the decision code) so it is unit-testable; the
Telethon glue is at the bottom.
"""
from __future__ import annotations

import html
import logging
import re
import time
from typing import Any, Awaitable, Callable
from zoneinfo import ZoneInfo

from telethon import Button, TelegramClient, events
from telethon.errors import MessageNotModifiedError, RPCError

from core import licenses
from core.fleet import MAIN_ID, Fleet
from core.login_flow import LoginSession

log = logging.getLogger(__name__)

STATE_TTL = 600.0
Reply = Callable[..., Awaitable[Any]]


def _b(text: str, data: str) -> Button:
    return Button.inline(text, data.encode())


class ControlBot:
    def __init__(self, fleet: Fleet, *, tz: str = "Asia/Tehran"):
        self.fleet = fleet
        self.db = fleet.db
        self.tz = ZoneInfo(tz)
        self.state: dict[int, dict] = {}
        self.throttle = licenses.Throttle()

    # ------------------------------------------------------------------ helpers
    def is_owner(self, uid: int | None) -> bool:
        return bool(uid) and int(uid) == self.fleet.owner_id

    def fmt(self, ts: float | None) -> str:
        if not ts:
            return "—"
        from datetime import datetime
        return datetime.fromtimestamp(ts, self.tz).strftime("%Y-%m-%d %H:%M")

    async def _drop_state(self, uid: int) -> None:
        st = self.state.pop(uid, None)
        client = st.get("client") if st else None
        if client is not None:
            try:
                await client.disconnect()
            except Exception:  # noqa: BLE001
                pass

    async def _gc(self) -> None:
        now = time.time()
        for uid in [u for u, s in self.state.items() if now - s["ts"] > STATE_TTL]:
            await self._drop_state(uid)

    async def _set_state(self, uid: int, **kw: Any) -> None:
        old = self.state.get(uid)
        if old and old.get("client") is not None and old.get("client") is not kw.get("client"):
            await self._drop_state(uid)
        self.state[uid] = {"ts": time.time(), **kw}

    # ------------------------------------------------------------------ owner screens
    async def home_owner(self) -> tuple[str, list]:
        rows = await licenses.list_licenses(self.db)
        now = time.time()
        active = sum(1 for r in rows if licenses.state(r, now) == licenses.ACTIVE)
        text = (
            "👑 <b>پنل مالک</b>\n\n"
            f"اکانت‌های در حال اجرا: <b>{len(self.fleet.runtimes)}</b> (بدون محدودیت تعداد)\n"
            f"لایسنس‌ها: {len(rows)} (فعال: {active})\n\n"
            "⚡️ برای ساخت سریع لایسنس فقط مدت را بفرست: <code>30s</code> ثانیه · <code>5min</code> دقیقه · "
            "<code>12h</code> ساعت · <code>3d</code> روز · <code>1m</code> ماه (می‌توانی بعدش اسم هم بنویسی: <code>3d اکانت دوم</code>)"
        )
        return text, [
            [_b("🎫 ساخت لایسنس", "fl:new"), _b("📋 لایسنس‌ها", "fl:list")],
            [_b("➕ افزودن سلف به اکانت (بدون لایسنس)", "fl:add")],
            [_b("🖥 اکانت‌های در حال اجرا", "fl:run")],
        ]

    async def license_detail(self, lid: int) -> tuple[str, list]:
        row = await licenses.get_license(self.db, lid)
        if row is None:
            return "❌ این لایسنس دیگر وجود ندارد.", [[_b("⬅️ برگشت", "fl:list")]]
        now = time.time()
        st = licenses.state(row, now)
        acc = await self.fleet.account_for_license(lid)
        if acc is None:
            account = "—"
        else:
            account = ("🟢 در حال اجرا" if self.fleet.is_running(acc["id"]) else "⚪️ خاموش") + f" · {html.escape(acc['label'] or '')} ({acc['phone_masked'] or '—'})"
        lines = [
            f"🎫 <b>لایسنس #{lid}</b> — {html.escape(row['label'] or '—')}",
            f"وضعیت: {licenses.STATE_ICON[st]} {licenses.STATE_NAME[st]}",
            f"مدت: {licenses.format_duration(row['duration_s'])}",
            f"کد: <code>…{row['code_hint']}</code>",
            f"صاحب (Telegram ID): <code>{row['bound_user_id'] or '—'}</code>",
            f"اکانت: {account}",
            f"ساخته‌شده: {self.fmt(row['created_at'])}",
        ]
        if row["activated_at"]:
            lines += [f"شروع: {self.fmt(row['activated_at'])}", f"پایان: {self.fmt(row['expires_at'])}"]
            if st in (licenses.ACTIVE, licenses.SUSPENDED):
                lines.append(f"مانده: {licenses.format_duration(row['expires_at'] - now)}")
        else:
            lines.append(f"استفاده‌نشده تا: {self.fmt(row['redeem_by'])}")
        buttons = []
        if st == licenses.ACTIVE:
            buttons.append([_b("⏸ خاموش‌کردن لایسنس", f"fl:susp:{lid}")])
        elif st == licenses.SUSPENDED:
            buttons.append([_b("▶️ روشن‌کردن لایسنس", f"fl:unsusp:{lid}")])
        buttons.append([_b("🗑 حذف لایسنس", f"fl:delask:{lid}")])
        buttons.append([_b("⬅️ برگشت", "fl:list")])
        return "\n".join(lines), buttons

    # ------------------------------------------------------------------ licensed-user screens
    async def home_user(self, uid: int) -> tuple[str, list] | None:
        """None when this person has no usable license (the bot then asks for one)."""
        lic = await licenses.license_for_user(self.db, uid)
        if lic is None:
            return None
        now = time.time()
        st = licenses.state(lic, now)
        if st == licenses.EXPIRED:
            return None
        acc = await self.fleet.account_for_user(uid)
        running = acc is not None and self.fleet.is_running(acc["id"])
        lines = ["🔐 <b>سلف شما</b>", ""]
        lines.append(f"لایسنس: {licenses.STATE_ICON[st]} {licenses.STATE_NAME[st]} — {licenses.format_duration(lic['expires_at'] - now)} مانده (تا {self.fmt(lic['expires_at'])})")
        buttons: list[list] = []
        if acc is None or not acc["session_enc"]:
            lines.append("اکانت: هنوز وارد نشده‌ای.")
            if acc is not None and acc["note"]:
                lines.append(f"ℹ️ {html.escape(acc['note'])}")
            if st == licenses.ACTIVE:
                buttons.append([_b("🔑 ورود به اکانت", "fl:me:login")])
        else:
            lines.append(f"اکانت: {'🟢 فعال' if running else '⚪️ غیرفعال'} · {html.escape(acc['label'] or '')} ({acc['phone_masked'] or '—'})")
            if st == licenses.SUSPENDED:
                lines.append("⏸ لایسنس توسط مالک خاموش شده؛ تا روشن‌شدن مجدد نمی‌توانی فعالش کنی.")
            elif running:
                buttons.append([_b("⏸ غیرفعال‌کردن", "fl:me:off")])
            else:
                buttons.append([_b("▶️ فعال‌کردن", "fl:me:on")])
            buttons.append([_b("🚪 خروج کامل (Logout)", "fl:me:logoutask")])
        buttons.append([_b("🔄 به‌روزرسانی", "fl:me:refresh")])
        return "\n".join(lines), buttons

    # ------------------------------------------------------------------ text entry point
    async def handle_text(self, uid: int, text: str, reply: Reply, delete: Callable[[], Awaitable[Any]] | None = None) -> None:
        await self._gc()
        text = (text or "").strip()
        low = text.lower()
        if low.startswith("/cancel"):
            await self._drop_state(uid)
            return await reply("لغو شد. /start")
        if low.startswith(("/start", "/panel")):
            await self._drop_state(uid)
            return await self.show_home(uid, reply)
        st = self.state.get(uid)
        if st is not None:
            return await self._step(uid, st, text, reply, delete)
        if self.is_owner(uid):
            quick = licenses.parse_quick(text)
            if quick is not None:  # owner typed "3d" / "30s" / "12h اسم" -> license right away
                return await self._create(uid, quick[0], quick[1], reply)
            return await self.show_home(uid, reply)
        home = await self.home_user(uid)
        if home is not None:
            return await reply(home[0], buttons=home[1])
        return await self.license_attempt(uid, text, reply)

    async def show_home(self, uid: int, reply: Reply) -> None:
        if self.is_owner(uid):
            text, buttons = await self.home_owner()
            return await reply(text, buttons=buttons)
        home = await self.home_user(uid)
        if home is not None:
            return await reply(home[0], buttons=home[1])
        await self._set_state(uid, step="license")
        await reply("🔐 برای استفاده باید <b>لایسنس</b> داشته باشی.\nلایسنس را بفرست (مثال: <code>HPY-XXXX-XXXX-XXXX</code>):")

    async def license_attempt(self, uid: int, text: str, reply: Reply) -> None:
        wait = self.throttle.blocked_for(uid)
        if wait:
            return await reply(f"⏳ تلاش‌های اشتباه زیاد بود؛ {wait} ثانیه بعد دوباره امتحان کن.")
        res = await licenses.redeem(self.db, text, uid)
        if res.ok:
            self.throttle.success(uid)
            await self._drop_state(uid)
            lic = res.row
            home = await self.home_user(uid)
            head = (f"✅ لایسنس تأیید شد. اعتبار: <b>{licenses.format_duration(lic['expires_at'] - time.time())}</b>.\n\n"
                    if res.first_time else "✅ لایسنس شما فعال است.\n\n")
            return await reply(head + home[0], buttons=home[1])
        if res.reason == "expired":
            self.throttle.fail(uid)
            return await reply("⌛️ این لایسنس منقضی شده است.")
        if res.reason == "suspended":
            return await reply("⏸ این لایسنس توسط مالک خاموش شده است.")
        self.throttle.fail(uid)
        await self._set_state(uid, step="license")
        await reply("⛔ لایسنس نامعتبر است.")

    # ------------------------------------------------------------------ multi-step conversations
    async def _step(self, uid: int, st: dict, text: str, reply: Reply, delete: Callable[[], Awaitable[Any]] | None) -> None:
        step = st["step"]
        if step == "license":
            return await self.license_attempt(uid, text, reply)
        if step == "new_duration" and self.is_owner(uid):
            seconds = licenses.parse_duration(text)
            if seconds is None:
                return await reply("❌ مدت نامعتبر. مثال: <code>30s</code> (ثانیه)، <code>5min</code> (دقیقه)، <code>12h</code> (ساعت)، <code>3d</code> (روز)، <code>1m</code> (ماه).")
            await self._set_state(uid, step="new_label", duration=seconds)
            return await reply(f"مدت: <b>{licenses.format_duration(seconds)}</b>\nیک اسم برای این لایسنس بفرست (مثلاً «اکانت دوم») یا رد کن:",
                               buttons=[[_b("رد کردن", "fl:newskip")]])
        if step == "new_label" and self.is_owner(uid):
            return await self._create(uid, st["duration"], text[:40], reply)
        if step == "phone":
            digits = re.sub(r"\D", "", text)
            if not 8 <= len(digits) <= 15:
                return await reply("❌ شماره نامعتبر؛ با کد کشور بفرست (مثال: 98912xxxxxxx). /cancel")
            owner_add = bool(st.get("owner_add")) and self.is_owner(uid)
            if not owner_add and not await self._login_allowed(uid):
                await self._drop_state(uid)
                return await reply("❌ لایسنس فعالی نداری.")
            client = await self.fleet.client_factory("")
            session = LoginSession(client, "+" + digits)
            err = await session.send_code()
            if err:
                await client.disconnect()
                await self._drop_state(uid)
                return await reply(f"❌ {err}")
            await self._set_state(uid, step="code", client=client, session=session, owner_add=owner_add)
            return await reply("🔑 کدی که تلگرام فرستاد را <b>با فاصله بین ارقام</b> بفرست، مثل <code>1 2 3 4 5</code>\n"
                               "(اگر یکجا بفرستی تلگرام ممکن است کد را باطل کند.) /cancel")
        if step in {"code", "password"}:
            if delete is not None:
                try:
                    await delete()  # never leave a login code / password lying in the chat
                except Exception:  # noqa: BLE001
                    pass
            session: LoginSession = st["session"]
            if step == "code":
                code = re.sub(r"\D", "", text)
                if not code:
                    return await reply("❌ فقط رقم‌های کد را بفرست.")
                result = await session.submit_code(code)
                if result.needs_password:
                    await self._set_state(uid, step="password", client=st["client"], session=session, owner_add=bool(st.get("owner_add")))
                    return await reply("🔐 رمز دومرحله‌ای (2FA) را بفرست:")
            else:
                result = await session.submit_password(text)
            if not result.ok:
                await self._drop_state(uid)
                return await reply(f"❌ {result.error}\nاز اول شروع کن: /start")
            return await self._finish_login(uid, st, result, reply)

    async def _login_allowed(self, uid: int) -> bool:
        lic = await licenses.license_for_user(self.db, uid)
        return lic is not None and licenses.state(lic) == licenses.ACTIVE

    async def _finish_owner_login(self, uid: int, st: dict, result: Any, reply: Reply) -> None:
        """The owner logged ANY account in (his second account, a friend's, ...): no license code, no same-account rule."""
        client = st["client"]
        try:
            me = await client.get_me()
            main = self.fleet.runtimes.get(MAIN_ID)
            if main is not None and main.user_id is not None and int(main.user_id) == int(me.id):
                try:
                    await client.log_out()
                except Exception:  # noqa: BLE001
                    pass
                return await reply("⚠️ این همان اکانت اصلی است که همین الان اجراست؛ دوباره اضافه نمی‌شود (session تازه‌ساخته بسته شد).",
                                   buttons=[[_b("⬅️ پنل", "fl:home")]])
            label = getattr(me, "first_name", None) or getattr(me, "username", None) or str(me.id)
            account_id = await self.fleet.add_owner_account(int(me.id), label, result.session_string, result.phone)
        finally:
            await self._drop_state(uid)
        ok, msg = await self.fleet.start_account(account_id)
        if not ok:
            return await reply(f"⚠️ وارد شد ولی اجرا نشد: {html.escape(msg)}", buttons=[[_b("⬅️ پنل", "fl:home")]])
        await reply(f"✅ سلف روی اکانت <b>{html.escape(label)}</b> (<code>{me.id}</code>) فعال شد.\n"
                    "از «📋 لایسنس‌ها» می‌توانی خاموش/حذفش کنی.", buttons=[[_b("📋 لایسنس‌ها", "fl:list"), _b("⬅️ پنل", "fl:home")]])

    async def _finish_login(self, uid: int, st: dict, result: Any, reply: Reply) -> None:
        if st.get("owner_add") and self.is_owner(uid):
            return await self._finish_owner_login(uid, st, result, reply)
        client = st["client"]
        try:
            me = await client.get_me()
            if int(me.id) != int(uid):
                try:
                    await client.log_out()
                except Exception:  # noqa: BLE001
                    pass
                return await reply("⛔ فقط خودِ همین اکانت می‌تواند وارد شود (شماره‌ای که زدی مال حساب دیگری بود). session ساخته‌شده بسته شد.")
            label = getattr(me, "first_name", None) or getattr(me, "username", None) or str(uid)
            lic = await licenses.license_for_user(self.db, uid)
            account_id = await self.fleet.add_account(lic["id"], uid, label, result.session_string, result.phone)
        finally:
            await self._drop_state(uid)
        ok, msg = await self.fleet.start_account(account_id)
        if not ok:
            return await reply(f"⚠️ وارد شدی ولی اجرا نشد: {html.escape(msg)}")
        home = await self.home_user(uid)
        await reply("✅ سلف روی اکانتت فعال شد.\n\n" + home[0], buttons=home[1])

    async def _create(self, uid: int, seconds: int, label: str, reply: Reply) -> None:
        label = "" if label.strip() == "-" else label
        await self._drop_state(uid)
        lid, code = await licenses.create_license(self.db, seconds, label, self.fleet.unused_ttl_s)
        await reply(
            f"🎫 لایسنس <b>#{lid}</b> ساخته شد — مدت {licenses.format_duration(seconds)}\n\n"
            f"<code>{code}</code>\n\n"
            "این کد فقط همین یک بار نشان داده می‌شود. شمارش مدت از لحظهٔ واردکردنش شروع می‌شود؛ "
            f"اگر تا {licenses.format_duration(self.fleet.unused_ttl_s)} استفاده نشود باطل می‌شود.",
            buttons=[[_b("📋 لایسنس‌ها", "fl:list"), _b("⬅️ پنل", "fl:home")]])

    # ------------------------------------------------------------------ buttons
    async def handle_callback(self, uid: int, data: str, edit: Reply, answer: Callable[..., Awaitable[Any]]) -> None:
        await self._gc()
        parts = data.split(":")
        action = parts[1] if len(parts) > 1 else ""
        arg = parts[2] if len(parts) > 2 else ""
        if action == "me":
            return await self._user_callback(uid, arg, edit, answer)
        if not self.is_owner(uid):
            return await answer("⛔ مجاز نیستی.", alert=True)
        if action == "home":
            text, buttons = await self.home_owner()
            return await edit(text, buttons=buttons)
        if action == "new":
            await self._set_state(uid, step="new_duration")
            return await edit("🎫 <b>ساخت لایسنس</b>\nمدت را انتخاب کن یا بفرست (مثال <code>30s</code>، <code>5min</code>، <code>12h</code>، <code>3d</code>، <code>1m</code>):",
                              buttons=[[_b("۱ ساعت", "fl:newd:1h"), _b("۱ روز", "fl:newd:1d")],
                                       [_b("۷ روز", "fl:newd:7d"), _b("۱ ماه", "fl:newd:1m")],
                                       [_b("⬅️ برگشت", "fl:home")]])
        if action == "add":
            await self._set_state(uid, step="phone", owner_add=True)
            return await edit("➕ <b>افزودن سلف به اکانت</b>\nشمارهٔ اکانتی که می‌خواهی سلف رویش فعال شود را با کد کشور بفرست (مثال: 98912xxxxxxx).\n"
                              "کد ورود در همان اکانت تلگرام می‌آید؛ آن را <b>با فاصله بین ارقام</b> اینجا بفرست. بدون نیاز به کد لایسنس. /cancel",
                              buttons=[[_b("⬅️ برگشت", "fl:home")]])
        if action == "newd":
            seconds = licenses.parse_duration(arg)
            if seconds is None:
                return await answer("مدت نامعتبر.", alert=True)
            await self._set_state(uid, step="new_label", duration=seconds)
            return await edit(f"مدت: <b>{licenses.format_duration(seconds)}</b>\nیک اسم برای این لایسنس بفرست یا رد کن:",
                              buttons=[[_b("رد کردن", "fl:newskip")]])
        if action == "newskip":
            st = self.state.get(uid)
            if not st or st.get("step") != "new_label":
                return await answer("منقضی شد؛ دوباره «ساخت لایسنس».", alert=True)
            return await self._create(uid, st["duration"], "", edit)
        if action == "list":
            rows = await licenses.list_licenses(self.db)
            if not rows:
                return await edit("📭 هنوز لایسنسی نساخته‌ای.", buttons=[[_b("🎫 ساخت لایسنس", "fl:new")], [_b("⬅️ برگشت", "fl:home")]])
            buttons = [[_b(licenses.license_line(r)[:60], f"fl:lic:{r['id']}")] for r in rows[:40]]
            buttons.append([_b("⬅️ برگشت", "fl:home")])
            return await edit("📋 <b>لایسنس‌ها</b>", buttons=buttons)
        if action == "run":
            lines = ["🖥 <b>اکانت‌های در حال اجرا</b>"]
            for rt in self.fleet.runtimes.values():
                lines.append(f"• {'👑' if rt.account_id == MAIN_ID else '🔐'} {html.escape(rt.label)} (<code>{rt.user_id}</code>)")
            return await edit("\n".join(lines), buttons=[[_b("⬅️ برگشت", "fl:home")]])
        if action in {"lic", "susp", "unsusp", "delask", "del"} and arg.isdigit():
            lid = int(arg)
            if action == "susp":
                await self.fleet.suspend_license(lid, True)
            elif action == "unsusp":
                await self.fleet.suspend_license(lid, False)
            elif action == "delask":
                return await edit(f"🗑 لایسنس <b>#{lid}</b> حذف شود؟ اگر اکانتی روی آن فعال باشد خاموش و از تلگرام Logout می‌شود.",
                                  buttons=[[_b("✅ بله، حذف", f"fl:del:{lid}"), _b("❌ نه", f"fl:lic:{lid}")]])
            elif action == "del":
                row = await licenses.get_license(self.db, lid)
                await self.fleet.delete_license_and_account(lid)
                if row is not None and row["bound_user_id"]:
                    await self._notify(row["bound_user_id"], "🗑 لایسنس شما توسط مالک حذف شد؛ سلف روی اکانت خاموش و session بسته شد.")
                return await edit(f"✅ لایسنس #{lid} حذف شد.", buttons=[[_b("📋 لایسنس‌ها", "fl:list")]])
            text, buttons = await self.license_detail(lid)
            return await edit(text, buttons=buttons)
        await answer("دکمهٔ نامعتبر.", alert=True)

    async def _user_callback(self, uid: int, arg: str, edit: Reply, answer: Callable[..., Awaitable[Any]]) -> None:
        lic = await licenses.license_for_user(self.db, uid)
        if lic is None or licenses.state(lic) in (licenses.EXPIRED,):
            return await answer("لایسنس معتبری نداری؛ /start", alert=True)
        acc = await self.fleet.account_for_user(uid)
        if arg == "login":
            if licenses.state(lic) != licenses.ACTIVE:
                return await answer("لایسنس فعال نیست.", alert=True)
            await self._set_state(uid, step="phone")
            return await edit("📱 شمارهٔ <b>همین اکانت</b> را با کد کشور بفرست (مثال: 98912xxxxxxx).\n"
                              "فقط خود همین اکانت می‌تواند وارد شود. /cancel")
        if arg == "off" and acc is not None:
            await self.fleet.set_enabled(acc["id"], False)
        elif arg == "on" and acc is not None:
            ok, msg = await self.fleet.set_enabled(acc["id"], True)
            if not ok:
                return await answer(msg[:180], alert=True)
        elif arg == "logoutask" and acc is not None:
            return await edit("🚪 خروج کامل؟ session از تلگرام بسته می‌شود و برای ورود دوباره کد لازم است.",
                              buttons=[[_b("✅ بله", "fl:me:logout"), _b("❌ نه", "fl:me:refresh")]])
        elif arg == "logout" and acc is not None:
            await self.fleet.retire_account(acc["id"])
        home = await self.home_user(uid)
        if home is None:
            return await edit("لایسنس معتبری نداری؛ /start")
        await edit(home[0], buttons=home[1])

    async def _notify(self, user_id: int, text: str) -> None:
        bot = self.fleet.bot
        if bot is None or not user_id:
            return
        try:
            await bot.send_message(int(user_id), text)
        except Exception:  # noqa: BLE001
            pass

    async def dispatch_notices(self, notices: list) -> None:
        for n in notices:
            await self._notify(n.user_id, n.text)
            if self.fleet.owner_id and n.user_id != self.fleet.owner_id:
                await self._notify(self.fleet.owner_id, f"🔔 [{n.kind}] کاربر <code>{n.user_id}</code>: {n.text.splitlines()[0]}")


# ====================================================================== Telethon glue
async def start(fleet: Fleet, *, token: str, session: str, api_id: int, api_hash: str, tz: str) -> tuple[TelegramClient, ControlBot] | None:
    bot = TelegramClient(session, api_id, api_hash, auto_reconnect=True, flood_sleep_threshold=60)
    control = ControlBot(fleet, tz=tz)

    @bot.on(events.NewMessage(incoming=True, func=lambda e: e.is_private and not e.forward))
    async def on_message(event):
        async def reply(text, buttons=None):
            return await event.respond(text, buttons=buttons, parse_mode="html")
        try:
            await control.handle_text(event.sender_id, event.raw_text or "", reply, delete=event.delete)
        except Exception:  # noqa: BLE001
            log.exception("control bot message failed")
            await event.respond("❌ خطای داخلی؛ دوباره /start بزن.")

    @bot.on(events.CallbackQuery(pattern=rb"fl:.*"))
    async def on_callback(event):
        async def edit(text, buttons=None):
            try:
                return await event.edit(text, buttons=buttons, parse_mode="html")
            except MessageNotModifiedError:
                return None
        try:
            await control.handle_callback(event.sender_id, event.data.decode("utf-8", "ignore"), edit, event.answer)
        except Exception:  # noqa: BLE001
            log.exception("control bot callback failed")
            await event.answer("❌ خطای داخلی.", alert=True)

    try:
        await bot.start(bot_token=token)
    except RPCError as exc:
        log.error("control bot failed to start: %s", exc)
        return None
    fleet.bot = bot
    return bot, control
