"""License store (lives in the MAIN database only; per-account databases never see it).

A license is created by the owner (main account), has a duration in hours / days / months and is
redeemed once by the person who types it into the control bot. The clock starts at redeem time.
Only the SHA-256 of the code is stored; the plain code is shown to the owner exactly once.
"""
from __future__ import annotations

import hashlib
import re
import secrets
import time
from dataclasses import dataclass
from typing import Any

MINUTE = 60
HOUR = 3600
DAY = 86400
WEEK = 7 * DAY
MONTH = 30 * DAY
MAX_DURATION = 3650 * DAY
ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no 0/O/1/I

UNUSED, ACTIVE, SUSPENDED, EXPIRED = "unused", "active", "suspended", "expired"

_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
_UNITS = {
    "s": 1, "sec": 1, "secs": 1, "second": 1, "seconds": 1, "ثانیه": 1, "ث": 1,
    "min": MINUTE, "mins": MINUTE, "minute": MINUTE, "minutes": MINUTE, "دقیقه": MINUTE, "د": MINUTE,
    "h": HOUR, "hr": HOUR, "hour": HOUR, "hours": HOUR, "ساعت": HOUR, "س": HOUR,
    "d": DAY, "day": DAY, "days": DAY, "روز": DAY, "ر": DAY,
    "w": WEEK, "week": WEEK, "weeks": WEEK, "هفته": WEEK,
    "m": MONTH, "mo": MONTH, "month": MONTH, "months": MONTH, "ماه": MONTH, "م": MONTH,
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS licenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code_hash TEXT NOT NULL UNIQUE,
    code_hint TEXT,
    label TEXT,
    duration_s INTEGER NOT NULL,
    created_at REAL NOT NULL,
    redeem_by REAL NOT NULL,
    bound_user_id INTEGER,
    activated_at REAL,
    expires_at REAL,
    suspended INTEGER NOT NULL DEFAULT 0,
    expired_handled INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS fleet_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    license_id INTEGER NOT NULL UNIQUE,
    tg_user_id INTEGER NOT NULL UNIQUE,
    label TEXT,
    phone_masked TEXT,
    session_enc TEXT,
    enabled INTEGER NOT NULL DEFAULT 1,
    note TEXT,
    created_at REAL NOT NULL,
    last_active_at REAL
);
"""


def parse_duration(text: str) -> int | None:
    """'30s' / '5min' / '12h' / '3d' / '2w' / '1m' (m = month = 30 days) / '۳ روز' / '2 ماه' -> seconds, or None."""
    t = (text or "").strip().lower().translate(_DIGITS)
    m = re.fullmatch(r"(\d{1,9})\s*([a-z\u0600-\u06ff]+)", t)
    if not m:
        return None
    unit = _UNITS.get(m.group(2))
    if unit is None:
        return None
    seconds = int(m.group(1)) * unit
    return seconds if 0 < seconds <= MAX_DURATION else None


def parse_quick(text: str) -> tuple[int, str] | None:
    """'3d' / '30s اکانت دوم' / '۲ روز نام' -> (seconds, label). None when the text does not START with a duration."""
    t = (text or "").strip().translate(_DIGITS)
    m = re.match(r"(\d{1,9})\s*([A-Za-z\u0600-\u06ff]+)(?:\s+(.*))?$", t, re.S)
    if not m:
        return None
    seconds = parse_duration(m.group(1) + m.group(2))
    if seconds is None:
        return None
    return seconds, (m.group(3) or "").strip()[:40]


def format_duration(seconds: float) -> str:
    seconds = int(max(0, seconds))
    if seconds < 60:
        return f"{seconds} ثانیه" if seconds else "کمتر از یک ثانیه"
    days, rest = divmod(seconds, DAY)
    hours, rest = divmod(rest, HOUR)
    minutes = rest // 60
    if days:
        return f"{days} روز" + (f" و {hours} ساعت" if hours else "")
    if hours:
        return f"{hours} ساعت" + (f" و {minutes} دقیقه" if minutes else "")
    return f"{minutes} دقیقه"


def new_code() -> str:
    parts = ["".join(secrets.choice(ALPHABET) for _ in range(4)) for _ in range(3)]
    return "HPY-" + "-".join(parts)


def normalize(code: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", (code or "").upper().translate(_DIGITS))


def hash_code(code: str) -> str:
    return hashlib.sha256(normalize(code).encode("utf-8")).hexdigest()


def state(row: Any, now: float | None = None) -> str:
    now = time.time() if now is None else now
    if row["activated_at"] is None:
        return EXPIRED if now > row["redeem_by"] else UNUSED
    if now >= row["expires_at"]:
        return EXPIRED
    return SUSPENDED if row["suspended"] else ACTIVE


@dataclass
class RedeemResult:
    ok: bool
    reason: str = ""      # invalid | taken | expired | suspended
    row: Any = None
    first_time: bool = False


async def create_license(db: Any, duration_s: int, label: str | None, unused_ttl_s: float, now: float | None = None) -> tuple[int, str]:
    now = time.time() if now is None else now
    code = new_code()
    lid = await db.insert(
        "INSERT INTO licenses(code_hash,code_hint,label,duration_s,created_at,redeem_by) VALUES(?,?,?,?,?,?)",
        (hash_code(code), code[-4:], (label or "").strip()[:40] or None, int(duration_s), now, now + unused_ttl_s),
    )
    return lid, code


async def create_owner_license(db: Any, user_id: int, label: str | None, now: float | None = None) -> int:
    """A license the OWNER gives to an account he logs in himself: already redeemed by `user_id`, valid for
    the maximum duration, so the normal list / off / delete machinery keeps working for it."""
    now = time.time() if now is None else now
    code = new_code()  # never shown: nobody needs to redeem this one
    return await db.insert(
        "INSERT INTO licenses(code_hash,code_hint,label,duration_s,created_at,redeem_by,bound_user_id,activated_at,expires_at) "
        "VALUES(?,?,?,?,?,?,?,?,?)",
        (hash_code(code), code[-4:], ("👑 " + (label or "").strip())[:40], MAX_DURATION, now, now, int(user_id), now, now + MAX_DURATION),
    )


async def get_license(db: Any, license_id: int) -> Any:
    return await db.fetchone("SELECT * FROM licenses WHERE id=?", (int(license_id),))


async def list_licenses(db: Any) -> list[Any]:
    return await db.fetchall("SELECT * FROM licenses ORDER BY id DESC")


async def license_for_user(db: Any, user_id: int) -> Any:
    return await db.fetchone("SELECT * FROM licenses WHERE bound_user_id=? ORDER BY id DESC LIMIT 1", (int(user_id),))


async def redeem(db: Any, code: str, user_id: int, now: float | None = None) -> RedeemResult:
    now = time.time() if now is None else now
    if len(normalize(code)) < 8:
        return RedeemResult(False, "invalid")
    row = await db.fetchone("SELECT * FROM licenses WHERE code_hash=?", (hash_code(code),))
    if row is None:
        return RedeemResult(False, "invalid")
    st = state(row, now)
    if row["bound_user_id"] is not None and int(row["bound_user_id"]) != int(user_id):
        return RedeemResult(False, "taken")
    if st == EXPIRED:
        return RedeemResult(False, "expired", row)
    if st == SUSPENDED:
        return RedeemResult(False, "suspended", row)
    if row["bound_user_id"] is None:
        n = await db.execute(
            "UPDATE licenses SET bound_user_id=?, activated_at=?, expires_at=? WHERE id=? AND bound_user_id IS NULL",
            (int(user_id), now, now + int(row["duration_s"]), row["id"]),
        )
        if not n:  # somebody else redeemed it a moment ago
            return RedeemResult(False, "taken")
        return RedeemResult(True, "", await get_license(db, row["id"]), first_time=True)
    return RedeemResult(True, "", row, first_time=False)


async def set_suspended(db: Any, license_id: int, flag: bool) -> bool:
    return bool(await db.execute("UPDATE licenses SET suspended=? WHERE id=?", (1 if flag else 0, int(license_id))))


async def delete_license(db: Any, license_id: int) -> bool:
    return bool(await db.execute("DELETE FROM licenses WHERE id=?", (int(license_id),)))


async def due_for_expiry(db: Any, now: float | None = None) -> list[Any]:
    now = time.time() if now is None else now
    return await db.fetchall(
        "SELECT * FROM licenses WHERE activated_at IS NOT NULL AND expires_at<=? AND expired_handled=0", (now,))


async def mark_expiry_handled(db: Any, license_id: int) -> None:
    await db.execute("UPDATE licenses SET expired_handled=1 WHERE id=?", (int(license_id),))


class Throttle:
    """Wrong-license brute-force guard: 5 misses within 15 minutes block that user for 15 minutes."""

    def __init__(self, max_fails: int = 5, window: float = 900.0, block: float = 900.0):
        self.max_fails, self.window, self.block = max_fails, window, block
        self._fails: dict[int, list[float]] = {}
        self._blocked: dict[int, float] = {}

    def blocked_for(self, user_id: int, now: float | None = None) -> int:
        now = time.time() if now is None else now
        until = self._blocked.get(user_id, 0.0)
        if until <= now:
            self._blocked.pop(user_id, None)
            return 0
        return int(until - now) + 1

    def fail(self, user_id: int, now: float | None = None) -> None:
        now = time.time() if now is None else now
        hits = [t for t in self._fails.get(user_id, []) if now - t < self.window] + [now]
        self._fails[user_id] = hits
        if len(hits) >= self.max_fails:
            self._blocked[user_id] = now + self.block
            self._fails.pop(user_id, None)

    def success(self, user_id: int) -> None:
        self._fails.pop(user_id, None)


STATE_ICON = {UNUSED: "🆕", ACTIVE: "🟢", SUSPENDED: "⏸", EXPIRED: "⌛️"}
STATE_NAME = {UNUSED: "استفاده‌نشده", ACTIVE: "فعال", SUSPENDED: "خاموش‌شده توسط مالک", EXPIRED: "منقضی"}


def license_line(row: Any, now: float | None = None) -> str:
    now = time.time() if now is None else now
    st = state(row, now)
    tail = {
        ACTIVE: f"{format_duration(row['expires_at'] - now)} مانده" if row["expires_at"] else "",
        SUSPENDED: f"{format_duration(row['expires_at'] - now)} مانده (خاموش)" if row["expires_at"] else "",
        UNUSED: f"مدت {format_duration(row['duration_s'])} — استفاده‌نشده",
        EXPIRED: "منقضی",
    }[st]
    return f"{STATE_ICON[st]} #{row['id']} · {row['label'] or '—'} · {tail}"
