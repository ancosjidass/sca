"""`.whoami`, `.deactivate` and (main account only) `.lic ...`.

Accounts are run by core/fleet.py. A licensed account can switch itself off from inside Telegram with
`.deactivate`; it comes back with the control bot's «فعال‌سازی» button (no new login code needed).
The main account (from .env) can never be deactivated from here.
"""
from __future__ import annotations

import os
import re
import time

from telethon import events

from core import licenses

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)


def setup(client, db):
    def fleet():
        return getattr(client, "_hapoyi_fleet", None)

    def is_main() -> bool:
        return getattr(client, "_hapoyi_account_id", None) == 0

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}whoami$"))
    async def whoami(event):
        me = await client.get_me()
        name = " ".join(x for x in (me.first_name, me.last_name) if x).strip()
        text = f"👤 {name} (@{me.username})\nID: {me.id}\n"
        fl = fleet()
        if fl is None:
            return await event.reply(text + "🧩 این اکانت از طریق Fleet اجرا نمی‌شود.")
        if is_main():
            n = len(fl.runtimes)
            return await event.reply(text + f"👑 اکانت اصلی (مالک) — همین الان {n} اکانت هم‌زمان در حال اجراست.")
        rt = fl.runtimes.get(getattr(client, "_hapoyi_account_id", -1))
        lic = await licenses.get_license(fl.db, rt.license_id) if rt and rt.license_id else None
        left = licenses.format_duration(lic["expires_at"] - time.time()) if lic and lic["expires_at"] else "—"
        await event.reply(text + f"🔐 اکانت لایسنس‌دار — اعتبار باقی‌مانده: {left}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}deactivate$"))
    async def deactivate(event):
        fl = fleet()
        if fl is None or is_main():
            return await event.reply("❌ اکانت اصلی غیرفعال‌شدنی نیست (فقط اکانت‌های لایسنس‌دار).")
        aid = getattr(client, "_hapoyi_account_id")
        await fl.db.execute("UPDATE fleet_accounts SET enabled=0 WHERE id=?", (aid,))
        await event.reply("🚪 سلف روی این اکانت خاموش شد. برای روشن‌کردن دوباره، در بات کنترل «▶️ فعال‌کردن» را بزن.")
        fl.request_stop(aid)

    # ------------------------------------------------------------------ .lic (main account only)
    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}lic(?:\s+(.+))?$"))
    async def lic(event):
        fl = fleet()
        if fl is None or not is_main():
            return  # licensed accounts have no business creating licenses; stay silent
        args = (event.pattern_match.group(1) or "").split(None, 2)
        cmd = args[0].lower() if args else ""
        if cmd == "new" and len(args) >= 2:
            seconds = licenses.parse_duration(args[1])
            if seconds is None:
                return await event.reply("❌ مدت نامعتبر. مثال: `30s` ثانیه، `5min` دقیقه، `12h` ساعت، `3d` روز، `1m` ماه.")
            label = args[2].strip() if len(args) > 2 else None
            lid, code = await licenses.create_license(fl.db, seconds, label, fl.unused_ttl_s)
            await client.send_message("me", f"🎫 لایسنس #{lid} ({licenses.format_duration(seconds)})\n`{code}`\n"
                                      f"فقط همین یک بار نشان داده می‌شود. اگر تا {licenses.format_duration(fl.unused_ttl_s)} استفاده نشود باطل می‌شود.")
            return await event.reply(f"✅ لایسنس #{lid} ساخته شد؛ کد در Saved Messages است.")
        if cmd == "list":
            rows = await licenses.list_licenses(fl.db)
            if not rows:
                return await event.reply("📭 لایسنسی نداری.")
            return await event.reply("🎫 لایسنس‌ها\n" + "\n".join(licenses.license_line(r) for r in rows[:40]))
        if cmd in {"off", "on", "del"} and len(args) >= 2 and args[1].isdigit():
            lid = int(args[1])
            if await licenses.get_license(fl.db, lid) is None:
                return await event.reply("❌ این لایسنس پیدا نشد.")
            if cmd == "del":
                await fl.delete_license_and_account(lid)
                return await event.reply(f"🗑 لایسنس #{lid} حذف شد (اکانتش هم خاموش و logout شد).")
            await fl.suspend_license(lid, cmd == "off")
            return await event.reply(f"{'⏸ خاموش' if cmd == 'off' else '▶️ روشن'} شد: #{lid}")
        await event.reply(
            f"🎫 `{PREFIX}lic new <مدت> [نام]` — مدت: 30s / 5min / 12h / 3d / 1m\n`{PREFIX}lic list`\n"
            f"`{PREFIX}lic off|on|del <id>`")
