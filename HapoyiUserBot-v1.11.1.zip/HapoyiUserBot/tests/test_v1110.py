"""1.11.0: unlimited concurrent accounts (Fleet), licenses, control bot, account protect, remote mesdel, reactdel."""
from __future__ import annotations

import asyncio
import pathlib
import sys
import tempfile
import time
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from telethon.errors import PhoneCodeInvalidError, SessionPasswordNeededError  # noqa: E402
from telethon.tl.functions.account import ResetAuthorizationRequest  # noqa: E402
from telethon.tl.functions.messages import SendReactionRequest  # noqa: E402
from telethon.tl.types import User  # noqa: E402

from core import licenses  # noqa: E402
from core.control_bot import ControlBot  # noqa: E402
from core.database import Database  # noqa: E402
from core.fleet import Fleet, MAIN_ID  # noqa: E402

DAY = licenses.DAY


@pytest.fixture(autouse=True)
def _key(monkeypatch, tmp_path):
    import core.crypto_store as cs
    monkeypatch.setattr(cs, "DATA_DIR", tmp_path)
    monkeypatch.setattr(cs, "KEY_FILE", tmp_path / "session.key")
    monkeypatch.delenv("SESSION_ENCRYPTION_KEY", raising=False)


# ============================================================ licenses
def test_parse_duration():
    assert licenses.parse_duration("12h") == 12 * 3600
    assert licenses.parse_duration("3d") == 3 * DAY
    assert licenses.parse_duration("1m") == 30 * DAY
    assert licenses.parse_duration("۳ روز") == 3 * DAY
    assert licenses.parse_duration("2 ماه") == 60 * DAY
    assert licenses.parse_duration("5 ساعت") == 5 * 3600
    for bad in ("", "0h", "x", "5y", "-3d", "d3"):
        assert licenses.parse_duration(bad) is None


def test_license_lifecycle_and_hash_only_storage():
    async def run():
        db = Database(tempfile.mktemp(), control=True)
        await db.connect()
        lid, code = await licenses.create_license(db, 2 * DAY, "دوم", 7 * DAY, now=1000.0)
        row = await licenses.get_license(db, lid)
        assert code not in str(tuple(row)) and row["code_hint"] == code[-4:]
        assert licenses.state(row, 1000.0) == licenses.UNUSED

        assert (await licenses.redeem(db, "HPY-AAAA-BBBB-CCCC", 5, now=1001.0)).reason == "invalid"
        assert (await licenses.redeem(db, "x", 5)).reason == "invalid"
        ok = await licenses.redeem(db, code.lower().replace("-", " "), 5, now=2000.0)  # sloppy typing is fine
        assert ok.ok and ok.first_time and ok.row["expires_at"] == 2000.0 + 2 * DAY
        assert (await licenses.redeem(db, code, 6, now=2001.0)).reason == "taken"
        again = await licenses.redeem(db, code, 5, now=2002.0)
        assert again.ok and not again.first_time and again.row["expires_at"] == ok.row["expires_at"]

        await licenses.set_suspended(db, lid, True)
        assert (await licenses.redeem(db, code, 5, now=2003.0)).reason == "suspended"
        await licenses.set_suspended(db, lid, False)
        late = 2000.0 + 2 * DAY + 1
        assert (await licenses.redeem(db, code, 5, now=late)).reason == "expired"
        assert [r["id"] for r in await licenses.due_for_expiry(db, late)] == [lid]
        await licenses.mark_expiry_handled(db, lid)
        assert await licenses.due_for_expiry(db, late) == []

        # never-used license dies after its claim window
        lid2, code2 = await licenses.create_license(db, DAY, None, 100.0, now=5000.0)
        assert (await licenses.redeem(db, code2, 9, now=5101.0)).reason == "expired"

    asyncio.run(run())


def test_throttle_blocks_after_five_misses():
    t = licenses.Throttle()
    for i in range(4):
        t.fail(1, now=100.0 + i)
    assert t.blocked_for(1, now=105.0) == 0
    t.fail(1, now=105.0)
    assert t.blocked_for(1, now=106.0) > 0
    assert t.blocked_for(2, now=106.0) == 0
    assert t.blocked_for(1, now=106.0 + 901) == 0


# ============================================================ fake telegram
class FakeSession:
    def __init__(self, owner):
        self.owner = owner

    def save(self):
        return f"STR-{self.owner.uid}"


class FakeTg:
    """Stands in for a TelegramClient (both the userbot clients and the anonymous login client)."""
    instances: list["FakeTg"] = []

    def __init__(self, session: str, authorized: bool = True, uid: int | None = None):
        self.session_string = session
        self.uid = uid if uid is not None else (int(session.split("-")[1]) if session.startswith("STR-") else None)
        self._authorized = authorized and session.startswith("STR-")
        self.disconnected = self.logged_out = False
        self.handlers = []
        self.session = FakeSession(self)
        self.code_ok, self.needs_pw, self.login_uid = True, False, None
        self.signed = []
        FakeTg.instances.append(self)

    def on(self, builder=None):
        def deco(fn):
            self.handlers.append(fn)
            return fn
        return deco

    async def is_user_authorized(self):
        return self._authorized

    async def get_me(self):
        return SimpleNamespace(id=self.uid, phone="+98912", first_name=f"U{self.uid}", username=None)

    async def disconnect(self):
        self.disconnected = True

    async def log_out(self):
        self.logged_out = True
        self._authorized = False
        self.disconnected = True

    async def run_until_disconnected(self):
        await asyncio.Event().wait()

    # --- login side
    async def send_code_request(self, phone):
        self.phone = phone

    async def sign_in(self, phone=None, code=None, password=None):
        if password is not None:
            self.signed.append(("pw", password))
            self.uid = self.login_uid
            return
        if not self.code_ok:
            raise PhoneCodeInvalidError(request=None)
        if self.needs_pw:
            raise SessionPasswordNeededError(request=None)
        self.signed.append(("code", code))
        self.uid = self.login_uid


def make_factory(login_uid=None, **login_kw):
    async def factory(session: str):
        c = FakeTg(session)
        if not session:
            c.login_uid = login_uid
            for k, v in login_kw.items():
                setattr(c, k, v)
        return c
    return factory


async def make_fleet(tmp_path, factory=None):
    db = Database(str(tmp_path / "main.db"), control=True)
    await db.connect()
    fleet = Fleet(db, factory or make_factory(), data_dir=tmp_path, modules_package="tests.fixture_modules")
    fleet.install_task_tracking()
    return fleet, db


async def licensed(fleet, uid, duration=DAY, *, start=True):
    lid, code = await licenses.create_license(fleet.db, duration, f"acc{uid}", 7 * DAY)
    assert (await licenses.redeem(fleet.db, code, uid)).ok
    aid = await fleet.add_account(lid, uid, f"acc{uid}", f"STR-{uid}", "+98912")
    if start:
        ok, msg = await fleet.start_account(aid)
        assert ok, msg
    return lid, aid


# ============================================================ fleet
def test_many_accounts_run_at_once_with_separate_databases_and_tasks(tmp_path):
    async def run():
        fleet, db = await make_fleet(tmp_path)
        ok, _ = await fleet.start_main("STR-1")
        assert ok and fleet.owner_id == 1
        accounts = [await licensed(fleet, uid) for uid in (11, 12, 13, 14)]  # no upper limit
        assert len(fleet.runtimes) == 5 and MAIN_ID in fleet.runtimes
        await asyncio.sleep(0.05)
        ticks = {aid: fleet.runtimes[aid].client.ticks for _, aid in accounts}
        assert all(t > 0 for t in ticks.values())

        dbs = {fleet.runtimes[aid].db.path for _, aid in accounts}
        assert len(dbs) == 4 and fleet.runtimes[MAIN_ID].db is db
        rt = fleet.runtimes[accounts[0][1]]
        assert await rt.db.fetchone("SELECT name FROM sqlite_master WHERE name='licenses'") is None  # no license data inside accounts
        await rt.db.execute("INSERT INTO notes(owner_id,name,value,created_at,updated_at) VALUES(1,'a','b','x','x')")
        other = fleet.runtimes[accounts[1][1]]
        assert await other.db.fetchone("SELECT 1 FROM notes") is None  # settings never leak between accounts

        # stopping ONE account kills its background loop; the others keep running
        stopped_aid = accounts[0][1]
        stopped_client = fleet.runtimes[stopped_aid].client
        await fleet.stop_account(stopped_aid)
        frozen = stopped_client.ticks
        await asyncio.sleep(0.1)
        assert stopped_client.ticks == frozen and stopped_client.disconnected
        assert fleet.runtimes[accounts[1][1]].client.ticks > ticks[accounts[1][1]]
        assert len(fleet.runtimes) == 4
        await fleet.stop_all()
        assert fleet.runtimes == {}

    asyncio.run(run())


def test_account_off_on_keeps_session_and_needs_no_new_login(tmp_path):
    async def run():
        fleet, db = await make_fleet(tmp_path)
        lid, aid = await licensed(fleet, 21)
        ok, _ = await fleet.set_enabled(aid, False)
        assert ok and not fleet.is_running(aid)
        row = await db.fetchone("SELECT * FROM fleet_accounts WHERE id=?", (aid,))
        assert row["enabled"] == 0 and row["session_enc"] and "STR-21" not in row["session_enc"]  # encrypted at rest
        assert not any(c.logged_out for c in FakeTg.instances if c.session_string == "STR-21")
        ok, _ = await fleet.set_enabled(aid, True)
        assert ok and fleet.is_running(aid)
        # a "restart": brand-new fleet, same database
        fleet2 = Fleet(db, make_factory(), data_dir=tmp_path, modules_package="tests.fixture_modules")
        fleet2.install_task_tracking()
        await fleet.stop_all()
        res = await fleet2.resume_all()
        assert res and res[0][1] is True
        await fleet2.set_enabled(aid, False)
        fleet3 = Fleet(db, make_factory(), data_dir=tmp_path, modules_package="tests.fixture_modules")
        assert await fleet3.resume_all() == []  # switched off stays off across restarts

    asyncio.run(run())


def test_expiry_logs_the_account_out_and_wipes_it(tmp_path):
    async def run():
        fleet, db = await make_fleet(tmp_path)
        lid, aid = await licensed(fleet, 31, duration=3600)
        client = fleet.runtimes[aid].client
        assert await fleet.enforce_licenses() == []
        notices = await fleet.enforce_licenses(now=time.time() + 3601)
        assert [n.kind for n in notices] == ["expired"] and notices[0].user_id == 31
        assert client.logged_out and not fleet.is_running(aid)
        assert await db.fetchone("SELECT 1 FROM fleet_accounts") is None
        assert await fleet.enforce_licenses(now=time.time() + 3700) == []  # reported only once
        # an expired license can never start again
        lid2, aid2 = await licensed(fleet, 32, duration=3600, start=False)
        await db.execute("UPDATE licenses SET expires_at=? WHERE id=?", (time.time() - 5, lid2))
        ok, msg = await fleet.start_account(aid2)
        assert not ok and "منقضی" in msg

    asyncio.run(run())


def test_owner_can_suspend_resume_and_delete_a_license(tmp_path):
    async def run():
        fleet, db = await make_fleet(tmp_path)
        lid, aid = await licensed(fleet, 41)
        client = fleet.runtimes[aid].client
        assert await fleet.suspend_license(lid, True)
        assert not fleet.is_running(aid) and not client.logged_out  # off, session kept
        ok, msg = await fleet.start_account(aid)
        assert not ok and "خاموش" in msg
        assert await fleet.suspend_license(lid, False)
        assert fleet.is_running(aid)  # comes back by itself

        client2 = fleet.runtimes[aid].client
        assert await fleet.delete_license_and_account(lid)
        assert client2.logged_out and not fleet.is_running(aid)
        assert await licenses.get_license(db, lid) is None
        assert await db.fetchone("SELECT 1 FROM fleet_accounts") is None

        # deleting while the account is switched off still terminates its Telegram session
        lid3, aid3 = await licensed(fleet, 42)
        await fleet.set_enabled(aid3, False)
        await fleet.delete_license_and_account(lid3)
        assert any(c.logged_out and c.session_string == "STR-42" for c in FakeTg.instances)

    asyncio.run(run())


def test_dead_session_or_wrong_account_never_runs(tmp_path):
    async def run():
        fleet, db = await make_fleet(tmp_path)
        lid, code = await licenses.create_license(db, DAY, None, DAY)
        await licenses.redeem(db, code, 51)
        aid = await fleet.add_account(lid, 51, "x", "DEAD", None)  # not an STR- session -> unauthorized
        ok, msg = await fleet.start_account(aid)
        assert not ok and "دوباره وارد" in msg
        row = await db.fetchone("SELECT * FROM fleet_accounts WHERE id=?", (aid,))
        assert row["session_enc"] is None and row["enabled"] == 0

        lid2, code2 = await licenses.create_license(db, DAY, None, DAY)
        await licenses.redeem(db, code2, 52)
        aid2 = await fleet.add_account(lid2, 52, "y", "STR-999", None)  # session belongs to user 999, not 52
        ok, msg = await fleet.start_account(aid2)
        assert not ok and "همین اکانت" in msg and not fleet.is_running(aid2)

    asyncio.run(run())


# ============================================================ control bot
class Chat:
    def __init__(self):
        self.out, self.alerts, self.deleted = [], [], 0

    async def reply(self, text, buttons=None):
        self.out.append((text, buttons))

    async def delete(self):
        self.deleted += 1

    async def answer(self, text="", alert=False):
        self.alerts.append(text)

    @property
    def last(self):
        return self.out[-1][0] if self.out else ""


async def cb_env(tmp_path, factory=None):
    fleet, db = await make_fleet(tmp_path, factory)
    fleet.set_owner(1)
    bot = SimpleNamespace(sent=[])

    async def send_message(uid, text):
        bot.sent.append((uid, text))
    bot.send_message = send_message
    fleet.bot = bot
    return fleet, db, ControlBot(fleet), bot


def test_owner_creates_a_license_from_the_panel(tmp_path):
    async def run():
        fleet, db, cb, _ = await cb_env(tmp_path)
        c = Chat()
        await cb.handle_text(1, "/start", c.reply)
        assert "پنل مالک" in c.last
        await cb.handle_callback(1, "fl:new", c.reply, c.answer)
        await cb.handle_callback(1, "fl:newd:1d", c.reply, c.answer)
        await cb.handle_text(1, "اکانت دوم", c.reply)
        assert "HPY-" in c.last
        code = c.last.split("<code>")[1].split("</code>")[0]
        row = (await licenses.list_licenses(db))[0]
        assert row["duration_s"] == DAY and row["label"] == "اکانت دوم" and code not in str(tuple(row))
        # typed duration and "skip label" also work
        await cb.handle_callback(1, "fl:new", c.reply, c.answer)
        await cb.handle_text(1, "12h", c.reply)
        await cb.handle_callback(1, "fl:newskip", c.reply, c.answer)
        assert len(await licenses.list_licenses(db)) == 2
        await cb.handle_callback(1, "fl:new", c.reply, c.answer)
        await cb.handle_text(1, "zzz", c.reply)
        assert "نامعتبر" in c.last

    asyncio.run(run())


def test_strangers_get_nothing_without_a_license(tmp_path):
    async def run():
        fleet, db, cb, _ = await cb_env(tmp_path)
        lid, code = await licenses.create_license(db, DAY, None, DAY)
        c = Chat()
        await cb.handle_text(500, "/start", c.reply)
        assert "لایسنس" in c.last and "فعال" not in c.last
        await cb.handle_text(500, "hello", c.reply)
        assert "نامعتبر" in c.last
        # owner-only actions are refused for everybody else
        for data in ("fl:new", "fl:list", f"fl:del:{lid}", f"fl:susp:{lid}", "fl:run"):
            await cb.handle_callback(500, data, c.reply, c.answer)
        assert c.alerts == ["⛔ مجاز نیستی."] * 5 and await licenses.get_license(db, lid) is not None
        # brute force: blocked after 5 misses, even a correct code is not tried
        for _ in range(4):
            await cb.handle_text(500, "HPY-WRONG-WRONG-WRNG", c.reply)
        await cb.handle_text(500, code, c.reply)
        assert "ثانیه" in c.last
        # the real license works for somebody else, once
        await cb.handle_text(600, code, c.reply)
        assert "تأیید شد" in c.last
        await cb.handle_text(700, code, c.reply)
        assert "نامعتبر" in c.last

    asyncio.run(run())


def test_login_only_into_the_account_you_are_chatting_from(tmp_path):
    async def run():
        # the second account (user 77) logs in with its own phone
        fleet, db, cb, _ = await cb_env(tmp_path, make_factory(login_uid=77))
        lid, code = await licenses.create_license(db, DAY, "دوم", DAY)
        c = Chat()
        await cb.handle_text(77, code, c.reply)
        await cb.handle_callback(77, "fl:me:login", c.reply, c.answer)
        await cb.handle_text(77, "+98 912 000 0000", c.reply)
        assert "با فاصله" in c.last
        await cb.handle_text(77, "1 2 3 4 5", c.reply, c.delete)
        assert c.deleted == 1 and "فعال شد" in c.last
        assert fleet.is_running((await fleet.account_for_user(77))["id"])
        assert cb.state == {}
        # self-service off / on / logout
        aid = (await fleet.account_for_user(77))["id"]
        await cb.handle_callback(77, "fl:me:off", c.reply, c.answer)
        assert not fleet.is_running(aid) and "غیرفعال" in c.last
        await cb.handle_callback(77, "fl:me:on", c.reply, c.answer)
        assert fleet.is_running(aid)
        await cb.handle_callback(77, "fl:me:logout", c.reply, c.answer)
        assert not fleet.is_running(aid) and await fleet.account_for_user(77) is None
        assert "🔑 ورود به اکانت" in [b.text for row in c.out[-1][1] for b in row]

    asyncio.run(run())


def test_login_with_someone_elses_number_is_rejected_and_closed(tmp_path):
    async def run():
        fleet, db, cb, _ = await cb_env(tmp_path, make_factory(login_uid=999))  # the phone belongs to user 999
        lid, code = await licenses.create_license(db, DAY, None, DAY)
        c = Chat()
        await cb.handle_text(88, code, c.reply)
        await cb.handle_callback(88, "fl:me:login", c.reply, c.answer)
        await cb.handle_text(88, "989120000000", c.reply)
        await cb.handle_text(88, "12345", c.reply, c.delete)
        assert "فقط خودِ همین اکانت" in c.last
        assert await fleet.account_for_user(88) is None and await fleet.account_for_user(999) is None
        assert any(x.logged_out for x in FakeTg.instances if x.login_uid == 999)

    asyncio.run(run())


def test_login_with_2fa_and_wrong_code(tmp_path):
    async def run():
        fleet, db, cb, _ = await cb_env(tmp_path, make_factory(login_uid=66, needs_pw=True))
        lid, code = await licenses.create_license(db, DAY, None, DAY)
        c = Chat()
        await cb.handle_text(66, code, c.reply)
        await cb.handle_callback(66, "fl:me:login", c.reply, c.answer)
        await cb.handle_text(66, "989120000001", c.reply)
        await cb.handle_text(66, "1 2 3 4 5", c.reply, c.delete)
        assert "2FA" in c.last
        await cb.handle_text(66, "my-password", c.reply, c.delete)
        assert c.deleted == 2 and "فعال شد" in c.last

        (tmp_path / "b").mkdir()
        fleet2, db2, cb2, _ = await cb_env(tmp_path / "b", make_factory(login_uid=67, code_ok=False))
        lid, code = await licenses.create_license(db2, DAY, None, DAY)
        c2 = Chat()
        await cb2.handle_text(67, code, c2.reply)
        await cb2.handle_callback(67, "fl:me:login", c2.reply, c2.answer)
        await cb2.handle_text(67, "989120000002", c2.reply)
        await cb2.handle_text(67, "1 2 3 4 5", c2.reply, c2.delete)
        assert "کد اشتباه" in c2.last and cb2.state == {} and await fleet2.account_for_user(67) is None

    asyncio.run(run())


def test_owner_deletes_a_license_and_the_user_is_told(tmp_path):
    async def run():
        fleet, db, cb, bot = await cb_env(tmp_path)
        lid, aid = await licensed(fleet, 90)
        c = Chat()
        await cb.handle_callback(1, f"fl:lic:{lid}", c.reply, c.answer)
        assert "در حال اجرا" in c.last and "⏸ خاموش‌کردن لایسنس" in [b.text for row in c.out[-1][1] for b in row]
        await cb.handle_callback(1, f"fl:susp:{lid}", c.reply, c.answer)
        assert not fleet.is_running(aid) and "خاموش‌شده" in c.last
        await cb.handle_callback(1, f"fl:delask:{lid}", c.reply, c.answer)
        await cb.handle_callback(1, f"fl:del:{lid}", c.reply, c.answer)
        assert await licenses.get_license(db, lid) is None and any(u == 90 for u, _ in bot.sent)
        # user whose license is gone gets the license prompt again
        await cb.handle_text(90, "hi", c.reply)
        assert "نامعتبر" in c.last

    asyncio.run(run())


# ============================================================ account protect / mesdel / reactdel
from tests.test_regressions import FakeClient, FakeEvent, _dispatch  # noqa: E402


class ProtectClient(FakeClient):
    def __init__(self):
        super().__init__()
        self.auths = [self._a(0, current=True), self._a(1), self._a(2)]
        self.killed = []

    @staticmethod
    def _a(h, current=False):
        return SimpleNamespace(hash=h, current=current, device_model=f"dev{h}", platform="x", app_name="app", ip="1.2.3.4",
                               country="IR", date_created=None)

    async def __call__(self, request):
        if request.__class__.__name__ == "GetAuthorizationsRequest":
            return SimpleNamespace(authorizations=list(self.auths))
        if isinstance(request, ResetAuthorizationRequest):
            self.killed.append(request.hash)
            self.auths = [a for a in self.auths if a.hash != request.hash]
            return True
        return await super().__call__(request)


def test_account_protect_only_kills_sessions_born_while_on():
    async def run():
        from modules import account_protect as ap

        ap.POLL_SECONDS = 0.05
        db = Database(tempfile.mktemp())
        await db.connect()
        c = ProtectClient()
        ap.setup(c, db)

        async def cmd(text):
            ev = FakeEvent(c, text)
            assert await _dispatch(c, "protect_cmd", ev)
            return ev.replies[0]

        await asyncio.sleep(0.15)
        assert c.killed == []                                  # OFF: nothing is touched
        assert "روشن شد" in await cmd(".protect on")
        c.auths.append(c._a(3))                                # a new login while ON
        await asyncio.sleep(0.2)
        assert c.killed == [3]                                 # killed on the spot; 1 and 2 (older) and 0 (me) untouched
        assert "🟢 روشن" in await cmd(".account protect status")

        assert "خاموش شد" in await cmd(".protect off")
        c.auths.append(c._a(4))                                # created while OFF
        await asyncio.sleep(0.2)
        assert c.killed == [3]
        await cmd(".protect on")                               # back ON: 4 is trusted now
        await asyncio.sleep(0.2)
        assert c.killed == [3] and {a.hash for a in c.auths} == {0, 1, 2, 4}
        c.auths.append(c._a(5))
        await asyncio.sleep(0.2)
        assert c.killed == [3, 5]
        assert any(call[0] == "send" and "بسته شد" in call[1][1] for call in c.calls if isinstance(call, tuple))

    asyncio.run(run())


def test_account_protect_never_touches_the_current_session():
    from modules.account_protect import new_sessions
    auths = [SimpleNamespace(hash=0, current=True), SimpleNamespace(hash=7, current=False), SimpleNamespace(hash=8, current=False)]
    assert [a.hash for a in new_sessions(auths, {7})] == [8]


def _lifecycle_env(db):
    from tests.test_v171 import _lifecycle
    return _lifecycle(db)


def test_mesdel_works_on_a_chat_given_by_id_without_opening_it():
    async def run():
        db = Database(tempfile.mktemp())
        await db.connect()
        c = _lifecycle_env(db)
        seen, deleted = {}, []

        async def get_entity(ref):
            seen["ref"] = ref
            return User(id=4242)

        async def iter_messages(chat, from_user=None, limit=None, **kw):
            seen["chat"] = chat
            for i, mid in enumerate((50, 49, 48, 47)):
                if limit is not None and i >= limit:
                    return
                yield SimpleNamespace(id=mid)

        async def delete_messages(chat, ids, **kw):
            deleted.append((chat, list(ids)))

        c.get_entity, c.iter_messages, c.delete_messages = get_entity, iter_messages, delete_messages
        ev = FakeEvent(c, ".mesdel all 4242")
        await _dispatch(c, "mesdel", ev)
        assert seen["ref"] == 4242 or getattr(seen["ref"], "user_id", None) == 4242
        assert deleted[0][0].id == 4242 and deleted[0][1] == [50, 49, 48, 47]
        assert ev.deleted  # the command itself disappears from the chat it was typed in
        ev2 = FakeEvent(c, ".mesdel 2 @somegroup")
        await _dispatch(c, "mesdel", ev2)
        assert deleted[1][1] == [50, 49] and seen["ref"] == "@somegroup"
        # bad chat
        async def nope(ref):
            raise ValueError("no")
        c.get_entity = nope
        ev3 = FakeEvent(c, ".mesdel all 1")
        await _dispatch(c, "mesdel", ev3)
        assert "پیدا نشد" in ev3.replies[0]

    asyncio.run(run())


def test_reactdel_removes_only_my_reactions(monkeypatch):
    async def run():
        import modules.message_lifecycle as ml

        real_sleep = asyncio.sleep

        async def fast(_delay, *a, **k):
            await real_sleep(0)  # still yields, so background loops cannot starve the test
        monkeypatch.setattr(ml.asyncio, "sleep", fast)
        db = Database(tempfile.mktemp())
        await db.connect()
        c = _lifecycle_env(db)
        mine = SimpleNamespace(results=[SimpleNamespace(chosen_order=0)])
        theirs = SimpleNamespace(results=[SimpleNamespace(chosen_order=None)])
        msgs = [SimpleNamespace(id=10, reactions=mine), SimpleNamespace(id=9, reactions=theirs),
                SimpleNamespace(id=8, reactions=None), SimpleNamespace(id=7, reactions=mine)]

        async def iter_messages(chat, limit=None, **kw):
            for i, m in enumerate(msgs):
                if limit is not None and i >= limit:
                    return
                yield m

        c.iter_messages = iter_messages
        async def get_entity(ref):
            return User(id=777)
        c.get_entity = get_entity
        ev = FakeEvent(c, ".reactdel 100")
        await _dispatch(c, "reactdel", ev)
        sent = [x for x in c.calls if isinstance(x, SendReactionRequest)]
        assert [r.msg_id for r in sent] == [10, 7] and all(list(r.reaction) == [] for r in sent)
        c.calls.clear()
        ev2 = FakeEvent(c, ".reactdel 2 777")  # only the 2 newest messages are scanned
        await _dispatch(c, "reactdel", ev2)
        assert [r.msg_id for r in c.calls if isinstance(r, SendReactionRequest)] == [10]
        ev3 = FakeEvent(c, ".reactdel")
        await _dispatch(c, "reactdel", ev3)
        assert "فرمت" in ev3.replies[0]

    asyncio.run(run())


# ============================================================ owner: typed durations + "add self to an account"
def test_parse_duration_seconds_minutes_and_quick_form():
    assert licenses.parse_duration("30s") == 30
    assert licenses.parse_duration("5min") == 300
    assert licenses.parse_duration("12h") == 12 * 3600 and licenses.parse_duration("3d") == 3 * DAY
    assert licenses.parse_duration("1m") == 30 * DAY  # m stays "month"
    assert licenses.parse_duration("۴۵ ثانیه") == 45 and licenses.parse_duration("2w") == 14 * DAY
    for bad in ("0s", "s", "30x", "99999999999s", "4000d"):
        assert licenses.parse_duration(bad) is None
    assert licenses.parse_quick("3d") == (3 * DAY, "")
    assert licenses.parse_quick("30s اکانت دوم") == (30, "اکانت دوم")
    assert licenses.parse_quick("۲ روز  نام") == (2 * DAY, "نام")
    for not_a_duration in ("سلام", "98912000000", "3 سلام", "/start", ""):
        assert licenses.parse_quick(not_a_duration) is None
    assert licenses.format_duration(30) == "30 ثانیه"


def test_owner_creates_a_license_just_by_typing_a_duration(tmp_path):
    async def run():
        fleet, db, cb, _ = await cb_env(tmp_path)
        c = Chat()
        await cb.handle_text(1, "30s", c.reply)
        assert "HPY-" in c.last
        await cb.handle_text(1, "3d اکانت دوم", c.reply)
        rows = {r["duration_s"]: r for r in await licenses.list_licenses(db)}
        assert set(rows) == {30, 3 * DAY} and rows[3 * DAY]["label"] == "اکانت دوم"
        await cb.handle_text(1, "hello", c.reply)  # anything else still just shows the panel
        assert "پنل مالک" in c.last and len(await licenses.list_licenses(db)) == 2
        # a stranger typing a duration gets nothing
        await cb.handle_text(500, "3d", c.reply)
        assert len(await licenses.list_licenses(db)) == 2
        # the panel offers the new button
        assert "➕ افزودن سلف به اکانت (بدون لایسنس)" in [b.text for row in c.out[-2][1] for b in row]

    asyncio.run(run())


def test_owner_logs_any_account_in_without_a_license_code(tmp_path):
    async def run():
        fleet, db = await make_fleet(tmp_path, make_factory(login_uid=77, needs_pw=True))
        fleet.set_owner(1)
        ok, _ = await fleet.start_main("STR-1")
        assert ok
        cb = ControlBot(fleet)
        c = Chat()
        await cb.handle_callback(1, "fl:add", c.reply, c.answer)
        await cb.handle_text(1, "+98 912 000 0077", c.reply)  # a number that is NOT the owner's own
        assert "با فاصله" in c.last
        await cb.handle_text(1, "1 2 3 4 5", c.reply, c.delete)
        assert "2FA" in c.last
        await cb.handle_text(1, "pw", c.reply, c.delete)
        assert c.deleted == 2 and "فعال شد" in c.last and cb.state == {}
        acc = await fleet.account_for_user(77)
        assert acc is not None and fleet.is_running(acc["id"]) and len(fleet.runtimes) == 2
        lic = await licenses.get_license(db, acc["license_id"])
        assert licenses.state(lic) == licenses.ACTIVE and lic["bound_user_id"] == 77 and lic["label"].startswith("👑")
        # its database is its own
        assert fleet.runtimes[acc["id"]].db.path != fleet.runtimes[MAIN_ID].db.path
        # logging the same account in again reuses its license (no second license)
        n = len(await licenses.list_licenses(db))
        await cb.handle_callback(1, "fl:add", c.reply, c.answer)
        await cb.handle_text(1, "989120000077", c.reply)
        await cb.handle_text(1, "1 2 3 4 5", c.reply, c.delete)
        await cb.handle_text(1, "pw", c.reply, c.delete)
        assert len(await licenses.list_licenses(db)) == n
        # the owner can still switch it off / delete it from the license list
        await fleet.delete_license_and_account(acc["license_id"])
        assert await fleet.account_for_user(77) is None

    asyncio.run(run())


def test_owner_add_refuses_the_main_account_and_strangers_cannot_use_it(tmp_path):
    async def run():
        fleet, db = await make_fleet(tmp_path, make_factory(login_uid=1))  # the phone belongs to the MAIN account
        fleet.set_owner(1)
        await fleet.start_main("STR-1")
        cb = ControlBot(fleet)
        c = Chat()
        await cb.handle_callback(1, "fl:add", c.reply, c.answer)
        await cb.handle_text(1, "989120000001", c.reply)
        await cb.handle_text(1, "12345", c.reply, c.delete)
        assert "اکانت اصلی" in c.last and len(fleet.runtimes) == 1 and cb.state == {}
        assert any(x.logged_out for x in FakeTg.instances if x.login_uid == 1)  # the stray new session is closed
        assert await licenses.list_licenses(db) == []
        # a non-owner can neither open the add flow nor skip the license check
        await cb.handle_callback(500, "fl:add", c.reply, c.answer)
        assert c.alerts[-1] == "⛔ مجاز نیستی." and 500 not in cb.state
        cb.state[500] = {"ts": time.time(), "step": "phone", "owner_add": True}
        await cb.handle_text(500, "989120000009", c.reply)
        assert "لایسنس فعالی نداری" in c.last and await fleet.account_for_user(500) is None

    asyncio.run(run())
