from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
DB_PATH = Path(os.getenv("HAPOYI_DB", DATA_DIR / "hapoyi.db"))
SESSION_PATH = Path(os.getenv("HAPOYI_SESSION", DATA_DIR / "hapoyi"))


def _int_env(name: str, default: int = 0) -> int:
    raw = os.getenv(name, str(default)).strip()
    try:
        return int(raw)
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    api_id: int
    api_hash: str
    session: str
    command_prefix: str
    timezone: str
    crypto_provider: str
    crypto_cache_seconds: int
    fx_provider: str
    default_toman_divisor: float
    log_level: str
    owner_only: bool
    bot_token: str
    ui_enabled: bool
    bot_session: str

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            api_id=_int_env("API_ID"),
            api_hash=os.getenv("API_HASH", "").strip(),
            session=os.getenv("SESSION", str(SESSION_PATH)),
            command_prefix=os.getenv("COMMAND_PREFIX", ".").strip() or ".",
            timezone=os.getenv("TIMEZONE", "Asia/Tehran"),
            crypto_provider=os.getenv("CRYPTO_PROVIDER", "coingecko").strip(),
            crypto_cache_seconds=_int_env("CRYPTO_CACHE_SECONDS", 20),
            fx_provider=os.getenv("FX_PROVIDER", "reference").strip(),
            default_toman_divisor=float(os.getenv("TOMAN_DIVISOR", "10")),
            log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
            owner_only=os.getenv("OWNER_ONLY", "true").lower() not in {"0", "false", "no"},
            bot_token=os.getenv("BOT_TOKEN", "").strip(),
            ui_enabled=os.getenv("UI_ENABLED", "true").lower() not in {"0", "false", "no"},
            bot_session=os.getenv("HAPOYI_BOT_SESSION", str(DATA_DIR / "hapoyi_ui_bot")),
        )

    def validate(self) -> list[str]:
        errors: list[str] = []
        if self.api_id <= 0:
            errors.append("API_ID is missing or invalid")
        if len(self.api_hash) < 20:
            errors.append("API_HASH is missing or invalid")
        if not self.session:
            errors.append("SESSION is empty")
        if not self.command_prefix:
            errors.append("COMMAND_PREFIX is empty")
        return errors
