"""Which fleet account the currently running code belongs to.

Every asyncio task created while this is set is remembered by the Fleet, so stopping an account
cancels ALL of its background work (module loops, schedulers, Telethon internals) - nothing keeps
running for a disabled / expired account, and nothing leaks into another account.
"""
from __future__ import annotations

from contextvars import ContextVar

CURRENT_ACCOUNT: ContextVar[int | None] = ContextVar("hapoyi_current_account", default=None)
