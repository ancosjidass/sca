from __future__ import annotations

from typing import Any

from telethon.tl.functions.channels import EditBannedRequest
from telethon.tl.functions.messages import DeleteChatUserRequest
from telethon.tl.types import InputPeerChannel, InputPeerChat


class UnsupportedChat(Exception):
    """Operation cannot be done in this kind of chat (e.g. mute in a legacy group)."""


async def edit_banned(client: Any, event_or_chat: Any, user: Any, rights: Any) -> None:
    """Apply ChatBannedRights to `user` in the chat of `event_or_chat`.

    Works in supergroups. In legacy basic groups only removal (ban/kick) exists.
    Raises telethon RPCError / UnsupportedChat on failure so callers can report it.
    """
    if hasattr(event_or_chat, "get_input_chat"):
        peer = await event_or_chat.get_input_chat()
    else:
        peer = await client.get_input_entity(event_or_chat)
    target = await client.get_input_entity(user)
    if isinstance(peer, InputPeerChannel):
        await client(EditBannedRequest(peer, target, rights))
        return
    if isinstance(peer, InputPeerChat):
        if getattr(rights, "view_messages", False):
            await client(DeleteChatUserRequest(peer.chat_id, target, revoke_history=False))
            return
        raise UnsupportedChat("در گروه‌های قدیمی (غیر سوپرگروه) mute/unban ممکن نیست؛ گروه را به سوپرگروه تبدیل کن.")
    raise UnsupportedChat("این نوع چت از این عملیات پشتیبانی نمی‌کند.")
