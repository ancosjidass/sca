from __future__ import annotations

import asyncio
import logging
import os

from dotenv import load_dotenv

from config import Settings
import config as config_module
from core import control_bot
from core.database import Database
from core.fleet import Fleet, make_client_factory
from core.logging_setup import setup_logging

log = logging.getLogger(__name__)


async def _license_watcher(fleet: Fleet, control) -> None:
    """Expired licenses are retired and suspended ones switched off, within a few seconds."""
    while True:
        try:
            notices = await fleet.enforce_licenses()
            if control is not None and notices:
                await control.dispatch_notices(notices)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            log.warning("license watcher: %s: %s", exc.__class__.__name__, exc)
        await asyncio.sleep(5)


async def start() -> None:
    load_dotenv()
    settings = Settings.from_env()
    setup_logging(settings.log_level)
    errors = settings.validate()
    if errors:
        raise SystemExit("Configuration errors:\n- " + "\n- ".join(errors))

    db = Database(config_module.DB_PATH, control=True)
    await db.connect()

    fleet = Fleet(db, make_client_factory(settings.api_id, settings.api_hash),
                  data_dir=config_module.DATA_DIR,
                  unused_license_days=float(os.getenv("LICENSE_UNUSED_DAYS", "7") or 7))
    fleet.install_task_tracking()
    owner_env = int(os.getenv("HAPOYI_OWNER_ID", "0") or 0)
    if owner_env:
        fleet.set_owner(owner_env)

    ok, info = await fleet.start_main(settings.session)
    if ok:
        log.info("main account online: %s (owner id %s)", info, fleet.owner_id)
    else:
        log.error("main account NOT started: %s", info)

    bot = control = None
    if settings.bot_token:
        started = await control_bot.start(fleet, token=settings.bot_token, session=settings.bot_session, api_id=settings.api_id,
                                          api_hash=settings.api_hash, tz=settings.timezone)
        if started is None:
            log.error("control bot did not start (check BOT_TOKEN / API_ID / API_HASH): licensing is unavailable")
        else:
            bot, control = started
            if settings.ui_enabled:
                from modules import ui
                ui.attach(bot, fleet)
            if not fleet.owner_id:
                log.error("HAPOYI_OWNER_ID is empty and the main account is offline: nobody can use the owner panel")
    else:
        log.warning("BOT_TOKEN is empty: running the main account only (no licenses, no extra accounts)")

    for account_id, resumed_ok, msg in await fleet.resume_all():
        log.info("licensed account #%s %s%s", account_id, "online" if resumed_ok else "NOT started: ", "" if resumed_ok else msg)

    watcher = asyncio.get_running_loop().create_task(_license_watcher(fleet, control))
    try:
        if bot is not None:
            await bot.run_until_disconnected()
        elif fleet.runtimes:
            await asyncio.gather(*[rt.run_task for rt in fleet.runtimes.values() if rt.run_task])
        else:
            log.error("nothing to run; exiting")
    finally:
        watcher.cancel()
        await fleet.stop_all()
        if bot is not None:
            await bot.disconnect()
        await db.close()
