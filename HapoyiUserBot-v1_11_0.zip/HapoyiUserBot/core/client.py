from __future__ import annotations

import logging
from telethon import TelegramClient

from config import Settings

log = logging.getLogger(__name__)


def build_client(settings: Settings) -> TelegramClient:
    client = TelegramClient(
        settings.session,
        settings.api_id,
        settings.api_hash,
        sequential_updates=True,
        auto_reconnect=True,
        flood_sleep_threshold=60,
    )
    log.info("Telegram client initialized with Telethon 1.45.x")
    return client
