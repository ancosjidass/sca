"""Encrypts Telethon session strings before they touch the database.

Key priority: SESSION_ENCRYPTION_KEY env var (base64 urlsafe, 32 bytes - what Fernet.generate_key()
produces) > a key auto-generated on first run and stored in data/session.key (0600). Losing this key
means every stored session string becomes unreadable (accounts must be re-added via /login).
"""
from __future__ import annotations

import os
import stat
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
KEY_FILE = DATA_DIR / "session.key"

__all__ = ["encrypt", "decrypt", "DecryptionError", "load_key"]


class DecryptionError(Exception):
    pass


def load_key() -> bytes:
    env_key = os.getenv("SESSION_ENCRYPTION_KEY", "").strip()
    if env_key:
        return env_key.encode("ascii")
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if KEY_FILE.exists():
        return KEY_FILE.read_bytes().strip()
    key = Fernet.generate_key()
    KEY_FILE.write_bytes(key)
    try:
        os.chmod(KEY_FILE, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass
    return key


def _fernet() -> Fernet:
    return Fernet(load_key())


def encrypt(plaintext: str) -> str:
    return _fernet().encrypt(plaintext.encode("utf-8")).decode("ascii")


def decrypt(token: str) -> str:
    try:
        return _fernet().decrypt(token.encode("ascii")).decode("utf-8")
    except (InvalidToken, ValueError) as exc:
        raise DecryptionError("session قابل رمزگشایی نیست (کلید SESSION_ENCRYPTION_KEY عوض شده؟)") from exc
