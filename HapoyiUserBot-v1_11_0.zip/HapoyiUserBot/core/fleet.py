"""Fleet: runs ANY number of userbot accounts at the same time (no switching).

* account 0 ("main") is the account from `.env` (SESSION). It needs no license and lives in the
  main database.
* every other account belongs to a license. It gets its own SQLite file (data/accounts/u<id>.db),
  its own module instances and its own background tasks, so two accounts never share settings,
  jobs, filters, AFK state, ... even in the same chat.
* stopping an account disconnects it AND cancels every task it started (see core/accountctx.py).
"""
from __future__ import annotations

import asyncio
import contextvars
import logging
import re
import time
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable

from telethon import TelegramClient
from telethon.errors import AuthKeyUnregisteredError, RPCError
from telethon.sessions import StringSession

from core import licenses
from core.accountctx import CURRENT_ACCOUNT
from core.crypto_store import DecryptionError, decrypt, encrypt
from core.database import Database
from core.guard import install_handler_guard
from core.registry import ModuleRegistry

log = logging.getLogger(__name__)

MAIN_ID = 0
ClientFactory = Callable[[str], Awaitable[TelegramClient]]


def mask_phone(phone: str) -> str:
    digits = "".join(c for c in phone if c.isdigit())
    if len(digits) <= 4:
        return "*" * len(digits)
    return digits[:3] + "*" * (len(digits) - 5) + digits[-2:]


def _looks_like_string_session(value: str) -> bool:
    return bool(re.fullmatch(r"1[A-Za-z0-9_\-=]{100,}", value.strip()))


def make_client_factory(api_id: int, api_hash: str) -> ClientFactory:
    """'' -> fresh anonymous session; a Telethon string -> StringSession; anything else -> session file path."""
    async def factory(session_value: str) -> TelegramClient:
        v = (session_value or "").strip()
        session: Any = StringSession(v) if (not v or _looks_like_string_session(v)) else v
        client = TelegramClient(session, api_id, api_hash, sequential_updates=True, auto_reconnect=True, flood_sleep_threshold=60)
        await client.connect()
        return client
    return factory


@dataclass
class Runtime:
    account_id: int
    kind: str                       # "main" | "licensed"
    label: str
    user_id: int | None
    client: Any
    registry: Any
    db: Any
    owns_db: bool
    license_id: int | None = None
    started_at: float = field(default_factory=time.time)
    run_task: asyncio.Task | None = None


@dataclass
class Notice:
    user_id: int | None
    kind: str          # expired | suspended | session_dead | removed
    text: str


def spawn_detached(coro: Any) -> asyncio.Task:
    """Create a task that is NOT attributed to any account (so it survives that account's stop)."""
    return contextvars.Context().run(asyncio.get_running_loop().create_task, coro)


class Fleet:
    def __init__(self, control_db: Any, client_factory: ClientFactory, *, data_dir: str | Path | None = None,
                 modules_package: str = "modules", unused_license_days: float = 7.0):
        self.db = control_db
        self.unused_ttl_s = float(unused_license_days) * licenses.DAY
        self.client_factory = client_factory
        self.modules_package = modules_package
        self.data_dir = Path(data_dir) if data_dir else Path(__file__).resolve().parents[1] / "data"
        self.runtimes: dict[int, Runtime] = {}
        self.bot: Any = None
        self._owner_id = 0
        self._tasks: dict[int, set[asyncio.Task]] = defaultdict(set)
        self._locks: dict[int, asyncio.Lock] = defaultdict(asyncio.Lock)
        self._tracking = False

    # ------------------------------------------------------------------ owner / lookups
    @property
    def owner_id(self) -> int:
        return self._owner_id

    def set_owner(self, user_id: int) -> None:
        self._owner_id = int(user_id)

    def runtime_for_user(self, user_id: int | None) -> Runtime | None:
        if user_id is None:
            return None
        for rt in self.runtimes.values():
            if rt.user_id is not None and int(rt.user_id) == int(user_id):
                return rt
        return None

    def is_running(self, account_id: int) -> bool:
        return account_id in self.runtimes

    # ------------------------------------------------------------------ task tracking
    def install_task_tracking(self) -> None:
        if self._tracking:
            return
        loop = asyncio.get_running_loop()
        previous = loop.get_task_factory()
        fleet = self

        def factory(loop_: Any, coro: Any, **kw: Any) -> asyncio.Task:
            task = previous(loop_, coro, **kw) if previous else asyncio.Task(coro, loop=loop_, **kw)
            aid = CURRENT_ACCOUNT.get()
            if aid is not None:
                bucket = fleet._tasks[aid]
                bucket.add(task)
                task.add_done_callback(bucket.discard)
            return task

        loop.set_task_factory(factory)
        self._tracking = True

    async def _cancel_tasks(self, account_id: int) -> None:
        bucket = self._tasks.pop(account_id, set())
        me = asyncio.current_task()
        victims = [t for t in bucket if not t.done() and t is not me]
        for t in victims:
            t.cancel()
        if victims:
            await asyncio.wait(victims, timeout=5)

    # ------------------------------------------------------------------ account rows
    async def account_for_user(self, user_id: int) -> Any:
        return await self.db.fetchone("SELECT * FROM fleet_accounts WHERE tg_user_id=?", (int(user_id),))

    async def account_for_license(self, license_id: int) -> Any:
        return await self.db.fetchone("SELECT * FROM fleet_accounts WHERE license_id=?", (int(license_id),))

    async def list_accounts(self) -> list[Any]:
        return await self.db.fetchall("SELECT * FROM fleet_accounts ORDER BY id")

    async def add_account(self, license_id: int, tg_user_id: int, label: str, session_string: str, phone: str | None) -> int:
        """Store (or replace) the account for this license / Telegram user. Does not start it."""
        for old in (await self.account_for_user(tg_user_id), await self.account_for_license(license_id)):
            if old is not None:
                await self.stop_account(old["id"])
                await self.db.execute("DELETE FROM fleet_accounts WHERE id=?", (old["id"],))
        return await self.db.insert(
            "INSERT INTO fleet_accounts(license_id,tg_user_id,label,phone_masked,session_enc,enabled,created_at) VALUES(?,?,?,?,?,1,?)",
            (int(license_id), int(tg_user_id), label, mask_phone(phone) if phone else None, encrypt(session_string), time.time()),
        )

    def _db_path(self, user_id: int) -> Path:
        folder = self.data_dir / "accounts"
        folder.mkdir(parents=True, exist_ok=True)
        return folder / f"u{int(user_id)}.db"

    # ------------------------------------------------------------------ start / stop
    async def _launch(self, account_id: int, kind: str, label: str, user_id: int | None, client: Any, db: Any,
                      owns_db: bool, license_id: int | None) -> Runtime:
        install_handler_guard(client)
        client._hapoyi_fleet = self
        client._hapoyi_account_id = account_id
        client._hapoyi_kind = kind
        registry = ModuleRegistry(client, db)
        client._hapoyi_registry = registry
        try:
            await registry.load_all(self.modules_package)
        except Exception as exc:  # noqa: BLE001 - keep the account online even if one module misbehaves
            log.exception("module load failed for account %s: %s", account_id, exc)
        rt = Runtime(account_id, kind, label, user_id, client, registry, db, owns_db, license_id)
        rt.run_task = asyncio.get_running_loop().create_task(self._run(client))
        self.runtimes[account_id] = rt
        return rt

    async def _run(self, client: Any) -> None:
        try:
            await client.run_until_disconnected()
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            log.warning("userbot loop ended: %s: %s", exc.__class__.__name__, exc)

    async def start_main(self, session_value: str) -> tuple[bool, str]:
        async def go() -> tuple[bool, str]:
            CURRENT_ACCOUNT.set(MAIN_ID)
            async with self._locks[MAIN_ID]:
                if MAIN_ID in self.runtimes:
                    return True, self.runtimes[MAIN_ID].label
                try:
                    client = await self.client_factory(session_value)
                    if not await client.is_user_authorized():
                        await client.disconnect()
                        return False, "SESSION اکانت اصلی معتبر نیست؛ یک بار با اسکریپت لاگین بساز."
                    me = await client.get_me()
                except (RPCError, AuthKeyUnregisteredError, ConnectionError, OSError) as exc:
                    return False, f"اتصال اکانت اصلی برقرار نشد: {exc.__class__.__name__}"
                if not self._owner_id:
                    self._owner_id = int(me.id)
                label = (getattr(me, "first_name", None) or getattr(me, "username", None) or "اصلی")
                await self._launch(MAIN_ID, "main", label, int(me.id), client, self.db, False, None)
                return True, label
        return await spawn_detached(go())

    async def start_account(self, account_id: int) -> tuple[bool, str]:
        async def go() -> tuple[bool, str]:
            CURRENT_ACCOUNT.set(account_id)
            async with self._locks[account_id]:
                return await self._start_licensed(account_id)
        return await spawn_detached(go())

    async def _start_licensed(self, account_id: int) -> tuple[bool, str]:
        if account_id in self.runtimes:
            return True, self.runtimes[account_id].label
        row = await self.db.fetchone("SELECT * FROM fleet_accounts WHERE id=?", (account_id,))
        if row is None:
            return False, "این اکانت پیدا نشد."
        lic = await licenses.get_license(self.db, row["license_id"])
        st = licenses.state(lic) if lic is not None else licenses.EXPIRED
        if st == licenses.SUSPENDED:
            return False, "لایسنس شما توسط مالک خاموش شده است."
        if st != licenses.ACTIVE:
            return False, "لایسنس منقضی یا حذف شده است."
        if not row["session_enc"]:
            return False, "برای این اکانت session ذخیره نشده؛ دوباره وارد شو."
        try:
            session_string = decrypt(row["session_enc"])
        except DecryptionError as exc:
            return False, str(exc)
        try:
            client = await self.client_factory(session_string)
            if not await client.is_user_authorized():
                await client.disconnect()
                await self.db.execute("UPDATE fleet_accounts SET session_enc=NULL, enabled=0, note=? WHERE id=?", ("session باطل شد", account_id))
                return False, "این session دیگر معتبر نیست (از اکانت خارج شده)؛ دوباره وارد شو."
            me = await client.get_me()
        except (RPCError, AuthKeyUnregisteredError, ConnectionError, OSError) as exc:
            return False, f"اتصال برقرار نشد: {exc.__class__.__name__}"
        if int(me.id) != int(row["tg_user_id"]):
            await client.disconnect()
            return False, "session متعلق به همین اکانت نیست."
        db = Database(self._db_path(row["tg_user_id"]))
        await db.connect()
        await self._launch(account_id, "licensed", row["label"] or str(me.id), int(me.id), client, db, True, int(row["license_id"]))
        await self.db.execute("UPDATE fleet_accounts SET enabled=1, note=NULL, last_active_at=? WHERE id=?", (time.time(), account_id))
        return True, row["label"] or str(me.id)

    async def stop_account(self, account_id: int, *, logout: bool = False) -> bool:
        async def go() -> bool:
            async with self._locks[account_id]:
                return await self._stop_impl(account_id, logout=logout)
        return await spawn_detached(go())

    def request_stop(self, account_id: int, *, logout: bool = False) -> None:
        """Fire-and-forget stop - safe to call from inside that account's own command handler."""
        spawn_detached(self.stop_account(account_id, logout=logout))

    async def _stop_impl(self, account_id: int, *, logout: bool) -> bool:
        rt = self.runtimes.pop(account_id, None)
        if rt is None:
            return False
        try:
            if logout:
                await rt.client.log_out()
            else:
                await rt.client.disconnect()
        except Exception as exc:  # noqa: BLE001
            log.warning("stopping account %s: %s: %s", account_id, exc.__class__.__name__, exc)
            try:
                await rt.client.disconnect()
            except Exception:  # noqa: BLE001
                pass
        await self._cancel_tasks(account_id)
        if rt.owns_db:
            try:
                await rt.db.close()
            except Exception:  # noqa: BLE001
                pass
        return True

    async def stop_all(self) -> None:
        for account_id in list(self.runtimes):
            await self.stop_account(account_id)

    async def resume_all(self) -> list[tuple[int, bool, str]]:
        out = []
        for row in await self.db.fetchall("SELECT id FROM fleet_accounts WHERE enabled=1 AND session_enc IS NOT NULL ORDER BY id"):
            ok, msg = await self.start_account(row["id"])
            out.append((row["id"], ok, msg))
        return out

    # ------------------------------------------------------------------ user-facing switches
    async def set_enabled(self, account_id: int, enabled: bool) -> tuple[bool, str]:
        """The account owner's own on/off switch. Off keeps the saved session (no new login needed)."""
        await self.db.execute("UPDATE fleet_accounts SET enabled=? WHERE id=?", (1 if enabled else 0, account_id))
        if enabled:
            return await self.start_account(account_id)
        await self.stop_account(account_id)
        return True, "خاموش شد."

    async def _logout_stored(self, row: Any) -> None:
        """Terminate the Telegram session of an account that is not running right now."""
        if not row["session_enc"]:
            return
        try:
            client = await self.client_factory(decrypt(row["session_enc"]))
            try:
                await client.log_out()
            finally:
                await client.disconnect()
        except Exception as exc:  # noqa: BLE001
            log.warning("logout of stored session failed: %s", exc.__class__.__name__)

    async def retire_account(self, account_id: int) -> None:
        """Full removal: stop, terminate the Telegram session, forget the row (data file is kept)."""
        row = await self.db.fetchone("SELECT * FROM fleet_accounts WHERE id=?", (account_id,))
        if row is None:
            return
        if self.is_running(account_id):
            await self.stop_account(account_id, logout=True)
        else:
            await self._logout_stored(row)
        await self.db.execute("DELETE FROM fleet_accounts WHERE id=?", (account_id,))

    # ------------------------------------------------------------------ licenses
    async def delete_license_and_account(self, license_id: int) -> bool:
        acc = await self.account_for_license(license_id)
        if acc is not None:
            await self.retire_account(acc["id"])
        return await licenses.delete_license(self.db, license_id)

    async def suspend_license(self, license_id: int, flag: bool) -> bool:
        ok = await licenses.set_suspended(self.db, license_id, flag)
        acc = await self.account_for_license(license_id)
        if ok and acc is not None:
            if flag:
                await self.stop_account(acc["id"])
            elif acc["enabled"] and acc["session_enc"]:
                await self.start_account(acc["id"])
        return ok

    async def enforce_licenses(self, now: float | None = None) -> list[Notice]:
        """Called every few seconds: expired licenses are retired, suspended ones are switched off."""
        notices: list[Notice] = []
        for lic in await licenses.due_for_expiry(self.db, now):
            acc = await self.account_for_license(lic["id"])
            if acc is not None:
                await self.retire_account(acc["id"])
            await licenses.mark_expiry_handled(self.db, lic["id"])
            notices.append(Notice(
                lic["bound_user_id"], "expired",
                "⏰ لایسنس شما تمام شد؛ سلف روی اکانت خاموش و session از تلگرام خارج شد.\nبرای ادامه یک لایسنس جدید بفرست."))
        for rt in list(self.runtimes.values()):
            if rt.license_id is None:
                continue
            lic = await licenses.get_license(self.db, rt.license_id)
            if lic is None:
                await self.stop_account(rt.account_id)
            elif licenses.state(lic, now) == licenses.SUSPENDED:
                await self.stop_account(rt.account_id)
                notices.append(Notice(lic["bound_user_id"], "suspended", "⏸ لایسنس شما توسط مالک خاموش شد؛ سلف روی اکانت متوقف است."))
        return notices
