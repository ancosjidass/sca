from __future__ import annotations

import functools
import logging
from typing import Any

from telethon import events

from core.accountctx import CURRENT_ACCOUNT
from core.permissions import explain_error

log = logging.getLogger(__name__)


def is_command_builder(builder: Any) -> bool:
    """A NewMessage handler that has a `pattern` is a *command* handler."""
    return isinstance(builder, events.NewMessage) and builder.pattern is not None


def install_handler_guard(client: Any) -> None:
    """Wrap `client.on` so that every registered handler is

    1. owner-only when it is a command (event.out must be True). Even if a module forgets
       `outgoing=True`, a command typed by somebody else can never run on this account.
    2. exception-safe: a failing handler is logged and, for commands, the owner gets an
       explicit "❌ ..." answer instead of silence.
    """
    if getattr(client, "_hapoyi_guard_installed", False):
        return
    original_on = client.on

    def on(builder: Any = None):
        register = original_on(builder)
        is_cmd = is_command_builder(builder)
        is_new_message = isinstance(builder, events.NewMessage)

        def wrap(fn):
            @functools.wraps(fn)
            async def guarded(event):
                CURRENT_ACCOUNT.set(getattr(client, "_hapoyi_account_id", None))
                if is_cmd and not getattr(event, "out", False):
                    return None
                if is_new_message and getattr(event, "out", False):
                    # A message that the Echo feature sent on somebody else's behalf (`اکو ...`) must never be
                    # interpreted as if the owner had typed it (otherwise "اکو .ban" would run .ban).
                    is_echo = getattr(client, "_hapoyi_echo_check", None)
                    if is_echo is not None:
                        try:
                            if is_echo(event):
                                return None
                        except Exception:  # noqa: BLE001
                            log.exception("echo check failed")
                try:
                    return await fn(event)
                except events.StopPropagation:
                    raise
                except Exception as exc:  # noqa: BLE001
                    log.exception("handler %s failed", getattr(fn, "__name__", fn))
                    if is_cmd:
                        try:
                            await event.reply("❌ انجام نشد: " + explain_error(exc))
                        except Exception:  # noqa: BLE001
                            pass
                    return None

            register(guarded)
            return fn

        return wrap

    client.on = on
    client._hapoyi_guard_installed = True
