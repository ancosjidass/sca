"""The phone / code / 2FA exchange, split into steps so a chat state machine (core/control_bot.py)
can drive it, and kept free of any chat glue so it can be unit tested with a fake client."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from telethon.errors import (
    FloodWaitError,
    PasswordHashInvalidError,
    PhoneCodeExpiredError,
    PhoneCodeInvalidError,
    PhoneNumberBannedError,
    PhoneNumberInvalidError,
    RPCError,
    SessionPasswordNeededError,
)


@dataclass
class LoginResult:
    ok: bool
    session_string: str | None = None
    phone: str | None = None
    error: str | None = None
    needs_password: bool = False


def _flood(exc: FloodWaitError) -> str:
    return f"تلگرام محدودیت گذاشته: {exc.seconds} ثانیه صبر کن."


class LoginSession:
    """One login attempt. `client` only needs send_code_request / sign_in / session.save."""

    def __init__(self, client: Any, phone: str):
        self.client = client
        self.phone = phone

    async def send_code(self) -> str | None:
        """Returns an error text, or None when the code was sent."""
        try:
            await self.client.send_code_request(self.phone)
        except PhoneNumberInvalidError:
            return "شماره نامعتبر است (با کد کشور، بدون + یا 00)."
        except PhoneNumberBannedError:
            return "این شماره در تلگرام مسدود است."
        except FloodWaitError as exc:
            return _flood(exc)
        except RPCError as exc:
            return f"تلگرام خطا داد: {exc.__class__.__name__}"
        return None

    def _done(self) -> LoginResult:
        return LoginResult(True, session_string=self.client.session.save(), phone=self.phone)

    async def submit_code(self, code: str) -> LoginResult:
        try:
            await self.client.sign_in(self.phone, code=code)
        except SessionPasswordNeededError:
            return LoginResult(False, needs_password=True)
        except (PhoneCodeInvalidError, PhoneCodeExpiredError):
            return LoginResult(False, error="کد اشتباه یا منقضی شده است.")
        except FloodWaitError as exc:
            return LoginResult(False, error=_flood(exc))
        except RPCError as exc:
            return LoginResult(False, error=f"تلگرام خطا داد: {exc.__class__.__name__}")
        return self._done()

    async def submit_password(self, password: str) -> LoginResult:
        try:
            await self.client.sign_in(password=password)
        except PasswordHashInvalidError:
            return LoginResult(False, error="رمز دومرحله‌ای اشتباه است.")
        except FloodWaitError as exc:
            return LoginResult(False, error=_flood(exc))
        except RPCError as exc:
            return LoginResult(False, error=f"تلگرام خطا داد: {exc.__class__.__name__}")
        return self._done()


async def run_login(
    client: Any,
    phone: str,
    ask_code: Callable[[], Awaitable[str]],
    ask_password: Callable[[], Awaitable[str]],
) -> LoginResult:
    """Callback-style driver (kept for scripts/tests): same steps as LoginSession."""
    session = LoginSession(client, phone)
    err = await session.send_code()
    if err:
        return LoginResult(False, error=err)
    result = await session.submit_code(await ask_code())
    if result.needs_password:
        return await session.submit_password(await ask_password())
    return result
