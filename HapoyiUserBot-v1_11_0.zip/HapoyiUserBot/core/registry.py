from __future__ import annotations

import importlib
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


@dataclass
class ModuleInfo:
    name: str
    description: str
    loaded: bool = False
    error: str | None = None


class ModuleRegistry:
    def __init__(self, client: Any, db: Any):
        self.client = client
        self.db = db
        self.modules: dict[str, ModuleInfo] = {}

    async def load_all(self, package_name: str = "modules") -> None:
        package = importlib.import_module(package_name)
        base = Path(package.__file__).parent
        for path in sorted(base.rglob("*.py")):
            if path.name.startswith("_"):
                continue
            relative = path.relative_to(base).with_suffix("")
            module_name = package_name + "." + ".".join(relative.parts)
            name = relative.parts[-1]
            info = ModuleInfo(name, module_name)
            self.modules[name] = info
            try:
                module = importlib.import_module(module_name)
                setup = getattr(module, "setup", None)
                if setup is None:
                    continue
                result = setup(self.client, self.db)
                if hasattr(result, "__await__"):
                    await result
                info.loaded = True
                log.info("loaded module: %s", module_name)
            except Exception as exc:
                info.error = f"{exc.__class__.__name__}: {exc}"
                log.exception("module failed: %s", module_name)

    def summary(self) -> str:
        loaded = sum(1 for x in self.modules.values() if x.loaded)
        failed = sum(1 for x in self.modules.values() if x.error)
        return f"modules={len(self.modules)} loaded={loaded} failed={failed}"
