from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from typing import Any

log = logging.getLogger(__name__)


class Runtime:
    def __init__(self) -> None:
        self.tasks: set[asyncio.Task[Any]] = set()
        self.games: dict[tuple[int, int], asyncio.Task[Any]] = {}
        self.job_locks = defaultdict(asyncio.Lock)

    def create_task(self, coro: Any, *, name: str | None = None) -> asyncio.Task[Any]:
        task = asyncio.create_task(coro, name=name)
        self.tasks.add(task)
        task.add_done_callback(self.tasks.discard)
        return task

    async def cancel_game(self, owner_id: int, chat_id: int) -> bool:
        task = self.games.pop((owner_id, chat_id), None)
        if task is None:
            return False
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        return True

    async def shutdown(self) -> None:
        for task in list(self.tasks):
            task.cancel()
        if self.tasks:
            await asyncio.gather(*self.tasks, return_exceptions=True)
