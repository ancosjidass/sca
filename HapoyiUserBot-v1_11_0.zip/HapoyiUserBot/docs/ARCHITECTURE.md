# Hāpoyi Architecture

## Layers

`main.py` starts `core.bootstrap.start()`.

`core.bootstrap` loads environment settings, opens SQLite, initializes the Telegram client, discovers Python modules recursively and then starts the client loop.

`core.database.Database` serializes SQLite operations behind an asyncio lock. The database is intentionally boring: SQLite gives durable local state without another daemon. WAL is enabled for better read/write concurrency and a five-second busy timeout is configured.

`core.permissions` is the policy boundary for group administration. Command modules should call `require_group_right()` before actions that need administrator rights. Target resolution supports Reply, username and numeric IDs.

`providers/` is the external-data boundary. Crypto quotes and FX are not embedded into the command handlers. That makes provider replacement possible without rewriting Telegram event logic.

`modules/` contains user-visible capabilities. Each module exposes `setup(client, db)` and registers its event handlers. A failure in one module is recorded and does not prevent the loader from reporting the rest of the module set.

## State model

Persistent features use explicit tables or structured key/value state. Feature switches are scoped where practical: AutoBan and AutoDelete are per chat; notes and alerts are per owner; chat automation has per-chat scope.

## Network model

The project is not a generic networking framework. External HTTP is used only in provider modules. Telegram API traffic is performed by Telethon. No arbitrary URL is accepted as executable code and no module loader downloads code at runtime.

## Rate-limiting model

Telegram can return FloodWait and similar RPC errors when an action is repeated too often. Long-running automated loops must stay bounded and should fail closed rather than retry indefinitely. The game engine therefore caps automated rolls at 300 and uses a pause between attempts.

## Data handling

Session files, API credentials, database files, downloaded media and `.env` files are excluded by `.gitignore`. The packaged ZIP intentionally contains `.env.example`, never a live session or token.
