# Hāpoyi UserBot v1.10.0 — Switchboard (multi-account control bot)

## What changed
The userbot account is no longer fixed by `SESSION` in `.env`. A permanent **control bot**
(`core/control_bot.py`, same `BOT_TOKEN` as the Assistant panel) now owns which account, if any, is
active - switch it from Telegram itself, no `.env` edits, no restart.

- `/login` in the control bot: you type your own phone number, the code Telegram sends you, and your
  2FA password if you have one - exactly like logging into Telegram normally, just through this bot.
  The resulting session is encrypted (`core/crypto_store.py`) and stored in the database.
- `/accounts`: buttons to activate / deactivate ("خروج (بدون حذف)" - disconnects but keeps the saved
  session, so reactivating never asks for a new code) / forget completely (real Telegram logout).
- `/managers`: owner-only. `HAPOYI_OWNER_ID` is always allowed and can never be removed. Add anyone
  else by forwarding one of their messages to the bot, or sending their numeric id; remove with
  `/managers del <id>`. Nobody outside this list can see or touch any account.
- Fresh install: nothing is active until you run `/login` yourself - the bot does not log into any
  account on its own.
- Upgrading from an older release: the old fixed `SESSION` is imported once as an account named
  «اصلی» and activated automatically, so nothing breaks.
- Restarting the process (e.g. a VPS reboot) resumes whichever account was last active; after
  "خروج (بدون حذف)" it stays off across restarts too.
- Inside the running userbot: `.whoami` shows which Switchboard account this is, `.deactivate` logs
  it out from inside the chat itself (same as the control bot's button).

## New files
`core/switchboard.py`, `core/control_bot.py`, `core/login_flow.py`, `core/crypto_store.py`,
`core/managers.py`, `modules/health.py` (moved `.health`/`.modules` here), `modules/account.py`.

## Changed
`core/bootstrap.py` now starts the control bot first; a userbot `TelegramClient` is created by
`core/switchboard.py` only once an account is activated, instead of unconditionally at boot.

## Security note
Anyone in `/managers` can read/activate/deactivate/forget every stored account from this bot. Only
add people you'd trust with full control of that Telegram account - the whole point of this feature
is that nobody *outside* that list can touch it, not that everyone inside it is restricted further.
