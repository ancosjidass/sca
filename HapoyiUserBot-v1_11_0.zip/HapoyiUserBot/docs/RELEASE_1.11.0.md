# Hāpoyi UserBot v1.11.0 — Fleet (multi-account + licenses)

## 1. Unlimited concurrent accounts (no switching)
`core/switchboard.py` and the manager list are gone. `core/fleet.py` runs **any number of accounts at the same
time**:
* account **0 = main** (from `.env` `SESSION`, no license needed);
* every other account has its **own database** (`data/accounts/u<telegram id>.db`), its own module instances and
  its own background tasks, so filters / AFK / repeat jobs / echo lists of two accounts never mix, even in the same chat;
* stopping an account disconnects it **and cancels every task it started** (`core/accountctx.py` tags tasks per account);
* permission / activity / rate-limit caches are per client.

## 2. Licenses (replaces the admin / manager panel)
The **control bot** (`BOT_TOKEN`) is the only entrance.

**Owner** (`HAPOYI_OWNER_ID`, or the main account): `/start` → panel
* 🎫 create a license: duration `12h` / `3d` / `1m` (month = 30 days) or quick buttons, optional name; the code
  (`HPY-XXXX-XXXX-XXXX`) is shown **once** — only its SHA-256 is stored;
* 📋 list → per license: state, remaining time, owner of the license, account status;
  **⏸ switch off / ▶️ switch on** (account stops, session kept) and **🗑 delete** (account stops, Telegram session is
  terminated, owner notified);
* the same from the main account: `.lic new 3d [name]`, `.lic list`, `.lic off|on|del <id>` (code goes to Saved Messages).

**Everybody else**: the bot asks for a license first. Wrong codes are throttled (5 misses → 15 min block).
A valid license binds to that Telegram user and its clock starts. Then:
* 🔑 login (phone → code → 2FA). The login is accepted **only for the same account that is chatting with the bot**,
  so a stranger can never put somebody else's number on your server. Code / password messages are deleted from the chat;
* the user can **⏸ switch off**, **▶️ switch on** (no new code needed) or **🚪 log out** from the bot, or type `.deactivate`
  inside the account;
* when the time ends the account stops, its Telegram session is **logged out**, the stored session is wiped and
  both the user and the owner get a message (checked every 5 s). Unredeemed licenses expire after `LICENSE_UNUSED_DAYS`.
* the main account can never be deactivated.

## 3. `.protect on | off | status` (Account Protect)
While ON, every **new** login is terminated immediately (instant via Telegram's `updateNewAuthorization` push,
plus a polling safety net). Sessions that existed when you switched it on — and sessions created while it was OFF —
are never touched, even after switching it on again (ON takes a fresh snapshot). The bot's own session is never
touched. Every kill is logged to Saved Messages (device, app, IP, country). Telegram only lets a session older than
24 h terminate others; `status`/`on` warns you if the bot's session is younger.

## 4. `.mesdel` and `.reactdel`
* `.mesdel all|N` — in the chat as before; **`.mesdel all|N <chat id | @username>`** works from anywhere (no need to open the chat).
* `.reactdel <N|all> [chat id | @username]` — removes **your** reactions from the last N messages of that chat
  (empty chat = current chat; `all` scans up to `REACTDEL_MAX`).

## Upgrade notes
* New `.env` keys: `LICENSE_UNUSED_DAYS`, `PROTECT_POLL_SECONDS`, `REACTDEL_MAX` (see `.env.example`).
* The old Switchboard tables are no longer used; accounts added through v1.10.0's `/login` must log in again
  with a license. Your main account keeps running from `SESSION` and keeps all its data.
* `ui.py` now shares the control bot (one `BOT_TOKEN`, one session); `.menu` works for every running account's owner.
