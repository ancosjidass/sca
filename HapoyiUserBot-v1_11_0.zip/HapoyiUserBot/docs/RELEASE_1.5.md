# v1.5.0 — LinkGuard & Stability

- Confirmed Casino/Slot keeps deleting failed dice rolls; Smart/Hooshmad mode remains rate-aware and stops on Telegram flood conditions.
- Added LinkGuard modes: `all` links or Telegram invite links only.
- Added configurable immediate actions: delete, warn, mute, ban.
- Added rolling-window escalation: `.linkguard threshold 100 10m ban`.
- Detected links are always deleted when LinkGuard is enabled; escalation action occurs at the configured threshold.
- Administrators are exempt from automatic LinkGuard actions.
- Fixed Rate Guard's `monotonic` reference.
- Added unit coverage for URL detection and rolling link counters.

The release does not attempt to bypass Telegram anti-spam or anti-flood systems.
