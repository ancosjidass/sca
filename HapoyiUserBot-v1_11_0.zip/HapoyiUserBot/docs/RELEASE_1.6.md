# Hāpoyi UserBot v1.6.0 — Private Audit Logger

## Added
- Separate Audit Bot destination with its own bot token/session.
- Per-chat opt-in audit configuration.
- New-message logging.
- Edit logging with before/after text when the original was previously observed.
- Optional deletion logging.
- SQLite persistence for observed message text and audit configuration.
- Queue + batching + flood/slow-mode backoff for the Audit Bot.
- Commands: `.audit on/off/list/status/purge/test`.

## Safety
The module does not implement anti-ban, anti-report, rate-limit bypass, stealth, proxy rotation, or enforcement-evasion behavior. It only reduces unnecessary log traffic using batching and backoff.
