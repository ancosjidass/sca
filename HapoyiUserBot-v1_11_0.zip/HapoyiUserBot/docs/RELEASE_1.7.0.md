# Hāpoyi UserBot v1.7.0

## Prices (root cause of "dollar = 133")
The old code asked a *reference* FX API (open.er-api.com) which returns the official IRR rate, not the market.
Now: `providers/iran.py` - USD/EUR from TGJU (free market), fallback Nobitex USDT/IRT, Wallex USDT/TMN;
crypto from Nobitex (USDT + Toman + 24h in one call) -> Binance -> CoinGecko; cache 4s (`PRICE_CACHE_SECONDS`).
Implausible values are rejected and a failure is shown as an error - a wrong number is never invented.
`.pricesrc` shows which source answers from your server (with latency). `IRAN_FX_URL` is still honoured first.

## Friends / enemies
- Answers are now real replies to the sender's message.
- `.friend|.enemy add|del|on|off` work with Reply (and `on|off` without target = whole list).
- `.relation clear [friend|enemy]` now empties the pool for good (no re-seeding); `.relation reset` restores defaults.

## Games
- `.casino ...`, `.dice/.dart/.bowling/.basket/.football`, `.slots`: typed as a reply -> every roll and the result
  reply to that message; otherwise plain messages.

## Channels
- `.comment first <channel> <text>`: automatic first comment under every new post (albums once), needs an open
  comment section and membership in the discussion group. `.comment first off|on|del <channel>`, `.comment first list`.

## AutoReact
- Per chat AND per user: `.autoreact 🤣` as a reply = only that person in this chat; without reply = whole chat.
  `on|off|del [user|all]`, `list`, `clear`. The emoji is tested immediately (chats may allow only some reactions).

## Profile clock
- `.profileclock name on|off`: Last name = clock (`Amiri ۸:۳۶`, flips every minute), original restored on `off`.
  `bio on|off`, `on|off` (both), `digits fa|en`, `status`. Bio is restored too on `off`.

## Clone
- `.clone` (reply) / `.clone @user|id [nouser]`: copies name, bio, profile photo and username; `.unclone` restores everything.
  Username: `mol` -> `mol_baraman`, `mol10`, `mol11`...; no username -> `baraman`, `baraman1`... (`CLONE_SUFFIX`).
