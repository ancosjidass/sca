# Hāpoyi UserBot v1.7.1

## Moderation is now rights-based (not "is he an admin?")
- `.ban .mute .kick .unban .unmute`: no more "target is admin" refusal. The request is sent and Telegram decides;
  failures are explained: «شما دسترسی ندارید», «شما دسترسی بالاتر از او ندارید», «او مالک گروه است».
- `.warn`: needs Ban Users and the ability to act on the target (`can_edit`: creator / the admin who promoted him).
  Otherwise no warning is recorded and the answer is «شما دسترسی ندارید».
- `.filter scope normal|all`, `.linkguard scope normal|all` (also `rate_scope`, `flood_scope` settings):
  normal = admins exempt (default), all = admins' messages are removed too.

## New
- `.promote [user]` (Pin + Delete + Invite + Ban; only rights you hold yourself), `.demote [user]`.
- `.banned users`, `.mute users` (with remaining time).
- `.mesdel all` / `.mesdel <n>`: delete your own messages in this chat.
- `.selfdestruct list | del <id|all> | now <id|all>`; jobs are stored in the DB (survive restarts); `.delafter` shares them.
- `.gif`: reply to photo (3s zoom loop) / video / video-note / video-sticker -> real Telegram GIF (needs ffmpeg).
- `.sticker` no longer leaves temp files behind.
- Optional `NAVASAN_API_KEY` price source; full `.env.example`.
