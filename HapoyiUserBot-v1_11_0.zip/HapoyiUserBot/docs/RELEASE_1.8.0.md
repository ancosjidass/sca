# Hāpoyi UserBot v1.8.0

## Repeat jobs
`.every 5m <text>` / `.time <text> 5m` / `.loop 5m <text>`: repeats in THIS chat (as a reply -> replies to that message).
`x10` = only 10 times. `.every list [all]`, `pause|resume <id|all>`, `del <id|all|allchats>`.
DB-backed (survive restarts), min interval 10s (`REPEAT_MIN_SECONDS`), permanent errors disable the job and keep the reason.
`.time Asia/Tehran` is still the clock command.

## Tag
`.tag [N]`, `.tag admin [N]`, `.tag normal [N]`, `.tag stop` (also `.تگ`, `ادمین`, `عادی`): admin/owner only, max 300,
most active first (message count in the last TAG_SCAN_LIMIT messages), small groups just tag everybody, long lists are split
into several messages (TAG_PER_MESSAGE each).

## Ten power tools
`.later` (Telegram-side scheduled messages + list/del), `.top`, `.export`, `.slowmode`, `.lock/.unlock/.lock status`,
`.delall`, `.poll`, `.qr` (needs `qrcode[pil]`, now in requirements.txt), `.pass`, `.link`.
Upgraded: `.save` (copies protected content), `.readall all`.
