# Hāpoyi UserBot v1.9.0

## Echo
Per-chat allow list (`.echo add|del|list|clear`). An allowed user writes `اکو <text>` / `echo <text>` (text only):
your account posts the text (as a reply to the message he replied to, otherwise plain), deletes his trigger message when
you have Delete Messages, and ~1s later edits it to `اکو از <mention>` (`.echo edit off` to keep the raw text).
Not on the list = ignored silently. Echoed messages are remembered (DB): your own commands never fire on them
(`اکو .ban` does nothing) and `.msginfo` shows `Echo: بله` + who caused it.

## Daily helpers
`.todo`, `.conv` (live USD/EUR/Toman/crypto), `.ping` (RTT + uptime + versions), `.copy [me|@chat]`, `.backup` (DB snapshot -> Saved Messages).

## Alerts
`.alert usd >= 280000` now works for USD/EUR in Toman (was crypto-only and silently never fired).
