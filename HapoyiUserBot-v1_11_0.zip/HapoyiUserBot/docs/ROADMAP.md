# Hāpoyi Roadmap

## Delivered — 1.4.0 GameForge
- Full 64-outcome 🎰 decoder and target engine.
- Exact combinations, count constraints and positional predicates.
- Smart rate-aware search for Telegram dice outcomes.
- Local mini-games and persistent scores/leaderboard.

## Next
- More inline controls for GameForge settings.
- Per-chat game policies and configurable score weights.
- Additional offline mini-games that do not generate Telegram message traffic.
- Expanded analytics and export.
