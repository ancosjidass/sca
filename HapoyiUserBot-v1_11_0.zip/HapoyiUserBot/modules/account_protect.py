"""Account Protect (`.protect on|off|status`) - an anti-hijack switch.

While it is ON, every NEW login (a session that was not there when you switched it on) is terminated
right away. Sessions that already existed when you switched it on, and sessions that were created
while it was OFF, are never touched - switching it ON again just takes a fresh snapshot of what is
there at that moment and trusts all of it. The session this bot itself runs on is never touched.

Notes
* Telegram only lets a session terminate others when it is older than 24 hours
  (FRESH_RESET_AUTHORISATION_FORBIDDEN otherwise); `.protect status` tells you when that applies.
* Detection is instant (Telegram pushes `updateNewAuthorization`) with a polling safety net.
* Every kill is written to your Saved Messages (device, app, IP, country).
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import time

from telethon import events
from telethon.errors import FloodWaitError, RPCError
from telethon.tl.functions.account import GetAuthorizationsRequest, ResetAuthorizationRequest
from telethon.tl.types import UpdateNewAuthorization

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
POLL_SECONDS = max(3.0, float(os.getenv("PROTECT_POLL_SECONDS", "6") or 6))
KV_KEY = "account_protect"
FRESH_SECONDS = 24 * 3600


def _describe(auth) -> str:
    bits = [getattr(auth, "device_model", None), getattr(auth, "platform", None), getattr(auth, "app_name", None)]
    where = " / ".join(x for x in (getattr(auth, "country", None), getattr(auth, "ip", None)) if x)
    return " · ".join(x for x in bits if x) + (f"\n📍 {where}" if where else "")


def new_sessions(auths, known: set[int]) -> list:
    """Sessions that must be terminated: not the current one, not in the trusted snapshot."""
    return [a for a in auths if not getattr(a, "current", False) and int(a.hash) not in known]


def setup(client, db):
    wake = asyncio.Event()
    memo: dict[str, object] = {"warned": set()}

    async def load() -> dict:
        data = await db.get_kv(KV_KEY, {}) or {}
        return {"enabled": bool(data.get("enabled")), "known": [int(x) for x in data.get("known", [])],
                "since": data.get("since"), "killed": int(data.get("killed", 0)), "recent": list(data.get("recent", []))}

    async def save(state: dict) -> None:
        await db.set_kv(KV_KEY, state)

    async def sessions():
        return (await client(GetAuthorizationsRequest())).authorizations

    async def check() -> None:
        state = await load()
        if not state["enabled"]:
            return
        known = set(state["known"])
        for auth in new_sessions(await sessions(), known):
            h = int(auth.hash)
            try:
                await client(ResetAuthorizationRequest(hash=h))
            except FloodWaitError as exc:
                await asyncio.sleep(min(exc.seconds, 30))
                continue
            except RPCError as exc:
                if h not in memo["warned"]:
                    memo["warned"].add(h)
                    reason = ("سشن این بات کمتر از ۲۴ ساعت عمر دارد و تلگرام اجازهٔ بستن سشن‌های دیگر را نمی‌دهد."
                              if "FRESH" in exc.__class__.__name__.upper() or "FRESH" in str(exc).upper() else exc.__class__.__name__)
                    await client.send_message("me", f"⚠️ سشن جدید شناسایی شد ولی بسته نشد:\n{_describe(auth)}\n{reason}")
                continue
            state["killed"] += 1
            state["recent"] = (state["recent"] + [{"t": int(time.time()), "d": _describe(auth)}])[-10:]
            await save(state)
            try:
                await client.send_message("me", f"🛡 Account Protect: یک سشن جدید بلافاصله بسته شد.\n{_describe(auth)}")
            except Exception:  # noqa: BLE001
                pass

    async def loop():
        while True:
            try:
                await asyncio.wait_for(wake.wait(), POLL_SECONDS)
            except asyncio.TimeoutError:
                pass
            wake.clear()
            try:
                await check()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - never let the guard loop die
                log.warning("account protect check failed: %s: %s", exc.__class__.__name__, exc)

    @client.on(events.Raw(UpdateNewAuthorization))
    async def on_new_login(update):
        await asyncio.sleep(1.0)  # let the new session show up in the list
        wake.set()

    asyncio.create_task(loop())

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}(?:account\s+)?protect(?:\s+(on|off|status))?$"))
    async def protect_cmd(event):
        arg = (event.pattern_match.group(1) or "status").lower()
        state = await load()
        if arg == "on":
            auths = await sessions()
            state.update(enabled=True, known=[int(a.hash) for a in auths if not a.current], since=int(time.time()))
            await save(state)
            memo["warned"] = set()
            cur = next((a for a in auths if a.current), None)
            young = cur is not None and cur.date_created and time.time() - cur.date_created.timestamp() < FRESH_SECONDS
            text = (f"🛡 Account Protect روشن شد.\n{len(state['known'])} سشن موجود فعلی مورد اعتماد ثبت شد؛ "
                    "از این لحظه هر لاگین جدید فوراً بسته می‌شود.")
            if young:
                text += "\n⚠️ سشن این بات هنوز کمتر از ۲۴ ساعت عمر دارد؛ تلگرام تا آن موقع اجازهٔ بستن سشن‌های دیگر را نمی‌دهد."
            return await event.reply(text)
        if arg == "off":
            state["enabled"] = False
            await save(state)
            return await event.reply("🔓 Account Protect خاموش شد. سشن‌هایی که از حالا بسازند دست نخورده می‌مانند، "
                                     "حتی اگر دوباره روشنش کنی.")
        lines = [f"🛡 Account Protect: {'🟢 روشن' if state['enabled'] else '⚪️ خاموش'}"]
        if state["enabled"] and state["since"]:
            lines.append(f"از {time.strftime('%Y-%m-%d %H:%M', time.localtime(state['since']))} · {len(state['known'])} سشن مورد اعتماد")
        lines.append(f"تعداد سشن‌های بسته‌شده: {state['killed']}")
        for r in state["recent"][-3:]:
            lines.append("• " + time.strftime("%m-%d %H:%M", time.localtime(r["t"])) + " — " + r["d"].replace("\n", " "))
        lines.append(f"`{PREFIX}protect on|off|status`")
        await event.reply("\n".join(lines))
