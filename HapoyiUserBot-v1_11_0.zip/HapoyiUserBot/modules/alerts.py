from __future__ import annotations

import asyncio
import operator
import os
import re
from datetime import datetime, timezone

from core.identity import my_id
from telethon import events

from providers.crypto import MarketProvider
from providers.iran import parse_number, shared
from utils.formatting import fmt_money

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
OPS = {">": operator.gt, "<": operator.lt, ">=": operator.ge, "<=": operator.le, "=": operator.eq}
FIAT = {"usd": "USD", "دلار": "USD", "dollar": "USD", "eur": "EUR", "یورو": "EUR", "euro": "EUR"}


def setup(client, db):
    provider = MarketProvider(cache_seconds=10)
    rates = shared()

    async def current_value(symbol: str):
        """USD/EUR -> (Toman, label, 'تومان'); crypto -> (USD price, symbol, '$')."""
        if symbol == "USD":
            return (await rates.usd_toman()).toman, "💵 دلار", "تومان"
        if symbol == "EUR":
            return (await rates.eur_toman()).toman, "💶 یورو", "تومان"
        q = await provider.quote(symbol)
        return q.usd, q.symbol, "$"

    def money(value: float, unit: str) -> str:
        return fmt_money(value, 0 if unit == "تومان" else 4)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}alert\s+(\S+)\s*(>=|<=|>|<|=)\s*([0-9۰-۹.,٬]+)$"))
    async def alert_add(event):
        raw_symbol, op = event.pattern_match.group(1), event.pattern_match.group(2)
        try:
            target = parse_number(event.pattern_match.group(3))
        except ValueError:
            return await event.reply("❌ عدد نامعتبر است. مثال: `.alert usd >= 280000`")
        symbol = FIAT.get(raw_symbol.lower())
        if not symbol and provider.resolve(raw_symbol):
            symbol = raw_symbol.upper()
        if not symbol:
            return await event.reply("❌ ارز ناشناخته است. مثال‌ها: usd، eur، btc، eth، sol، ton، usdt")
        alert_id = await db.insert(
            "INSERT INTO price_alerts(owner_id,chat_id,symbol,operator,target,created_at) VALUES(?,?,?,?,?,?)",
            (await my_id(client), event.chat_id, symbol, op, target, datetime.now(timezone.utc).isoformat()),
        )
        unit = "تومان" if symbol in {"USD", "EUR"} else "دلار"
        try:
            value, _, _ = await current_value(symbol)
            now_txt = f"\nالان: {money(value, unit)} {unit}"
        except Exception:  # noqa: BLE001 - price source is down right now; the alert is still saved
            now_txt = "\n(قیمت فعلی در دسترس نبود؛ هشدار ثبت شد.)"
        await event.reply(f"🔔 Alert #{alert_id} ثبت شد: {symbol} {op} {money(target, unit)} {unit}{now_txt}\nبعد از اولین رسیدن، همین‌جا پیام می‌دهم.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}alerts$"))
    async def alerts(event):
        rows = await db.fetchall("SELECT id,symbol,operator,target,enabled,last_value FROM price_alerts WHERE owner_id=? ORDER BY id DESC", (await my_id(client),))
        if not rows:
            return await event.reply("🔔 Alert نداری.")
        await event.reply("🔔 Alerts\n" + "\n".join(
            f"#{r['id']} {r['symbol']} {r['operator']} {fmt_money(r['target'], 0 if r['symbol'] in {'USD', 'EUR'} else 4)} {'ON' if r['enabled'] else 'OFF'}"
            for r in rows))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}alertdel\s+(\d+)$"))
    async def alert_del(event):
        await db.execute("DELETE FROM price_alerts WHERE id=? AND owner_id=?", (int(event.pattern_match.group(1)), await my_id(client)))
        await event.reply("✅ Alert حذف شد.")

    async def loop():
        while True:
            try:
                rows = await db.fetchall("SELECT id,owner_id,chat_id,symbol,operator,target FROM price_alerts WHERE enabled=1")
                for row in rows:
                    try:
                        value, label, unit = await current_value(row["symbol"])
                        if OPS[row["operator"]](value, row["target"]):
                            await client.send_message(
                                row["chat_id"],
                                f"🚨 Price Alert\n{label} = {money(value, unit)} {unit}\n🎯 شرط: {row['operator']} {money(row['target'], unit)}\n"
                                f"🕐 {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",
                            )
                            await db.execute("UPDATE price_alerts SET enabled=0,last_value=? WHERE id=?", (value, row["id"]))
                    except Exception:  # noqa: BLE001 - one bad symbol/source must not stop the others
                        continue
            except Exception:  # noqa: BLE001
                pass
            await asyncio.sleep(15)

    asyncio.create_task(loop())
