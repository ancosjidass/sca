from __future__ import annotations

import asyncio
import html
import logging
import os
import re
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from telethon import TelegramClient, events
from telethon.errors import FloodWaitError, RPCError, SlowModeWaitError

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
OWNER_ID = int(os.getenv("HAPOYI_OWNER_ID", "0") or 0)
AUDIT_BOT_TOKEN = os.getenv("AUDIT_BOT_TOKEN", "").strip()
AUDIT_BOT_SESSION = os.getenv(
    "AUDIT_BOT_SESSION",
    str(Path(__file__).resolve().parents[1] / "data" / "hapoyi_audit_bot"),
)
DEFAULT_LOG_CHAT_ID = int(os.getenv("AUDIT_LOG_CHAT_ID", "0") or 0)
BATCH_SECONDS = max(1.0, float(os.getenv("AUDIT_BATCH_SECONDS", "3")))
BATCH_MAX = max(1, min(50, int(os.getenv("AUDIT_BATCH_MAX", "10") or 10)))
LOG_DELETED = os.getenv("AUDIT_LOG_DELETED", "true").lower() not in {"0", "false", "no"}

_bot: TelegramClient | None = None
_queues: dict[int, deque[str]] = defaultdict(deque)
_tasks: dict[int, asyncio.Task] = {}
_locks: dict[int, asyncio.Lock] = defaultdict(asyncio.Lock)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _owner(event) -> bool:
    is_main = getattr(getattr(event, "client", None), "_hapoyi_account_id", 0) in (0, None)
    if OWNER_ID > 0 and is_main:
        return event.sender_id == OWNER_ID
    # Safe local fallback: only the account itself can issue audit commands.
    return bool(getattr(event, "out", False))


def _clip(value: str | None, limit: int = 3500) -> str:
    text = (value or "").replace("\x00", "").strip()
    if not text:
        return "<بدون متن>"
    if len(text) <= limit:
        return html.escape(text)
    return html.escape(text[:limit - 20] + "\n… [truncated]")


def _media_name(message: Any) -> str | None:
    media = getattr(message, "media", None)
    if not media:
        return None
    name = media.__class__.__name__
    mapping = {
        "MessageMediaPhoto": "photo",
        "MessageMediaDocument": "document",
        "MessageMediaWebPage": "webpage",
        "MessageMediaGeo": "location",
        "MessageMediaGeoLive": "live-location",
        "MessageMediaPoll": "poll",
        "MessageMediaContact": "contact",
        "MessageMediaVenue": "venue",
        "MessageMediaDice": "dice",
        "MessageMediaStory": "story",
    }
    return mapping.get(name, name.removeprefix("MessageMedia").lower())


def _sender_label(message: Any) -> str:
    sender = getattr(message, "sender", None)
    sender_id = getattr(message, "sender_id", None)
    if sender is None:
        return f"id={sender_id}"
    username = getattr(sender, "username", None)
    first = getattr(sender, "first_name", None) or ""
    last = getattr(sender, "last_name", None) or ""
    name = " ".join(x for x in (first, last) if x).strip()
    display = html.escape(name or "user")
    if username:
        return html.escape(f"@{username}") + f" ({display} / {sender_id})"
    return f"{display} / {sender_id}"


def _format_new(chat_id: int, message: Any) -> str:
    stamp = getattr(message, "date", None) or datetime.now(timezone.utc)
    sender = _sender_label(message)
    media = _media_name(message)
    lines = [
        "🟢 <b>NEW MESSAGE</b>",
        f"chat=<code>{chat_id}</code>  msg=<code>{getattr(message, 'id', '?')}</code>",
        f"from={_clip(sender, 300)}",
        f"time=<code>{stamp.isoformat(timespec='seconds')}</code>",
    ]
    if media:
        lines.append(f"media=<code>{media}</code>")
    lines.append("")
    lines.append(_clip(getattr(message, "raw_text", "")))
    return "\n".join(lines)


def _format_edit(chat_id: int, message: Any, old_text: str | None) -> str:
    stamp = getattr(message, "date", None) or datetime.now(timezone.utc)
    new_text = getattr(message, "raw_text", "")
    lines = [
        "✏️ <b>MESSAGE EDITED</b>",
        f"chat=<code>{chat_id}</code>  msg=<code>{getattr(message, 'id', '?')}</code>",
        f"from={_clip(_sender_label(message), 300)}",
        f"time=<code>{stamp.isoformat(timespec='seconds')}</code>",
        "",
        "<b>قبل:</b>",
        _clip(old_text) if old_text is not None else "<قابل بازیابی نبود؛ لاگر قبل از این پیام/ویرایش فعال نبوده است>",
        "",
        "<b>بعد:</b>",
        _clip(new_text),
    ]
    return "\n".join(lines)


def _format_delete(chat_id: int, message_id: int, old_text: str | None) -> str:
    return "\n".join([
        "🗑️ <b>MESSAGE DELETED</b>",
        f"chat=<code>{chat_id}</code>  msg=<code>{message_id}</code>",
        f"time=<code>{_now()}</code>",
        "",
        "<b>متن ذخیره‌شده:</b>",
        _clip(old_text) if old_text is not None else "<متن ذخیره نشده بود>",
    ])


async def _resolve_chat(client, ref: str, fallback: int | None = None) -> int:
    ref = (ref or "").strip()
    if not ref or ref.lower() in {"here", "this", "فعلی"}:
        if fallback is None:
            raise ValueError("چت مشخص نشده است")
        return int(fallback)
    if re.fullmatch(r"-?\d+", ref):
        return int(ref)
    entity = await client.get_entity(ref)
    return int(entity.id)


async def _send_bot(log_chat_id: int, text: str) -> None:
    if _bot is None:
        return
    try:
        await _bot.send_message(log_chat_id, text, parse_mode="html", link_preview=False)
    except (FloodWaitError, SlowModeWaitError) as exc:
        # Reliability/backoff only. No evasion or retry storm.
        seconds = max(1, int(getattr(exc, "seconds", 1)))
        await asyncio.sleep(min(seconds, 60))
        try:
            await _bot.send_message(log_chat_id, text, parse_mode="html", link_preview=False)
        except Exception as retry_exc:
            log.warning("audit bot retry failed: %s: %s", retry_exc.__class__.__name__, retry_exc)
    except RPCError as exc:
        log.warning("audit bot RPC failed: %s: %s", exc.__class__.__name__, exc)
    except Exception as exc:
        log.warning("audit bot send failed: %s: %s", exc.__class__.__name__, exc)


async def _flush(log_chat_id: int) -> None:
    async with _locks[log_chat_id]:
        queue = _queues[log_chat_id]
        if not queue:
            return
        items: list[str] = []
        while queue and len(items) < BATCH_MAX:
            items.append(queue.popleft())
        text = "\n\n━━━━━━━━━━━━━━━━━━━━\n\n".join(items)
    # Keep each Telegram message comfortably below the platform limit.
    if len(text) > 3900:
        chunks: list[str] = []
        current = ""
        for item in items:
            candidate = item if not current else current + "\n\n━━━━━━━━━━━━━━━━━━━━\n\n" + item
            if len(candidate) > 3900 and current:
                chunks.append(current)
                current = item
            else:
                current = candidate
        if current:
            chunks.append(current)
    else:
        chunks = [text]
    for chunk in chunks:
        await _send_bot(log_chat_id, chunk)
    async with _locks[log_chat_id]:
        if _queues[log_chat_id]:
            _schedule_flush(log_chat_id)


def _schedule_flush(log_chat_id: int) -> None:
    task = _tasks.get(log_chat_id)
    if task is not None and not task.done():
        return

    async def worker() -> None:
        await asyncio.sleep(BATCH_SECONDS)
        await _flush(log_chat_id)

    _tasks[log_chat_id] = asyncio.create_task(worker())


async def _queue_log(log_chat_id: int, text: str) -> None:
    async with _locks[log_chat_id]:
        _queues[log_chat_id].append(text)
        full = len(_queues[log_chat_id]) >= BATCH_MAX
    if full:
        task = _tasks.get(log_chat_id)
        if task is not None and not task.done():
            task.cancel()
        await _flush(log_chat_id)
    else:
        _schedule_flush(log_chat_id)


async def _remember(db, message: Any, chat_id: int) -> None:
    sender_id = getattr(message, "sender_id", None)
    sender = getattr(message, "sender", None)
    name = None
    if sender:
        name = " ".join(x for x in (getattr(sender, "first_name", None), getattr(sender, "last_name", None)) if x) or getattr(sender, "username", None)
    await db.execute(
        """INSERT INTO audit_messages(chat_id,message_id,sender_id,sender_name,message_date,text,media_type,last_edit_at,updated_at)
           VALUES(?,?,?,?,?,?,?,?,?)
           ON CONFLICT(chat_id,message_id) DO UPDATE SET sender_id=excluded.sender_id,
             sender_name=excluded.sender_name,message_date=excluded.message_date,text=excluded.text,
             media_type=excluded.media_type,last_edit_at=excluded.last_edit_at,updated_at=excluded.updated_at""",
        (
            int(chat_id), int(getattr(message, "id", 0)), sender_id, name,
            getattr(message, "date", None).isoformat() if getattr(message, "date", None) else None,
            getattr(message, "raw_text", ""), _media_name(message), None, _now(),
        ),
    )


async def _get_old(db, chat_id: int, message_id: int) -> str | None:
    row = await db.fetchone("SELECT text FROM audit_messages WHERE chat_id=? AND message_id=?", (chat_id, message_id))
    return None if row is None else row["text"]


async def setup(client, db):
    global _bot
    # SQLite schema is kept in the project DB so the logger survives restarts.
    await db.execute(
        """CREATE TABLE IF NOT EXISTS audit_configs(
            chat_id INTEGER PRIMARY KEY,
            log_chat_id INTEGER NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 1,
            log_new INTEGER NOT NULL DEFAULT 1,
            log_edits INTEGER NOT NULL DEFAULT 1,
            log_deletes INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )"""
    )
    await db.execute(
        """CREATE TABLE IF NOT EXISTS audit_messages(
            chat_id INTEGER NOT NULL,
            message_id INTEGER NOT NULL,
            sender_id INTEGER,
            sender_name TEXT,
            message_date TEXT,
            text TEXT,
            media_type TEXT,
            last_edit_at TEXT,
            updated_at TEXT NOT NULL,
            PRIMARY KEY(chat_id, message_id)
        )"""
    )

    if AUDIT_BOT_TOKEN and _bot is not None:
        pass  # the audit bot is shared by every account in this process
    elif AUDIT_BOT_TOKEN:
        try:
            api_id = int(os.getenv("API_ID", "0") or 0)
            api_hash = os.getenv("API_HASH", "")
            _bot = TelegramClient(AUDIT_BOT_SESSION, api_id, api_hash, auto_reconnect=True, flood_sleep_threshold=60)
            await _bot.start(bot_token=AUDIT_BOT_TOKEN)
            log.info("Audit bot started")
        except Exception as exc:
            log.error("Audit bot failed to start: %s: %s", exc.__class__.__name__, exc)
            _bot = None
    else:
        log.info("Audit logger loaded without AUDIT_BOT_TOKEN; configure it to enable remote logs")

    @client.on(events.NewMessage)
    async def audit_new(event):
        if not event.chat_id:
            return
        row = await db.fetchone("SELECT * FROM audit_configs WHERE chat_id=? AND enabled=1", (int(event.chat_id),))
        if row is None:
            return
        await _remember(db, event.message, int(event.chat_id))
        if row["log_new"]:
            await _queue_log(int(row["log_chat_id"]), _format_new(int(event.chat_id), event.message))

    @client.on(events.MessageEdited)
    async def audit_edit(event):
        if not event.chat_id:
            return
        row = await db.fetchone("SELECT * FROM audit_configs WHERE chat_id=? AND enabled=1", (int(event.chat_id),))
        if row is None:
            return
        old_text = await _get_old(db, int(event.chat_id), int(event.id))
        if row["log_edits"]:
            await _queue_log(int(row["log_chat_id"]), _format_edit(int(event.chat_id), event.message, old_text))
        await db.execute(
            "UPDATE audit_messages SET text=?, last_edit_at=?, updated_at=? WHERE chat_id=? AND message_id=?",
            (getattr(event.message, "raw_text", ""), _now(), _now(), int(event.chat_id), int(event.id)),
        )
        if old_text is None:
            await _remember(db, event.message, int(event.chat_id))

    if LOG_DELETED:
        @client.on(events.MessageDeleted)
        async def audit_deleted(event):
            chat_id = getattr(event, "chat_id", None)
            if not chat_id:
                return
            row = await db.fetchone("SELECT * FROM audit_configs WHERE chat_id=? AND enabled=1", (int(chat_id),))
            if row is None or not row["log_deletes"]:
                return
            for message_id in event.deleted_ids:
                old_text = await _get_old(db, int(chat_id), int(message_id))
                await _queue_log(int(row["log_chat_id"]), _format_delete(int(chat_id), int(message_id), old_text))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}audit(?:\s+(.+))?$"))
    async def audit_cmd(event):
        if not _owner(event):
            return
        raw = (event.pattern_match.group(1) or "").strip()
        parts = raw.split()
        if not parts:
            return await event.reply(
                "🔎 Audit Logger\n"
                f"{PREFIX}audit on [source] [log_chat]\n"
                f"{PREFIX}audit off [source]\n"
                f"{PREFIX}audit list\n"
                f"{PREFIX}audit status [source]\n"
                f"{PREFIX}audit purge [source]\n"
                f"{PREFIX}audit test"
            )
        action = parts[0].lower()
        if action == "list":
            rows = await db.fetchall("SELECT chat_id,log_chat_id,enabled,log_new,log_edits,log_deletes,updated_at FROM audit_configs ORDER BY chat_id")
            if not rows:
                return await event.reply("🔎 هیچ Audit فعالی ثبت نشده.")
            lines = ["🔎 Audit targets:"]
            for r in rows:
                lines.append(f"• source=<code>{r['chat_id']}</code> → log=<code>{r['log_chat_id']}</code> | new={r['log_new']} edit={r['log_edits']} delete={r['log_deletes']}")
            return await event.reply("\n".join(lines)[:4000], parse_mode="html")
        if action == "test":
            rows = await db.fetchall("SELECT DISTINCT log_chat_id FROM audit_configs WHERE enabled=1")
            if not rows and DEFAULT_LOG_CHAT_ID:
                rows = [{"log_chat_id": DEFAULT_LOG_CHAT_ID}]
            if not rows:
                return await event.reply("❌ هیچ مقصد لاگی تنظیم نشده.")
            for r in rows:
                await _queue_log(int(r["log_chat_id"]), "🧪 <b>AUDIT TEST</b>\nاگر این پیام را می‌بینی، ربات لاگ سالم است.")
            return await event.reply("✅ تست وارد صف لاگ شد.")
        if action in {"on", "off", "status", "purge"}:
            source = await _resolve_chat(client, parts[1], event.chat_id) if len(parts) >= 2 else int(event.chat_id)
            if action == "on":
                log_chat = int(DEFAULT_LOG_CHAT_ID)
                if len(parts) >= 3:
                    log_chat = await _resolve_chat(client, parts[2], None)
                if log_chat == 0:
                    return await event.reply("❌ مقصد لاگ مشخص نیست. در .env مقدار AUDIT_LOG_CHAT_ID بگذار یا log_chat را بده.")
                now = _now()
                await db.execute(
                    """INSERT INTO audit_configs(chat_id,log_chat_id,enabled,log_new,log_edits,log_deletes,created_at,updated_at)
                       VALUES(?,?,1,1,1,1,?,?)
                       ON CONFLICT(chat_id) DO UPDATE SET log_chat_id=excluded.log_chat_id,enabled=1,updated_at=excluded.updated_at""",
                    (source, log_chat, now, now),
                )
                return await event.reply(f"✅ Audit فعال شد.\nsource=<code>{source}</code>\nlog=<code>{log_chat}</code>", parse_mode="html")
            if action == "off":
                await db.execute("UPDATE audit_configs SET enabled=0,updated_at=? WHERE chat_id=?", (_now(), source))
                return await event.reply(f"🛑 Audit خاموش شد برای <code>{source}</code>.", parse_mode="html")
            if action == "status":
                row = await db.fetchone("SELECT * FROM audit_configs WHERE chat_id=?", (source,))
                if row is None:
                    return await event.reply("❌ برای این چت تنظیمی پیدا نشد.")
                count = await db.fetchone("SELECT COUNT(*) AS n FROM audit_messages WHERE chat_id=?", (source,))
                return await event.reply(
                    f"🔎 <b>Audit status</b>\nsource=<code>{source}</code>\nlog=<code>{row['log_chat_id']}</code>\nenabled=<code>{row['enabled']}</code>\nnew=<code>{row['log_new']}</code>\nedits=<code>{row['log_edits']}</code>\ndeletes=<code>{row['log_deletes']}</code>\nstored_messages=<code>{count['n']}</code>",
                    parse_mode="html",
                )
            await db.execute("DELETE FROM audit_messages WHERE chat_id=?", (source,))
            return await event.reply(f"🧹 حافظهٔ محلی Audit برای <code>{source}</code> پاک شد.", parse_mode="html")
        return await event.reply("❌ دستور Audit ناشناخته است. .audit را بزن.")
