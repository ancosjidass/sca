from __future__ import annotations

import asyncio
import logging
import os
import re
from core.identity import my_id
from telethon import events
from telethon.errors import FloodWaitError, ReactionInvalidError, RPCError

from core.permissions import explain_error, reply_to_id, resolve_target
from utils.react import send_reaction
from utils.targets import target_label

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}autoreply\s+(add|del|list|on|off)(?:\s+(.+?))?(?:\s+=>\s+(.+))?$"))
    async def autoreply_cmd(event):
        action, trigger, response = event.pattern_match.group(1), event.pattern_match.group(2), event.pattern_match.group(3)
        scope = event.chat_id if event.is_group else 0
        if action == "list":
            rows = await db.fetchall("SELECT id,trigger,response,mode,enabled FROM autoreplies WHERE scope_id=? ORDER BY id", (scope,))
            return await event.reply("🤖 AutoReply:\n" + "\n".join(f"#{r['id']} {r['trigger']} → {r['response']} {'ON' if r['enabled'] else 'OFF'}" for r in rows) if rows else "🤖 خالی است.")
        if action in {"on", "off"}:
            await db.execute("UPDATE autoreplies SET enabled=? WHERE scope_id=?", (int(action == "on"), scope))
            return await event.reply("✅ AutoReply " + ("روشن" if action == "on" else "خاموش"))
        if not trigger:
            return await event.reply("مثال: .autoreply add سلام => سلام داداش ❤️")
        if action == "add":
            if not response:
                return await event.reply("فرمت: .autoreply add trigger => response")
            await db.execute("INSERT INTO autoreplies(scope_type,scope_id,trigger,response,mode,enabled) VALUES('chat',?,?,?,?,1)", (scope, trigger.strip().lower(), response, "contains"))
            return await event.reply("✅ AutoReply اضافه شد.")
        try:
            rid = int(trigger.lstrip("#"))
        except ValueError:
            return await event.reply("برای حذف ID بده؛ مثل .autoreply del 3")
        await db.execute("DELETE FROM autoreplies WHERE id=? AND scope_id=?", (rid, scope))
        await event.reply("✅ حذف شد.")

    @client.on(events.NewMessage)
    async def autoreply_handler(event):
        # Never answer ourselves (that was a self-reply loop) or Telegram's service account.
        if event.out or not event.raw_text or event.raw_text.startswith(PREFIX) or event.sender_id == 777000:
            return
        scope = event.chat_id if event.is_group else 0
        rows = await db.fetchall("SELECT trigger,response,mode,enabled FROM autoreplies WHERE scope_id=? AND enabled=1", (scope,))
        low = event.raw_text.lower()
        for row in rows:
            try:
                matched = re.search(row["trigger"], event.raw_text, re.I) if row["mode"] == "regex" else row["trigger"] in low
            except re.error:
                matched = False
            if matched:
                await event.reply(row["response"])
                break

    # ------------------------------------------------------------------ AutoReact (per chat / per user)
    # user_id = 0 means "every message in this chat"; user_id > 0 means "only that person's messages".
    react_map: dict[int, dict[int, str]] = {}
    react_warned: set[tuple[int, str]] = set()

    async def load_reactions() -> None:
        # one-time migration of the old chat-wide table
        await db.execute("INSERT OR IGNORE INTO user_reactions(chat_id,user_id,emoji,enabled) SELECT chat_id,0,emoji,enabled FROM reactions WHERE emoji IS NOT NULL AND emoji<>''")
        react_map.clear()
        for r in await db.fetchall("SELECT chat_id,user_id,emoji FROM user_reactions WHERE enabled=1"):
            react_map.setdefault(int(r["chat_id"]), {})[int(r["user_id"])] = r["emoji"]

    loaded = {"done": False}

    async def ensure_loaded() -> None:
        if not loaded["done"]:
            loaded["done"] = True
            await load_reactions()

    def _looks_like_emoji(token: str) -> bool:
        return bool(token) and not (token.isascii() and token.isalnum())

    async def _react_target(event, raw):
        """(user_id, label). raw=None -> reply author, else chat-wide (0)."""
        if raw:
            user = await resolve_target(event, raw)
            if user is None:
                return None, "❌ کاربر پیدا نشد."
            return int(getattr(user, "id", user)), target_label(user)
        if event.is_reply:
            user = await resolve_target(event, None)
            if user is None:
                return None, "❌ نویسندهٔ پیام پیدا نشد (پیام کانال/ناشناس؟)."
            return int(getattr(user, "id", user)), target_label(user)
        return 0, "همهٔ پیام‌های این گپ"

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}autoreact(?:\s+(.+))?$"))
    async def autoreact_cmd(event):
        await ensure_loaded()
        args = (event.pattern_match.group(1) or "").split()
        chat = event.chat_id
        word = args[0].lower() if args else ""

        if word in {"list", ""}:
            rows = await db.fetchall("SELECT user_id,emoji,enabled FROM user_reactions WHERE chat_id=? ORDER BY user_id", (chat,))
            if not rows:
                return await event.reply(
                    "❤️ AutoReact در این گپ تنظیم نشده.\n"
                    f"`{PREFIX}autoreact 🤣` (روی پیام کسی Reply کن) → فقط پیام‌های اون آدم\n"
                    f"`{PREFIX}autoreact 🤣` (بدون Reply) → همهٔ پیام‌های این گپ\n"
                    f"`{PREFIX}autoreact off|on [@user]` — `{PREFIX}autoreact clear`"
                )
            lines = ["❤️ AutoReact این گپ:"]
            for r in rows:
                who = "همهٔ پیام‌ها" if r["user_id"] == 0 else str(r["user_id"])
                lines.append(f"• {who} → {r['emoji']} {'ON' if r['enabled'] else 'OFF'}")
            return await event.reply("\n".join(lines))

        if word == "clear":
            await db.execute("DELETE FROM user_reactions WHERE chat_id=?", (chat,))
            await db.execute("DELETE FROM reactions WHERE chat_id=?", (chat,))
            await load_reactions()
            return await event.reply("🗑 همهٔ AutoReactهای این گپ پاک شد.")

        if word in {"off", "on", "del"}:
            if len(args) > 1 and args[1].lower() == "all":
                flag = 1 if word == "on" else 0
                if word == "del":
                    await db.execute("DELETE FROM user_reactions WHERE chat_id=?", (chat,))
                else:
                    await db.execute("UPDATE user_reactions SET enabled=? WHERE chat_id=?", (flag, chat))
                await load_reactions()
                return await event.reply({"on": "✅ همهٔ AutoReactهای این گپ روشن شد.", "off": "⏸ همهٔ AutoReactهای این گپ خاموش شد.", "del": "🗑 حذف شد."}[word])
            uid, label = await _react_target(event, args[1] if len(args) > 1 else None)
            if uid is None:
                return await event.reply(label)
            if word == "del":
                n = await db.execute("DELETE FROM user_reactions WHERE chat_id=? AND user_id=?", (chat, uid))
            else:
                n = await db.execute("UPDATE user_reactions SET enabled=? WHERE chat_id=? AND user_id=?", (1 if word == "on" else 0, chat, uid))
            await load_reactions()
            if not n:
                return await event.reply(f"ℹ️ برای {label} AutoReact تنظیم نشده بود.")
            return await event.reply(f"✅ AutoReact برای {label} " + {"on": "روشن شد.", "off": "خاموش شد.", "del": "حذف شد."}[word])

        emoji = args[0]
        if not _looks_like_emoji(emoji):
            return await event.reply("❌ یک ایموجی بده؛ مثال: `.autoreact 🤣` (روی پیام کسی Reply کن).")
        uid, label = await _react_target(event, args[1] if len(args) > 1 else None)
        if uid is None:
            return await event.reply(label)
        # Test the emoji right now (on the replied message when there is one) so a chat that does
        # not allow this reaction is reported immediately instead of silently never reacting.
        probe = reply_to_id(event) if uid else None
        if probe:
            try:
                await send_reaction(client, chat, probe, emoji)
            except ReactionInvalidError:
                return await event.reply(f"❌ ایموجی {emoji} در این گپ مجاز نیست (ادمین‌ها فقط بعضی ری‌اکشن‌ها را فعال کرده‌اند).")
            except RPCError as exc:
                return await event.reply(f"❌ ری‌اکشن زدن نشد: {explain_error(exc)}")
        await db.execute(
            "INSERT INTO user_reactions(chat_id,user_id,emoji,enabled) VALUES(?,?,?,1) ON CONFLICT(chat_id,user_id) DO UPDATE SET emoji=excluded.emoji,enabled=1",
            (chat, uid, emoji),
        )
        await load_reactions()
        await event.reply(f"❤️ AutoReact {emoji} روشن شد برای: {label}")

    @client.on(events.NewMessage(incoming=True))
    async def autoreact_handler(event):
        if event.out:
            return
        await ensure_loaded()
        mapping = react_map.get(int(event.chat_id or 0))
        if not mapping:
            return
        emoji = mapping.get(int(event.sender_id or -1)) or mapping.get(0)
        if not emoji:
            return
        try:
            await send_reaction(client, event.chat_id, event.id, emoji)
        except ReactionInvalidError:
            if (event.chat_id, emoji) not in react_warned:
                react_warned.add((event.chat_id, emoji))
                log.warning("AutoReact: %s is not an allowed reaction in chat %s", emoji, event.chat_id)
        except FloodWaitError as exc:
            log.warning("AutoReact flood wait %ss in chat %s", exc.seconds, event.chat_id)
            await asyncio.sleep(min(exc.seconds, 30))
        except RPCError as exc:
            log.debug("AutoReact failed in %s: %s", event.chat_id, exc.__class__.__name__)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}watch\s+(add|del|list)(?:\s+(\S+))?(?:\s+(.+))?$"))
    async def watch_cmd(event):
        action, chat, needle = event.pattern_match.group(1), event.pattern_match.group(2), event.pattern_match.group(3)
        owner = (await my_id(client))
        if action == "list":
            rows = await db.fetchall("SELECT chat_id,kind,needle FROM watches WHERE owner_id=? AND enabled=1", (owner,))
            return await event.reply("👀 Watches:\n" + "\n".join(f"• {r['chat_id']} {r['kind']} {r['needle'] or ''}" for r in rows) if rows else "👀 خالی است.")
        if not chat:
            return await event.reply(".watch add @channel [keyword]")
        try:
            chat_id = int(chat) if chat.lstrip("-").isdigit() else (await client.get_entity(chat)).id
        except Exception:
            return await event.reply("❌ chat پیدا نشد.")
        kind = "keyword" if needle else "new_message"
        if action == "add":
            await db.execute("INSERT OR IGNORE INTO watches(owner_id,chat_id,kind,needle,enabled) VALUES(?,?,?,?,1)", (owner,chat_id,kind,needle))
            return await event.reply("✅ Watch اضافه شد.")
        await db.execute("DELETE FROM watches WHERE owner_id=? AND chat_id=?", (owner,chat_id))
        await event.reply("✅ Watch حذف شد.")

    @client.on(events.NewMessage)
    async def watch_handler(event):
        if event.out or not event.raw_text:
            return
        rows = await db.fetchall("SELECT owner_id,needle FROM watches WHERE chat_id=? AND enabled=1", (event.chat_id,))
        if not rows:
            return
        for row in rows:
            needle = row["needle"]
            if not needle or needle.lower() in event.raw_text.lower():
                await client.send_message(row["owner_id"], f"👀 Watch\nChat: {event.chat_id}\nMessage: {event.raw_text[:3000]}")
