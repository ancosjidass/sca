from __future__ import annotations

import asyncio
import logging
import os
import re
from datetime import datetime, timezone

from telethon import events, utils
from telethon.errors import RPCError
from telethon.tl.functions.channels import GetFullChannelRequest

from core.permissions import explain_error

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)


def setup(client, db):
    # channel_id (marked, -100...) -> comment text, for enabled channels only (hot path: no DB hit per post)
    enabled: dict[int, str] = {}
    seen_albums: dict[tuple[int, int], float] = {}
    loaded = {"done": False}

    async def reload() -> None:
        enabled.clear()
        for r in await db.fetchall("SELECT channel_id,text FROM first_comments WHERE enabled=1"):
            enabled[int(r["channel_id"])] = r["text"]
        loaded["done"] = True

    async def ensure_loaded() -> None:
        if not loaded["done"]:
            await reload()

    async def _entity(ref: str):
        ref = ref.strip()
        if re.fullmatch(r"-?\d+", ref):
            ref = int(ref)
        entity = await client.get_entity(ref)
        if not getattr(entity, "broadcast", False):
            raise ValueError("این یک کانال نیست (کانال broadcast لازم است).")
        return entity

    async def _check_commentable(entity) -> str:
        """Human readable warning list; empty string means everything looks fine."""
        notes = []
        try:
            full = await client(GetFullChannelRequest(entity))
            linked = getattr(full.full_chat, "linked_chat_id", None)
            if not linked:
                return "⚠️ این کانال گپ کامنت (Discussion) ندارد؛ کامنت بسته است."
            try:
                perm = await client.get_permissions(linked, "me")
                if perm is None or getattr(perm, "has_left", False) or getattr(perm, "is_banned", False):
                    notes.append("⚠️ عضو گپ کامنت این کانال نیستی؛ تا عضو نشوی کامنت گذاشته نمی‌شود.")
            except Exception:  # noqa: BLE001 - not a participant raises
                notes.append("⚠️ عضو گپ کامنت این کانال نیستی؛ تا عضو نشوی کامنت گذاشته نمی‌شود.")
        except Exception as exc:  # noqa: BLE001
            notes.append(f"⚠️ وضعیت کامنت بررسی نشد ({exc.__class__.__name__}).")
        return "\n".join(notes)

    # ------------------------------------------------------------------ .comment first ...
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}comment\s+first\s+(.+)$", ))
    async def comment_first_cmd(event):
        await ensure_loaded()
        rest = event.pattern_match.group(1).strip()
        parts = rest.split(maxsplit=1)
        word = parts[0].lower()

        if word == "list":
            rows = await db.fetchall("SELECT channel_id,title,text,enabled,posted,last_status,last_at FROM first_comments ORDER BY created_at")
            if not rows:
                return await event.reply("💬 First-Comment برای هیچ کانالی فعال نیست.")
            lines = ["💬 First-Comment:"]
            for r in rows:
                lines.append(
                    f"• {r['title'] or r['channel_id']} ({r['channel_id']}) {'ON' if r['enabled'] else 'OFF'} | ارسال‌شده: {r['posted']}\n"
                    f"  متن: {r['text'][:60]}\n  آخرین وضعیت: {r['last_status'] or '—'}"
                )
            return await event.reply("\n".join(lines)[:3900])

        if word in {"off", "del"}:
            if len(parts) < 2:
                return await event.reply(f"فرمت: `{PREFIX}comment first off @channel`")
            try:
                entity = await _entity(parts[1])
            except Exception as exc:  # noqa: BLE001
                return await event.reply(f"❌ کانال پیدا نشد: {exc}")
            cid = utils.get_peer_id(entity)
            if word == "del":
                await db.execute("DELETE FROM first_comments WHERE channel_id=?", (cid,))
            else:
                await db.execute("UPDATE first_comments SET enabled=0 WHERE channel_id=?", (cid,))
            await reload()
            return await event.reply(f"✅ First-Comment برای {getattr(entity, 'title', cid)} " + ("حذف شد." if word == "del" else "خاموش شد."))

        if word == "on" and len(parts) >= 2:  # re-enable with saved text
            try:
                entity = await _entity(parts[1])
            except Exception as exc:  # noqa: BLE001
                return await event.reply(f"❌ کانال پیدا نشد: {exc}")
            n = await db.execute("UPDATE first_comments SET enabled=1 WHERE channel_id=?", (utils.get_peer_id(entity),))
            await reload()
            return await event.reply("✅ روشن شد." if n else f"ℹ️ قبلاً تنظیم نشده؛ `{PREFIX}comment first @channel متن` بزن.")

        # .comment first <channel> <text>
        if len(parts) < 2:
            return await event.reply(f"فرمت: `{PREFIX}comment first @channel متن کامنت`")
        text = parts[1].strip()
        if len(text) > 4000:
            return await event.reply("❌ متن خیلی طولانی است.")
        try:
            entity = await _entity(parts[0])
        except Exception as exc:  # noqa: BLE001
            return await event.reply(f"❌ کانال پیدا نشد: {exc}")
        cid = utils.get_peer_id(entity)
        now = datetime.now(timezone.utc).isoformat()
        await db.execute(
            "INSERT INTO first_comments(channel_id,title,text,enabled,created_at) VALUES(?,?,?,1,?) "
            "ON CONFLICT(channel_id) DO UPDATE SET title=excluded.title,text=excluded.text,enabled=1",
            (cid, getattr(entity, "title", None), text, now),
        )
        await reload()
        warn = await _check_commentable(entity)
        await event.reply(
            f"✅ First-Comment فعال شد برای {getattr(entity, 'title', cid)}\n"
            f"از این به بعد زیر هر پست جدید این کانال، کامنت اول با این متن گذاشته می‌شود:\n{text[:200]}"
            + (f"\n\n{warn}" if warn else "")
        )

    # ------------------------------------------------------------------ the hot path
    async def _post_first_comment(event, text: str) -> None:
        cid = int(event.chat_id)
        status = "ok"
        for delay in (0, 0.6, 1.2, 2.5):
            if delay:
                await asyncio.sleep(delay)
            try:
                # comment_to resolves the discussion thread of this post; right after a post it may
                # not be ready yet, hence the short retry ladder.
                await client.send_message(event.chat_id, text, comment_to=event.message)
                break
            except RPCError as exc:
                name = exc.__class__.__name__
                if name in {"MsgIdInvalidError", "MessageIdInvalidError", "ChannelInvalidError"} and delay < 2.5:
                    continue
                status = f"fail: {explain_error(exc)}"
                break
            except ValueError as exc:  # Telethon: channel has no discussion group
                status = f"fail: کامنت بسته است ({exc})"
                break
            except Exception as exc:  # noqa: BLE001
                status = f"fail: {exc.__class__.__name__}"
                break
        else:
            status = "fail: گپ کامنت هنوز آماده نشد"
        ok = status == "ok"
        await db.execute(
            "UPDATE first_comments SET posted=posted+?,last_status=?,last_at=? WHERE channel_id=?",
            (1 if ok else 0, status, datetime.now(timezone.utc).isoformat(), cid),
        )
        if not ok:
            log.warning("first-comment in %s: %s", cid, status)

    @client.on(events.NewMessage(func=lambda e: bool(getattr(e.message, "post", False))))
    async def first_comment_watcher(event):
        await ensure_loaded()
        text = enabled.get(int(event.chat_id or 0))
        if not text:
            return
        gid = getattr(event.message, "grouped_id", None)
        if gid:  # an album arrives as several messages -> comment once
            key = (int(event.chat_id), int(gid))
            if key in seen_albums:
                return
            seen_albums[key] = asyncio.get_running_loop().time()
            if len(seen_albums) > 500:
                for k in sorted(seen_albums, key=seen_albums.get)[:250]:
                    seen_albums.pop(k, None)
        await _post_first_comment(event, text)

    # ------------------------------------------------------------------ classic commands
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}comment\s+(?!first\b)(\S+)\s+(.+)$"))
    async def comment(event):
        channel, text = event.pattern_match.group(1), event.pattern_match.group(2)
        try:
            entity = await client.get_entity(int(channel) if re.fullmatch(r"-?\d+", channel) else channel)
            posts = await client.get_messages(entity, limit=1)
            if not posts:
                return await event.reply("❌ پستی پیدا نشد.")
            await client.send_message(entity, text, comment_to=posts[0].id)
            await event.reply(f"✅ روی آخرین پست {channel} کامنت گذاشته شد.")
        except Exception as exc:  # noqa: BLE001
            await event.reply(f"❌ Comment failed: {explain_error(exc)}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}comments\s+(\S+)\s+(\d+)$"))
    async def comments(event):
        channel, post_id = event.pattern_match.group(1), int(event.pattern_match.group(2))
        entity = await client.get_entity(int(channel) if re.fullmatch(r"-?\d+", channel) else channel)
        rows = []
        async for msg in client.iter_messages(entity, reply_to=post_id, limit=30):
            rows.append(f"• {msg.sender_id}: {(msg.raw_text or '')[:100]}")
        await event.reply("💬 Comments\n" + "\n".join(rows) if rows else "💬 بدون کامنت")
