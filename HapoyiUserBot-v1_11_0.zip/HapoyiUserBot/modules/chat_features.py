from __future__ import annotations

import os
import re
from collections import defaultdict, deque
from time import monotonic, time

from telethon import events
from telethon.errors import RPCError

from core.actions import UnsupportedChat, edit_banned
from core.permissions import require_group_right, target_is_admin
from utils.rights import MIN_RESTRICT_SECONDS, ban_rights, mute_rights
from utils.formatting import parse_duration
from utils.linkguard import LinkCounter, contains_link

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
_URL_RE = re.compile(r"(?:https?://|www\.|t\.me/|telegram\.me/)[^\s]+", re.I)
_rate: dict[tuple[int, int, int], deque[float]] = defaultdict(lambda: deque(maxlen=50))


def _render(template: str, event, user, chat) -> str:
    name = " ".join(x for x in [getattr(user, "first_name", ""), getattr(user, "last_name", "")] if x).strip() or "کاربر"
    mention = f"[{name}](tg://user?id={getattr(user, 'id', 0)})"
    title = getattr(chat, "title", None) or getattr(chat, "first_name", None) or "چت"
    return (template.replace("{name}", name).replace("{mention}", mention)
            .replace("{id}", str(getattr(user, "id", ""))).replace("{chat}", title))


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}welcome\s+(on|off)(?:\s+(.+))?$"))
    async def welcome_cmd(event):
        if not event.is_group:
            return await event.reply("❌ فقط داخل گروه.")
        p = await require_group_right(client, event.chat_id, "change_info")
        if not p.allowed:
            return await event.reply("❌ " + p.reason)
        enabled = event.pattern_match.group(1) == "on"
        text = event.pattern_match.group(2) or "👋 خوش اومدی {mention} به {chat}!"
        await db.update_chat_settings(event.chat_id, welcome_enabled=enabled, welcome_text=text)
        await event.reply("👋 Welcome " + ("فعال شد." if enabled else "خاموش شد."))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}leave\s+(on|off)$"))
    async def leave_cmd(event):
        if not event.is_group:
            return await event.reply("❌ فقط داخل گروه.")
        p = await require_group_right(client, event.chat_id, "change_info")
        if not p.allowed:
            return await event.reply("❌ " + p.reason)
        enabled = event.pattern_match.group(1) == "on"
        await db.update_chat_settings(event.chat_id, leave_enabled=enabled)
        await event.reply("👋 Leave logger " + ("فعال شد." if enabled else "خاموش شد."))

    link_counts = LinkCounter()

    async def _link_action(event, cfg: dict, *, reason: str = "link") -> str:
        """Apply the configured immediate action. Returns a short status string."""
        action = str(cfg.get("linkguard_action", "delete"))
        duration = int(cfg.get("linkguard_duration", 600) or 600)
        try:
            await event.delete()
        except RPCError:
            pass

        if not event.sender_id:
            return "deleted"
        if action == "delete":
            return "deleted"
        if action == "warn":
            row = await db.fetchone(
                "SELECT count FROM warnings WHERE chat_id=? AND user_id=?",
                (event.chat_id, int(event.sender_id)),
            )
            count = int(row["count"] if row else 0) + 1
            await db.execute(
                "INSERT INTO warnings(chat_id,user_id,count,last_reason,updated_at) VALUES(?,?,?,?,?) "
                "ON CONFLICT(chat_id,user_id) DO UPDATE SET count=excluded.count,last_reason=excluded.last_reason,updated_at=excluded.updated_at",
                (event.chat_id, int(event.sender_id), count, reason, __import__("core.database", fromlist=["now_iso"]).now_iso()),
            )
            return f"warn:{count}"

        try:
            user = await event.get_input_sender()
            if action == "ban":
                await edit_banned(client, event, user, ban_rights())
            else:
                await edit_banned(client, event, user, mute_rights(max(duration, MIN_RESTRICT_SECONDS)))
            return action
        except (RPCError, UnsupportedChat):
            return f"{action}:failed"

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}linkguard\s+scope\s+(normal|all)$"))
    async def linkguard_scope_cmd(event):
        if not event.is_group:
            return await event.reply("❌ فقط داخل گروه.")
        scope = event.pattern_match.group(1)
        await db.update_chat_settings(event.chat_id, linkguard_scope=scope)
        await event.reply("🔗 LinkGuard scope = " + ("فقط افراد عادی (ادمین‌ها معاف)" if scope == "normal" else "همه (ادمین‌ها هم پیامشان پاک می‌شود)"))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}linkguard\s+status$"))
    async def linkguard_status(event):
        if not event.is_group:
            return await event.reply("❌ فقط داخل گروه.")
        cfg = await db.get_chat_settings(event.chat_id)
        await event.reply(
            "🔗 LinkGuard\n"
            f"enabled={bool(cfg.get('linkguard_enabled', False))}\n"
            f"mode={cfg.get('linkguard_mode', 'all')}\n"
            f"scope={cfg.get('linkguard_scope', 'normal')} (normal=بدون ادمین‌ها، all=همه)\n"
            f"action={cfg.get('linkguard_action', 'delete')}\n"
            f"threshold={int(cfg.get('linkguard_threshold', 1))} / {int(cfg.get('linkguard_window', 60))}s\n"
            f"duration={int(cfg.get('linkguard_duration', 600))}s"
        )

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}linkguard(?:\s+(on|off))?(?:\s+(all|invite))?(?:\s+(delete|warn|mute|ban))?(?:\s+(\d+[smhdw]|\d+))?(?:\s+(\d+))?$"))
    async def linkguard_cmd(event):
        if not event.is_group:
            return await event.reply("❌ فقط داخل گروه.")
        # Configuration is only allowed when the user account itself has the necessary rights.
        p = await require_group_right(client, event.chat_id, "delete_messages")
        if not p.allowed:
            return await event.reply("❌ " + p.reason)
        groups = event.pattern_match.groups()
        action_word = groups[2]
        duration_raw = groups[3]
        threshold_raw = groups[4]
        action = action_word or "delete"
        duration = 600
        if action == "mute":
            try:
                duration = parse_duration(duration_raw or "10m")
            except ValueError as exc:
                return await event.reply("❌ " + str(exc))
            b = await require_group_right(client, event.chat_id, "ban_users")
            if not b.allowed:
                return await event.reply("❌ برای mute/ban به Ban Users نیاز داری.")
        elif action == "ban":
            b = await require_group_right(client, event.chat_id, "ban_users")
            if not b.allowed:
                return await event.reply("❌ برای ban به Ban Users نیاز داری.")
        enabled_word = groups[0]
        mode = groups[1] or "all"
        enabled = enabled_word == "on"
        if enabled_word is None:
            return await event.reply(
                "🔗 LinkGuard\n"
                "`.linkguard on all|invite [delete|warn|mute|ban] [duration]`\n"
                "`.linkguard threshold <count> <window> <action> [duration]`\n"
                "`.linkguard scope normal|all` (all = پیام ادمین‌ها هم پاک شود)\n"
                "مثال: `.linkguard threshold 100 10m ban`"
            )
        threshold = max(1, min(int(threshold_raw or 1), 1000))
        await db.update_chat_settings(
            event.chat_id,
            linkguard_enabled=enabled,
            linkguard_action=action,
            linkguard_mode=mode,
            linkguard_duration=duration,
            linkguard_threshold=threshold,
            linkguard_window=60,
        )
        if not enabled:
            link_counts.reset_chat(event.chat_id)
        await event.reply(
            f"🔗 LinkGuard {'روشن' if enabled else 'خاموش'}\n"
            f"mode={mode} | action={action} | threshold={threshold}" + (f" | duration={duration}s" if action == "mute" else "")
        )

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}linkguard\s+threshold\s+(\d+)\s+(\S+)\s+(delete|warn|mute|ban)(?:\s+(\S+))?$"))
    async def linkguard_threshold_cmd(event):
        if not event.is_group:
            return await event.reply("❌ فقط داخل گروه.")
        p = await require_group_right(client, event.chat_id, "delete_messages")
        if not p.allowed:
            return await event.reply("❌ " + p.reason)
        count = max(1, min(int(event.pattern_match.group(1)), 1000))
        try:
            window = max(1, min(parse_duration(event.pattern_match.group(2)), 86400))
        except ValueError as exc:
            return await event.reply("❌ " + str(exc))
        action = event.pattern_match.group(3)
        duration = 600
        if action in {"mute", "ban"}:
            b = await require_group_right(client, event.chat_id, "ban_users")
            if not b.allowed:
                return await event.reply("❌ برای mute/ban به Ban Users نیاز داری.")
        if action == "mute":
            try:
                duration = parse_duration(event.pattern_match.group(4) or "10m")
            except ValueError as exc:
                return await event.reply("❌ " + str(exc))
        await db.update_chat_settings(
            event.chat_id,
            linkguard_enabled=True,
            linkguard_threshold=count,
            linkguard_window=window,
            linkguard_action=action,
            linkguard_duration=duration,
        )
        link_counts.reset_chat(event.chat_id)
        await event.reply(f"🔗 LinkGuard threshold: {count} لینک / {window}s → {action}")

    @client.on(events.ChatAction)
    async def lifecycle(event):
        if not event.is_group:
            return
        cfg = await db.get_chat_settings(event.chat_id)
        if event.user_joined or event.user_added:
            if not cfg.get("welcome_enabled") or not event.user_id:
                return
            try:
                user = await event.get_user()
                chat = await event.get_chat()
                await event.reply(_render(cfg.get("welcome_text", "👋 خوش اومدی {mention}!"), event, user, chat), parse_mode="md")
            except Exception:
                pass
        if event.user_left or event.user_kicked:
            if not cfg.get("leave_enabled") or not event.user_id:
                return
            try:
                user = await event.get_user()
                name = getattr(user, "first_name", None) or str(event.user_id)
                await event.reply(f"👋 {name} از گروه خارج شد.")
            except Exception:
                pass

    @client.on(events.NewMessage)
    async def linkguard(event):
        if not event.is_group or event.out or not event.sender_id or not event.raw_text:
            return
        cfg = await db.get_chat_settings(event.chat_id)
        if not cfg.get("linkguard_enabled"):
            return
        if cfg.get("linkguard_scope", "normal") != "all" and await target_is_admin(client, event.chat_id, event.sender_id, fresh=False):
            return  # scope=normal: admins are exempt; scope=all: admins' links are removed too
        white = await db.fetchone("SELECT 1 FROM whitelist WHERE chat_id=? AND user_id=?", (event.chat_id, int(event.sender_id)))
        if white:
            return
        mode = str(cfg.get("linkguard_mode", "all"))
        if not contains_link(event.raw_text, mode):
            return
        threshold = max(1, int(cfg.get("linkguard_threshold", 1)))
        window = max(1, int(cfg.get("linkguard_window", 60)))
        violation = link_counts.add(event.chat_id, int(event.sender_id), window)
        if threshold > 1 and violation.count < threshold:
            # Every detected link is removed, but escalation waits for the configured threshold.
            try:
                await event.delete()
            except RPCError:
                pass
            return
        result = await _link_action(event, cfg, reason=f"LinkGuard: {violation.count} لینک در {window}s")
        link_counts.reset(event.chat_id, int(event.sender_id))
        if result.startswith("warn:"):
            # Keep automated moderation quiet unless the user explicitly asks for notifications.
            notify = bool(cfg.get("linkguard_notify", False))
            if notify:
                await event.client.send_message(event.chat_id, f"⚠️ LinkGuard: کاربر {event.sender_id} اخطار گرفت.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}rate\s+(\d+)\s+(\S+)$"))
    async def rate_cmd(event):
        if not event.is_group:
            return await event.reply("❌ فقط در گروه.")
        count = max(1, min(int(event.pattern_match.group(1)), 30))
        window = max(1, min(parse_duration(event.pattern_match.group(2)), 3600))
        await db.update_chat_settings(event.chat_id, rate_enabled=True, rate_count=count, rate_window=window)
        await event.reply(f"⏱️ Rate Guard: {count} پیام / {window} ثانیه")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}rate\s+off$"))
    async def rate_off(event):
        await db.update_chat_settings(event.chat_id, rate_enabled=False)
        await event.reply("✅ Rate Guard خاموش شد.")

    @client.on(events.NewMessage)
    async def rate_guard(event):
        if not event.is_group or event.out or not event.sender_id or not event.raw_text or event.raw_text.startswith(PREFIX):
            return
        cfg = await db.get_chat_settings(event.chat_id)
        if not cfg.get("rate_enabled") or (cfg.get("rate_scope", "normal") != "all" and await target_is_admin(client, event.chat_id, event.sender_id, fresh=False)):
            return
        key = (id(client), event.chat_id, int(event.sender_id))
        q = _rate[key]
        now = monotonic()
        q.append(now)
        window = int(cfg.get("rate_window", 10)); count = int(cfg.get("rate_count", 8))
        while q and now - q[0] > window:
            q.popleft()
        if len(q) > count:
            try:
                await event.delete()
            except RPCError:
                pass
            q.clear()
