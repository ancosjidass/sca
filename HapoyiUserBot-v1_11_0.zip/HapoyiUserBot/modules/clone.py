"""`.clone` - copy another user's profile (name, bio, photo, username) onto YOUR account, `.unclone` undoes it.

    .clone                (as a reply)   -> clone the author of the replied message
    .clone @user | 12345  (no reply)     -> clone that user
    .clone ... nouser                    -> do everything except the username
    .unclone                             -> restore your own profile (name, bio, username, photo)

Username rules (Telegram usernames: latin letters/digits/_, 5-32 chars, must start with a letter):
    target has @mol   ->  mol_baraman , then mol10, mol11 ...   (candidates that are too short are skipped)
    target has none   ->  baraman , baraman1, baraman2 ...
The suffix can be changed with CLONE_SUFFIX in .env.
"""
from __future__ import annotations

import logging
import os
import re
import shutil
from pathlib import Path

from telethon import events, utils
from telethon.errors import (
    AboutTooLongError,
    FloodWaitError,
    RPCError,
    UsernameInvalidError,
    UsernameNotModifiedError,
    UsernameOccupiedError,
    UsernamePurchaseAvailableError,
)
from telethon.tl.functions.account import UpdateProfileRequest, UpdateUsernameRequest
from telethon.tl.functions.photos import DeletePhotosRequest, UploadProfilePhotoRequest
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.types import User

from core.identity import my_id
from core.permissions import explain_error, resolve_target

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
SUFFIX = re.sub(r"[^a-z0-9_]", "", (os.getenv("CLONE_SUFFIX", "baraman") or "baraman").lower()) or "baraman"
TMP_DIR = Path(__file__).resolve().parents[1] / "data" / "clone_tmp"
MAX_USERNAME_TRIES = 10
_USERNAME_OK = re.compile(r"^[a-z][a-z0-9_]{4,31}$")


def username_candidates(target_username: str | None, suffix: str = SUFFIX, limit: int = 40):
    """Yield valid username candidates in the order we should try them."""
    base = re.sub(r"[^a-z0-9_]", "", (target_username or "").lower()).strip("_")
    if base:
        first = f"{base}_{suffix}"
        if _USERNAME_OK.match(first) and not first.endswith("__"):
            yield first
        for n in range(1, limit):
            cand = f"{base}{n}"
            if _USERNAME_OK.match(cand):
                yield cand
    else:
        if _USERNAME_OK.match(suffix):
            yield suffix
        for n in range(1, limit):
            cand = f"{suffix}{n}"
            if _USERNAME_OK.match(cand):
                yield cand


def setup(client, db):
    TMP_DIR.mkdir(parents=True, exist_ok=True)

    async def _set_username(candidates) -> tuple[str | None, str]:
        """Try candidates until one is free. Returns (username or None, explanation)."""
        tried = []
        for cand in candidates:
            if len(tried) >= MAX_USERNAME_TRIES:
                break
            tried.append(cand)
            try:
                await client(UpdateUsernameRequest(cand))
                return cand, "ok"
            except UsernameNotModifiedError:
                return cand, "ok (همین بود)"
            except (UsernameOccupiedError, UsernameInvalidError, UsernamePurchaseAvailableError):
                continue
            except FloodWaitError as exc:
                return None, f"محدودیت تلگرام: {exc.seconds}s صبر کن"
            except RPCError as exc:
                return None, explain_error(exc)
        return None, "همهٔ نام‌های پیشنهادی پر بود: " + ", ".join(tried[:5])

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}clone(?:\s+(.+))?$"))
    async def clone(event):
        args = (event.pattern_match.group(1) or "").split()
        skip_username = any(a.lower() in {"nouser", "no-user", "-u"} for a in args)
        args = [a for a in args if a.lower() not in {"nouser", "no-user", "-u"}]
        target = await resolve_target(event, args[0] if args else None)
        if target is None or not isinstance(target, User):
            return await event.reply(f"❌ کاربر پیدا نشد. روی پیامش Reply کن یا `{PREFIX}clone @username` / آیدی عددی بده.")
        me = await client.get_me()
        if target.id == me.id:
            return await event.reply("❌ نمی‌توانی خودت را کلون کنی.")
        if getattr(target, "deleted", False):
            return await event.reply("❌ این اکانت حذف شده است.")

        # --- 1. back up MY profile once (a second clone keeps the very first backup)
        backup = await db.get_kv("clone_backup", None)
        if not backup:
            backup = {
                "first_name": me.first_name or "",
                "last_name": me.last_name or "",
                "about": "",
                "username": me.username or "",
                "uploaded_photo_ids": [],
            }
            try:
                full_me = await client(GetFullUserRequest(me))
                backup["about"] = full_me.full_user.about or ""
            except Exception:  # noqa: BLE001
                pass
            await db.set_kv("clone_backup", backup)

        report = [f"🧬 کلون {utils.get_display_name(target)} ({target.id})"]

        # --- 2. name + bio
        try:
            full_t = await client(GetFullUserRequest(target))
            about = full_t.full_user.about or ""
        except Exception:  # noqa: BLE001
            about = ""
        limit = 140 if getattr(me, "premium", False) else 70
        first = target.first_name or me.first_name or "."
        last = target.last_name or ""
        try:
            try:
                await client(UpdateProfileRequest(first_name=first, last_name=last, about=about[:limit]))
            except AboutTooLongError:
                await client(UpdateProfileRequest(first_name=first, last_name=last, about=about[:70]))
            report.append("✅ اسم و بیو کپی شد" + ("" if about else " (بیوی هدف خالی بود؛ بیو خالی شد)"))
            # keep the profile clock coherent: its "base" last name is now the cloned one
            orig = await db.get_kv("profile_clock_orig", {}) or {}
            if "last_name" in orig:
                backup.setdefault("clock_last_name", orig["last_name"])
                orig["last_name"] = last
                await db.set_kv("profile_clock_orig", orig)
                await db.set_kv("clone_backup", backup)
        except FloodWaitError as exc:
            report.append(f"❌ اسم/بیو: محدودیت تلگرام، {exc.seconds}s صبر کن")
        except RPCError as exc:
            report.append(f"❌ اسم/بیو: {explain_error(exc)}")

        # --- 3. profile photo
        photo_path = None
        try:
            photo_path = await client.download_profile_photo(target, file=str(TMP_DIR / f"{target.id}.jpg"))
        except Exception as exc:  # noqa: BLE001
            log.debug("photo download failed: %s", exc)
        if photo_path:
            try:
                uploaded = await client.upload_file(photo_path)
                res = await client(UploadProfilePhotoRequest(file=uploaded))
                pid = getattr(getattr(res, "photo", None), "id", None)
                if pid:
                    backup["uploaded_photo_ids"] = list(backup.get("uploaded_photo_ids", [])) + [int(pid)]
                    await db.set_kv("clone_backup", backup)
                report.append("✅ عکس پروفایل کپی شد")
            except RPCError as exc:
                report.append(f"❌ عکس: {explain_error(exc)}")
            finally:
                try:
                    os.remove(photo_path)
                except OSError:
                    pass
        else:
            report.append("ℹ️ عکس کپی نشد (عکس ندارد یا برای تو مخفی است)")

        # --- 4. username
        if skip_username:
            report.append("⏭ username کپی نشد (nouser)")
        else:
            name, why = await _set_username(username_candidates(getattr(target, "username", None)))
            report.append(f"✅ username: @{name}" if name else f"❌ username: {why}")

        report.append(f"\n↩️ برگشت به حالت اصلی: `{PREFIX}unclone`")
        await event.reply("\n".join(report))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}unclone$"))
    async def unclone(event):
        backup = await db.get_kv("clone_backup", None)
        if not backup:
            return await event.reply("ℹ️ کلون فعالی وجود ندارد.")
        report = ["↩️ بازگردانی پروفایل"]
        try:
            await client(UpdateProfileRequest(first_name=backup.get("first_name") or ".", last_name=backup.get("last_name", ""), about=(backup.get("about") or "")[:140]))
            report.append("✅ اسم و بیو برگشت")
        except AboutTooLongError:
            await client(UpdateProfileRequest(first_name=backup.get("first_name") or ".", last_name=backup.get("last_name", ""), about=(backup.get("about") or "")[:70]))
            report.append("✅ اسم و بیو برگشت")
        except RPCError as exc:
            report.append(f"❌ اسم/بیو: {explain_error(exc)}")

        ids = {int(x) for x in backup.get("uploaded_photo_ids", [])}
        if ids:
            try:
                photos = await client.get_profile_photos("me", limit=50)
                mine = [utils.get_input_photo(p) for p in photos if int(p.id) in ids]
                if mine:
                    await client(DeletePhotosRequest(mine))
                report.append("✅ عکس‌های کلون‌شده حذف شد (عکس قبلی‌ات برگشت)")
            except RPCError as exc:
                report.append(f"❌ عکس: {explain_error(exc)}")

        old = backup.get("username", "")
        try:
            await client(UpdateUsernameRequest(old))
            report.append(f"✅ username: @{old}" if old else "✅ username خالی شد (مثل قبل)")
        except UsernameNotModifiedError:
            report.append("✅ username همان بود")
        except (UsernameOccupiedError, UsernamePurchaseAvailableError):
            report.append(f"❌ username قبلی (@{old}) الان دست دیگری است و برنگشت.")
        except RPCError as exc:
            report.append(f"❌ username: {explain_error(exc)}")

        orig = await db.get_kv("profile_clock_orig", {}) or {}
        if "clock_last_name" in backup and "last_name" in orig:
            orig["last_name"] = backup["clock_last_name"]
            await db.set_kv("profile_clock_orig", orig)
        await db.execute("DELETE FROM kv WHERE key=?", ("clone_backup",))
        await event.reply("\n".join(report))
