"""Daily helpers: .todo, .conv, .ping, .copy, .backup"""
from __future__ import annotations

import json
import logging
import os
import platform
import random
import re
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

import telethon
from telethon import events
from telethon.errors import RPCError
from telethon.tl.functions import PingRequest
from telethon.tl.types import MessageMediaWebPage

from core.identity import my_id
from core.permissions import explain_error, get_real_reply
from providers.crypto import MarketProvider
from providers.iran import RateUnavailable, parse_number, shared

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
BASE = Path(__file__).resolve().parents[1]
STARTED = time.time()
TOMAN = {"toman", "تومان", "تومن", "irt", "t"}
RIAL = {"rial", "ریال", "irr"}
FIAT = {"usd": "USD", "دلار": "USD", "dollar": "USD", "$": "USD", "eur": "EUR", "یورو": "EUR", "euro": "EUR", "€": "EUR"}
_SUFFIX = {"k": 1e3, "m": 1e6, "b": 1e9, "هزار": 1e3, "میلیون": 1e6, "میلیارد": 1e9}
_FA = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


def parse_amount(token: str) -> float:
    """'280000' '280,000' '۲۸۰۰۰۰' '280k' '1.5m' -> float"""
    t = token.translate(_FA).replace(",", "").replace("٬", "").lower()
    m = re.fullmatch(r"(\d+(?:\.\d+)?)(k|m|b)?", t)
    if not m:
        raise ValueError("مقدار نامعتبر")
    return float(m.group(1)) * (_SUFFIX[m.group(2)] if m.group(2) else 1)


def fmt_number(x: float) -> str:
    if x == 0:
        return "0"
    if abs(x) >= 100:
        return f"{x:,.0f}"
    if abs(x) >= 1:
        return f"{x:,.2f}"
    return f"{x:.6g}"


def _uptime(seconds: float) -> str:
    d, r = divmod(int(seconds), 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    return " ".join(x for x in (f"{d}d" if d else "", f"{h}h" if h else "", f"{m}m" if m else "", f"{s}s") if x)


def setup(client, db):
    provider = MarketProvider(cache_seconds=5)
    rates = shared()

    # ------------------------------------------------------------------ .todo
    TODO_HELP = (
        "📝 Todo\n"
        f"`{PREFIX}todo add متن` | `{PREFIX}todo` (لیست) | `{PREFIX}todo done <id>` | `{PREFIX}todo undone <id>`\n"
        f"`{PREFIX}todo del <id>` | `{PREFIX}todo clear` (انجام‌شده‌ها) | `{PREFIX}todo clear all`"
    )

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}todo(?:\s+(.*))?$"))
    async def todo(event):
        owner = await my_id(client)
        arg = (event.pattern_match.group(1) or "").strip()
        word, _, rest = arg.partition(" ")
        word, rest = word.lower(), rest.strip()
        if word in {"", "list"}:
            rows = await db.fetchall("SELECT id,text,done FROM todos WHERE owner_id=? ORDER BY done,id", (owner,))
            if not rows:
                return await event.reply("📝 لیست کارها خالی است.\n\n" + TODO_HELP)
            open_n = sum(1 for r in rows if not r["done"])
            lines = [f"📝 کارها ({open_n} باز از {len(rows)})"]
            lines += [f"{'✅' if r['done'] else '⬜'} #{r['id']} {r['text']}" for r in rows]
            return await event.reply("\n".join(lines)[:3900])
        if word == "add":
            if not rest:
                return await event.reply("❌ متن کار را بنویس.")
            if len(rest) > 500:
                return await event.reply("❌ متن خیلی طولانی است (حداکثر ۵۰۰ حرف).")
            tid = await db.insert("INSERT INTO todos(owner_id,text,done,created_at) VALUES(?,?,0,?)", (owner, rest, datetime.now(timezone.utc).isoformat()))
            return await event.reply(f"⬜ #{tid} اضافه شد.")
        if word in {"done", "undone", "del", "delete", "rm"}:
            if not rest.lstrip("#").isdigit():
                return await event.reply(f"فرمت: `{PREFIX}todo {word} <id>`")
            tid = int(rest.lstrip("#"))
            if word in {"done", "undone"}:
                n = await db.execute("UPDATE todos SET done=? WHERE id=? AND owner_id=?", (1 if word == "done" else 0, tid, owner))
            else:
                n = await db.execute("DELETE FROM todos WHERE id=? AND owner_id=?", (tid, owner))
            if not n:
                return await event.reply("ℹ️ کاری با این شماره پیدا نشد.")
            return await event.reply({"done": f"✅ #{tid} انجام شد.", "undone": f"⬜ #{tid} دوباره باز شد."}.get(word, f"🗑 #{tid} حذف شد."))
        if word == "clear":
            if rest.lower() == "all":
                await db.execute("DELETE FROM todos WHERE owner_id=?", (owner,))
                return await event.reply("🗑 همهٔ کارها پاک شد.")
            n = await db.execute("DELETE FROM todos WHERE owner_id=? AND done=1", (owner,))
            return await event.reply(f"🗑 {n} کار انجام‌شده پاک شد.")
        await event.reply("❌ فرمت نامعتبر.\n\n" + TODO_HELP)

    # ------------------------------------------------------------------ .conv
    async def toman_per_unit(unit: str) -> tuple[float, str]:
        """(Toman for ONE unit, source label)."""
        low = unit.lower()
        if low in TOMAN:
            return 1.0, "تومان"
        if low in RIAL:
            return 0.1, "ریال"
        fiat = FIAT.get(low)
        if fiat == "USD":
            return (await rates.usd_toman()).toman, "دلار"
        if fiat == "EUR":
            return (await rates.eur_toman()).toman, "یورو"
        if provider.resolve(unit):
            q = await provider.quote(unit)
            if q.toman is not None:
                return q.toman, q.symbol
            return q.usd * (await rates.usd_toman()).toman, q.symbol
        raise ValueError(f"واحد ناشناخته: {unit}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}conv(?:\s+(.+))?$"))
    async def conv(event):
        raw = (event.pattern_match.group(1) or "").strip()
        tokens = [t for t in re.split(r"\s+", raw) if t and t.lower() not in {"to", "به", "->", "→", "in"}]
        usage = f"فرمت: `{PREFIX}conv 100 usd` یا `{PREFIX}conv 0.5 btc toman` یا `{PREFIX}conv 5m toman usd`"
        if len(tokens) < 2:
            return await event.reply(usage)
        # "100 usd" / "100usd"
        amount_tok, rest = tokens[0], tokens[1:]
        try:
            amount = parse_amount(amount_tok)
        except ValueError:
            glued = re.fullmatch(r"([0-9۰-۹.,٬]+[kKmMbB]?)(\D+)", amount_tok)
            if glued:
                amount_tok, rest = glued.group(1), [glued.group(2)] + rest
            try:
                amount = parse_amount(amount_tok)
            except ValueError:
                return await event.reply("❌ مقدار نامعتبر است.\n" + usage)
        src = rest[0]
        dst = rest[1] if len(rest) > 1 else None
        try:
            src_rate, src_name = await toman_per_unit(src)
            total_toman = amount * src_rate
            if dst:
                dst_rate, dst_name = await toman_per_unit(dst)
                return await event.reply(f"💱 {fmt_number(amount)} {src_name} = {fmt_number(total_toman / dst_rate)} {dst_name}")
            lines = [f"💱 {fmt_number(amount)} {src_name}", f"🇮🇷 {fmt_number(total_toman)} تومان"]
            try:
                usd_rate = (await rates.usd_toman()).toman
                if FIAT.get(src.lower()) != "USD":
                    lines.append(f"💵 {fmt_number(total_toman / usd_rate)} دلار")
            except RateUnavailable:
                pass
            return await event.reply("\n".join(lines))
        except ValueError as exc:
            return await event.reply("❌ " + str(exc) + "\n" + usage)
        except RateUnavailable as exc:
            return await event.reply(f"❌ قیمت در دسترس نیست: {exc}"[:400])
        except Exception as exc:  # noqa: BLE001
            return await event.reply(f"❌ تبدیل نشد: {exc.__class__.__name__}")

    # ------------------------------------------------------------------ .ping
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}ping$"))
    async def ping(event):
        t0 = time.monotonic()
        await client(PingRequest(ping_id=random.getrandbits(62)))
        rtt = (time.monotonic() - t0) * 1000
        try:
            version = json.loads((BASE / "VERSION.json").read_text(encoding="utf-8")).get("version", "?")
        except (OSError, ValueError):
            version = "?"
        await event.reply(
            f"🏓 Pong: {rtt:.0f}ms\n"
            f"⏱ آپتایم: {_uptime(time.time() - STARTED)}\n"
            f"🧩 Hāpoyi v{version} | Telethon {telethon.__version__} | Python {platform.python_version()}"
        )

    # ------------------------------------------------------------------ .copy
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}copy(?:\s+(\S+))?$"))
    async def copy(event):
        m = await get_real_reply(event)
        if m is None:
            return await event.reply(f"❌ روی پیام Reply کن. (`{PREFIX}copy` همین‌جا، `{PREFIX}copy me` به Saved Messages، `{PREFIX}copy @chat`)")
        arg = event.pattern_match.group(1)
        if not arg:
            target = event.chat_id
        elif arg.lower() in {"me", "saved"}:
            target = "me"
        else:
            try:
                target = await client.get_entity(int(arg) if re.fullmatch(r"-?\d+", arg) else arg)
            except Exception:  # noqa: BLE001
                return await event.reply("❌ مقصد پیدا نشد.")
        entities = getattr(m, "entities", None)
        media = getattr(m, "media", None)
        try:
            if media is not None and not isinstance(media, MessageMediaWebPage):
                if getattr(m, "poll", None):
                    return await event.reply("❌ نظرسنجی قابل کپی نیست.")
                try:
                    await client.send_file(target, media, caption=m.raw_text or "", formatting_entities=entities)
                except RPCError:
                    # restricted / unreferencable media -> download and upload a real copy
                    workdir = tempfile.mkdtemp()
                    path = await m.download_media(file=workdir + "/")
                    if not path:
                        return await event.reply("❌ کپی نشد (مدیا قابل دانلود نیست).")
                    try:
                        await client.send_file(target, path, caption=m.raw_text or "", formatting_entities=entities)
                    finally:
                        try:
                            os.remove(path)
                            os.rmdir(workdir)
                        except OSError:
                            pass
            elif m.raw_text:
                await client.send_message(target, m.raw_text, formatting_entities=entities, link_preview=False)
            else:
                return await event.reply("❌ چیزی برای کپی نبود.")
        except RPCError as exc:
            return await event.reply(f"❌ کپی نشد: {explain_error(exc)}")
        if target == event.chat_id:
            await event.delete()
        else:
            await event.reply("✅ کپی شد.")

    # ------------------------------------------------------------------ .backup
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}backup$"))
    async def backup(event):
        fd, path = tempfile.mkstemp(suffix=".db", prefix="hapoyi_backup_")
        os.close(fd)
        try:
            await db.backup_to(path)
            stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d_%H-%M")
            await client.send_file("me", path, caption=f"💾 Hāpoyi database backup\n{stamp} UTC", file_name=f"hapoyi_{stamp}.db")
        finally:
            try:
                os.remove(path)
            except OSError:
                pass
        await event.reply("💾 نسخهٔ پشتیبان دیتابیس به Saved Messages فرستاده شد. (فایل session داخلش نیست)")
