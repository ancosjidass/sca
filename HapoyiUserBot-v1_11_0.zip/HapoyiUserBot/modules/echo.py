"""Echo: people YOU allow (per chat) can make your account say something by writing `اکو <text>` / `echo <text>`.

    .echo add [@user|id]      (or Reply)   allow somebody in THIS chat
    .echo del [@user|id]      (or Reply)   remove him
    .echo list [all]                       who is allowed here (all = every chat)
    .echo clear [allchats]                 empty the list of this chat (or of every chat)
    .echo on|off                           global switch
    .echo edit on|off                      after ~1s edit the echo to "اکو از <mention>"   (default on)
    .echo wipe on|off                      delete the echoer's trigger message when you may   (default on)
    .echo status

How an echo works (Ali is allowed in this chat):
  * Ali writes `اکو سلام` as a reply to Hasan  -> your account replies `سلام` to Hasan.
    Without a reply it just posts `سلام` in the chat. Not on the list = silently ignored.
  * Text only (media / captions are ignored).
  * You are an admin with Delete Messages -> Ali's `اکو ...` message is deleted. Otherwise it stays.
  * The raw text is sent first (so other bots can react to it), then ~1s later it is edited to `اکو از <Ali>`.
  * The echoed message is remembered: your own commands NEVER fire on it (`اکو .ban` does nothing),
    and `.msginfo` on it shows who caused it.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from collections import OrderedDict
from datetime import datetime, timezone

from telethon import events
from telethon.errors import FloodWaitError, RPCError
from telethon.tl.types import MessageMediaWebPage

from core.identity import my_id
from core.permissions import explain_error, reply_to_id, require_group_right, resolve_target
from modules.tagger import mention
from utils.activity import display_name
from utils.targets import target_label

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TRIGGER = re.compile(r"(?is)^\s*(?:اکو|echo)\s+(.+?)\s*$")
COOLDOWN = float(os.getenv("ECHO_COOLDOWN", "1.0") or 1.0)
EDIT_DELAY = float(os.getenv("ECHO_EDIT_DELAY", "1.0") or 1.0)
ATTRIBUTION = os.getenv("ECHO_ATTRIBUTION", "اکو از") or "اکو از"
MAX_TEXT = 4000
PENDING_TTL = 20.0
MAX_IDS = 5000


def setup(client, db):
    ids: "OrderedDict[tuple[int, int], bool]" = OrderedDict()
    pending: list[tuple[int, str, float]] = []
    last_use: dict[tuple[int, int], float] = {}
    loaded = {"done": False}

    # ------------------------------------------------------------------ "is this message an echo?" (used by core/guard.py)
    def _remember(chat_id: int, message_id: int) -> None:
        ids[(int(chat_id), int(message_id))] = True
        while len(ids) > MAX_IDS:
            ids.popitem(last=False)

    def is_echo_event(event) -> bool:
        chat_id = int(getattr(event, "chat_id", 0) or 0)
        key = (chat_id, int(getattr(event, "id", 0) or 0))
        if key in ids:
            return True
        now = time.monotonic()
        pending[:] = [x for x in pending if x[2] > now]
        text = (getattr(event, "raw_text", "") or "").strip()
        for i, (chat, t, _) in enumerate(pending):
            if chat == chat_id and t == text:
                pending.pop(i)  # the outgoing update can arrive before send_message() returns
                _remember(*key)
                return True
        return False

    client._hapoyi_echo_check = is_echo_event

    async def ensure_loaded() -> None:
        if not loaded["done"]:
            loaded["done"] = True
            for r in await db.fetchall("SELECT chat_id,message_id FROM echo_messages ORDER BY created_at DESC LIMIT 2000"):
                _remember(r["chat_id"], r["message_id"])

    async def _flag(name: str, default: bool) -> bool:
        return bool(await db.get_kv(name, default))

    # ------------------------------------------------------------------ the echo itself
    @client.on(events.NewMessage(incoming=True))
    async def echo_watcher(event):
        if getattr(event, "out", False) or not event.is_group or not event.sender_id:
            return
        text = event.raw_text or ""
        m = TRIGGER.match(text)
        if not m:
            return
        media = getattr(event.message, "media", None)
        if media is not None and not isinstance(media, MessageMediaWebPage):
            return  # text only
        await ensure_loaded()
        chat, sender = int(event.chat_id), int(event.sender_id)
        if not await _flag("echo_enabled", True):
            return
        allowed = await db.fetchone("SELECT 1 FROM echo_users WHERE chat_id=? AND user_id=?", (chat, sender))
        if not allowed:
            return  # not on the list: ignore silently, no "you are not allowed" message
        now = time.monotonic()
        if now - last_use.get((chat, sender), 0.0) < COOLDOWN:
            return
        last_use[(chat, sender)] = now
        echoed = m.group(1).strip()
        if not echoed or len(echoed) > MAX_TEXT:
            return

        # register BEFORE sending: our own outgoing update must be recognised as an echo even if it races send_message()
        pending.append((chat, echoed, now + PENDING_TTL))
        try:
            sent = await client.send_message(chat, echoed, reply_to=reply_to_id(event), link_preview=False)
        except FloodWaitError as exc:
            pending[:] = [x for x in pending if not (x[0] == chat and x[1] == echoed)]
            log.warning("echo: flood wait %ss in %s", exc.seconds, chat)
            return
        except RPCError as exc:
            pending[:] = [x for x in pending if not (x[0] == chat and x[1] == echoed)]
            log.warning("echo: send failed in %s: %s", chat, exc.__class__.__name__)
            return
        _remember(chat, sent.id)
        who = None
        try:
            who = await event.get_sender()
        except Exception:  # noqa: BLE001
            pass
        name = display_name(who, str(sender)) if who else str(sender)
        await db.execute(
            "INSERT OR REPLACE INTO echo_messages(chat_id,message_id,source_user_id,source_name,source_msg_id,text,created_at) VALUES(?,?,?,?,?,?,?)",
            (chat, sent.id, sender, name, event.id, echoed[:1000], datetime.now(timezone.utc).isoformat()),
        )

        # delete the echoer's trigger message when we are allowed to
        if await _flag("echo_wipe", True):
            perm = await require_group_right(client, chat, "delete_messages", fresh=False)
            if perm.allowed:
                try:
                    await event.delete()
                except RPCError:
                    pass

        # raw text first (other bots see/execute it), then the attribution edit
        if await _flag("echo_edit", True) and who is not None:
            await asyncio.sleep(EDIT_DELAY)
            try:
                await client.edit_message(chat, sent.id, f"{ATTRIBUTION} {mention(who)}", parse_mode="md", link_preview=False)
            except RPCError as exc:
                log.debug("echo attribution edit failed: %s", exc.__class__.__name__)

    # ------------------------------------------------------------------ .echo management
    HELP = (
        "🔁 Echo\n"
        f"`{PREFIX}echo add [@user|id]` (یا Reply) — اجازهٔ اکو در همین گپ\n"
        f"`{PREFIX}echo del [@user|id]` | `{PREFIX}echo list [all]` | `{PREFIX}echo clear [allchats]`\n"
        f"`{PREFIX}echo on|off` — کلید کلی\n"
        f"`{PREFIX}echo edit on|off` — ادیت بعد از ~۱ ثانیه به «اکو از ...»\n"
        f"`{PREFIX}echo wipe on|off` — پاک‌کردن پیام اکوکننده (اگر دسترسی حذف داری)\n"
        "کاربر مجاز می‌نویسد: `اکو سلام` (روی پیام کسی Reply کند تا روی همان ریپلای شود)"
    )

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}echo(?:\s+(.*))?$"))
    async def echo_cmd(event):
        parts = (event.pattern_match.group(1) or "").split()
        word = parts[0].lower() if parts else ""
        chat = event.chat_id

        if word in {"", "status"}:
            n = await db.fetchone("SELECT COUNT(*) AS n FROM echo_users WHERE chat_id=?", (chat,))
            return await event.reply(
                f"🔁 Echo: {'ON' if await _flag('echo_enabled', True) else 'OFF'} | ادیت: {'ON' if await _flag('echo_edit', True) else 'OFF'} | "
                f"پاک‌کردن پیام: {'ON' if await _flag('echo_wipe', True) else 'OFF'}\nمجازها در این گپ: {n['n']}\n\n{HELP}")

        if word in {"on", "off"}:
            await db.set_kv("echo_enabled", word == "on")
            return await event.reply("✅ Echo " + ("روشن شد." if word == "on" else "خاموش شد."))
        if word in {"edit", "wipe"}:
            if len(parts) < 2 or parts[1].lower() not in {"on", "off"}:
                return await event.reply(f"فرمت: `{PREFIX}echo {word} on|off`")
            await db.set_kv(f"echo_{word}", parts[1].lower() == "on")
            return await event.reply(f"✅ echo {word} = {parts[1].lower()}")

        if word == "list":
            everywhere = len(parts) > 1 and parts[1].lower() == "all"
            rows = await db.fetchall(
                "SELECT chat_id,user_id,name FROM echo_users" + ("" if everywhere else " WHERE chat_id=?") + " ORDER BY chat_id,created_at",
                () if everywhere else (chat,))
            if not rows:
                return await event.reply("🔁 لیست اکو خالی است.")
            lines = [f"🔁 مجازها ({len(rows)})"]
            for r in rows:
                lines.append(f"• {r['name'] or '—'} ({r['user_id']})" + (f" — chat {r['chat_id']}" if everywhere else ""))
            return await event.reply("\n".join(lines)[:3900])

        if word == "clear":
            if len(parts) > 1 and parts[1].lower() == "allchats":
                await db.execute("DELETE FROM echo_users")
                return await event.reply("🗑 لیست اکوی همهٔ گپ‌ها پاک شد.")
            await db.execute("DELETE FROM echo_users WHERE chat_id=?", (chat,))
            return await event.reply("🗑 لیست اکوی این گپ پاک شد.")

        if word in {"add", "del", "remove", "rm"}:
            if not event.is_group:
                return await event.reply("❌ اکو فقط برای گروه‌ها تعریف می‌شود.")
            user = await resolve_target(event, parts[1] if len(parts) > 1 else None)
            if user is None:
                return await event.reply(f"❌ کاربر پیدا نشد. Reply کن یا `{PREFIX}echo {word} @username` بزن.")
            uid = int(user.id)
            if uid == await my_id(client):
                return await event.reply("❌ خودت را نمی‌توانی اضافه کنی.")
            if word == "add":
                await db.execute(
                    "INSERT INTO echo_users(chat_id,user_id,name,created_at) VALUES(?,?,?,?) ON CONFLICT(chat_id,user_id) DO UPDATE SET name=excluded.name",
                    (chat, uid, display_name(user, str(uid)), datetime.now(timezone.utc).isoformat()))
                return await event.reply(f"✅ {target_label(user)} در این گپ مجاز به اکو شد.")
            n = await db.execute("DELETE FROM echo_users WHERE chat_id=? AND user_id=?", (chat, uid))
            return await event.reply(f"✅ {target_label(user)} از لیست اکو حذف شد." if n else f"ℹ️ {target_label(user)} در لیست نبود.")

        await event.reply("❌ فرمت نامعتبر.\n\n" + HELP)
