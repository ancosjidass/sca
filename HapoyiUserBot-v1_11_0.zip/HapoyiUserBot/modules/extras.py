"""Everyday power tools: later, top, export, slowmode, lock/unlock, delall, poll, qr, pass, link."""
from __future__ import annotations

import asyncio
import inspect
import logging
import os
import re
import secrets
import string
import tempfile
import time
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from telethon import events, types
from telethon.errors import RPCError
from telethon.tl.functions.channels import GetFullChannelRequest, ToggleSlowModeRequest
from telethon.tl.functions.messages import (
    DeleteScheduledMessagesRequest,
    EditChatDefaultBannedRightsRequest,
    ExportChatInviteRequest,
)

from core.identity import my_id
from core.permissions import (
    explain_error,
    get_real_reply,
    reply_to_id,
    require_group_right,
    resolve_target,
)
from modules.message_lifecycle import delete_in_batches
from utils.activity import display_name, scan_activity
from utils.formatting import parse_duration

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TZ = ZoneInfo(os.getenv("TIMEZONE", "Asia/Tehran"))
SLOW_VALUES = (0, 10, 30, 60, 300, 900, 3600)
LATER_MIN = 15
LOCK_TYPES = {
    "all": ("send_messages",), "msg": ("send_messages",), "messages": ("send_messages",), "text": ("send_messages",),
    "media": ("send_media",), "stickers": ("send_stickers",), "sticker": ("send_stickers",),
    "gifs": ("send_gifs",), "gif": ("send_gifs",), "links": ("embed_links",), "link": ("embed_links",),
    "polls": ("send_polls",), "poll": ("send_polls",), "invite": ("invite_users",), "pin": ("pin_messages",),
    "info": ("change_info",),
}
LOCK_LABELS = {
    "send_messages": "ارسال پیام", "send_media": "مدیا", "send_stickers": "استیکر", "send_gifs": "گیف",
    "embed_links": "پیش‌نمایش لینک", "send_polls": "نظرسنجی", "invite_users": "افزودن عضو",
    "pin_messages": "پین", "change_info": "تغییر اطلاعات گروه",
}
_RIGHT_FIELDS = [n for n in inspect.signature(types.ChatBannedRights.__init__).parameters if n not in {"self", "until_date"}]


def _local(ts: datetime) -> str:
    return ts.astimezone(TZ).strftime("%Y-%m-%d %H:%M")


def setup(client, db):
    async def _temp_note(chat_id: int, text: str, seconds: float = 6) -> None:
        try:
            msg = await client.send_message(chat_id, text)
            await db.insert(
                "INSERT INTO delete_jobs(chat_id,message_ids,run_at,kind,preview,created_at) VALUES(?,?,?,?,?,?)",
                (chat_id, f"[{msg.id}]", time.time() + seconds, "note", text[:40], datetime.now(timezone.utc).isoformat()),
            )
        except RPCError:
            pass

    # ------------------------------------------------------------------ 1. .later  (server-side scheduled messages)
    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}later(?:\s+(.+))?$"))
    async def later(event):
        arg = (event.pattern_match.group(1) or "").strip()
        if not arg:
            return await event.reply(f"🕒 `{PREFIX}later 10m متن` — بعد از ۱۰ دقیقه ارسال می‌شود (توسط خود تلگرام، حتی اگر سلف خاموش باشد)\n`{PREFIX}later list` | `{PREFIX}later del <id|all>`")
        word, _, rest = arg.partition(" ")
        word = word.lower()
        if word == "list":
            rows = []
            async for m in client.iter_messages(event.chat_id, scheduled=True, limit=50):
                rows.append(f"#{m.id} — {_local(m.date)} — {(m.raw_text or '[مدیا]')[:50]}")
            return await event.reply("🕒 زمان‌بندی‌شده‌ها\n" + "\n".join(rows) if rows else "🕒 پیام زمان‌بندی‌شده‌ای نیست.")
        if word in {"del", "delete", "cancel"}:
            which = rest.strip().lstrip("#").lower()
            ids: list[int]
            if which == "all":
                ids = [m.id async for m in client.iter_messages(event.chat_id, scheduled=True, limit=100)]
            elif which.isdigit():
                ids = [int(which)]
            else:
                return await event.reply("❌ شمارهٔ پیام یا all بده.")
            if not ids:
                return await event.reply("ℹ️ چیزی برای حذف نبود.")
            try:
                await client(DeleteScheduledMessagesRequest(peer=await client.get_input_entity(event.chat_id), id=ids))
            except RPCError as exc:
                return await event.reply(f"❌ حذف نشد: {explain_error(exc)}")
            return await event.reply(f"✅ {len(ids)} پیام زمان‌بندی‌شده حذف شد.")
        try:
            seconds = parse_duration(word)
        except ValueError as exc:
            return await event.reply("❌ " + str(exc))
        text = rest.strip()
        if not text:
            return await event.reply("❌ متن را هم بنویس.")
        if seconds < LATER_MIN:
            return await event.reply(f"❌ حداقل زمان {LATER_MIN} ثانیه است.")
        try:
            await client.send_message(event.chat_id, text, schedule=timedelta(seconds=seconds), reply_to=reply_to_id(event))
        except RPCError as exc:
            return await event.reply(f"❌ زمان‌بندی نشد: {explain_error(exc)}")
        when = datetime.now(timezone.utc) + timedelta(seconds=seconds)
        await event.reply(f"🕒 زمان‌بندی شد برای {_local(when)} ({TZ.key})")

    # ------------------------------------------------------------------ 2. .top
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}top(?:\s+(\d+))?$"))
    async def top(event):
        n = max(1, min(int(event.pattern_match.group(1) or 10), 50))
        limit = int(os.getenv("TOP_SCAN_LIMIT", "5000") or 5000)
        counts, users = await scan_activity(client, event.chat_id, limit)
        if not counts:
            return await event.reply("ℹ️ پیامی برای شمارش پیدا نشد.")
        total = sum(counts.values())
        lines = [f"🏆 فعال‌ترین‌ها (از {total} پیام اخیر)"]
        for i, (uid, c) in enumerate(counts.most_common(n), 1):
            user = users.get(uid)
            name = display_name(user, str(uid)) if user else str(uid)
            lines.append(f"{i}. {name} — {c} پیام ({c * 100 // total}٪)")
        await event.reply("\n".join(lines)[:3900])

    # ------------------------------------------------------------------ 3. .export
    def _media_tag(m) -> str:
        for attr, label in (("photo", "عکس"), ("sticker", "استیکر"), ("voice", "ویس"), ("video_note", "ویدیونوت"),
                            ("video", "ویدیو"), ("gif", "گیف"), ("audio", "موزیک"), ("poll", "نظرسنجی"), ("document", "فایل")):
            if getattr(m, attr, None):
                return f"[{label}]"
        return "[مدیا]" if getattr(m, "media", None) else ""

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}export(?:\s+(\d+))?$"))
    async def export(event):
        n = max(1, min(int(event.pattern_match.group(1) or 200), 5000))
        rows = []
        async for m in client.iter_messages(event.chat_id, limit=n):
            if getattr(m, "action", None):
                continue
            sender = getattr(m, "sender", None)
            who = display_name(sender, str(m.sender_id or "?")) if sender else str(m.sender_id or "?")
            body = " ".join(x for x in ((m.raw_text or "").replace("\n", "\n    "), _media_tag(m)) if x)
            rows.append(f"[{_local(m.date)}] {who}: {body}")
        if not rows:
            return await event.reply("ℹ️ پیامی پیدا نشد.")
        rows.reverse()
        fd, path = tempfile.mkstemp(suffix=".txt", prefix="export_")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(f"# chat {event.chat_id} — {len(rows)} messages — exported {_local(datetime.now(timezone.utc))}\n\n")
                fh.write("\n".join(rows))
            await client.send_file("me", path, caption=f"📄 {len(rows)} پیام از چت {event.chat_id}")
        finally:
            try:
                os.remove(path)
            except OSError:
                pass
        await event.reply(f"📄 {len(rows)} پیام به Saved Messages فرستاده شد.")

    # ------------------------------------------------------------------ 4. .slowmode
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}slowmode(?:\s+(\S+))?$"))
    async def slowmode(event):
        if not event.is_group:
            return await event.reply("❌ فقط در گروه.")
        raw = (event.pattern_match.group(1) or "").lower()
        allowed_txt = "off, 10s, 30s, 1m, 5m, 15m, 1h"
        if not raw:
            return await event.reply(f"فرمت: `{PREFIX}slowmode <{allowed_txt}>`")
        if raw in {"off", "0"}:
            seconds = 0
        else:
            try:
                seconds = int(raw) if raw.isdigit() else parse_duration(raw)
            except ValueError:
                return await event.reply(f"❌ مقدار مجاز: {allowed_txt}")
        if seconds not in SLOW_VALUES:
            return await event.reply(f"❌ تلگرام فقط این مقدارها را می‌پذیرد: {allowed_txt}")
        perm = await require_group_right(client, event.chat_id, "change_info")
        if not perm.allowed:
            return await event.reply("❌ شما دسترسی ندارید: " + perm.reason)
        peer = await client.get_input_entity(event.chat_id)
        if not isinstance(peer, types.InputPeerChannel):
            return await event.reply("❌ حالت آهسته فقط در سوپرگروه‌ها وجود دارد.")
        try:
            await client(ToggleSlowModeRequest(types.InputChannel(peer.channel_id, peer.access_hash), seconds))
        except RPCError as exc:
            return await event.reply(f"❌ انجام نشد: {explain_error(exc)}")
        await event.reply("🐢 حالت آهسته خاموش شد." if seconds == 0 else f"🐢 حالت آهسته: {seconds} ثانیه")

    # ------------------------------------------------------------------ 5. .lock / .unlock
    async def _change_default_rights(event, lock: bool | None):
        if not event.is_group:
            return await event.reply("❌ فقط در گروه.")
        perm = await require_group_right(client, event.chat_id, "ban_users")
        if not perm.allowed:
            return await event.reply("❌ شما دسترسی ندارید: " + perm.reason)
        chat = await event.get_chat()
        current = getattr(chat, "default_banned_rights", None)
        flags = {name: bool(getattr(current, name, False)) for name in _RIGHT_FIELDS}
        if lock is None:  # status
            on = [LOCK_LABELS[k] for k in LOCK_LABELS if flags.get(k)]
            return await event.reply("🔐 قفل‌های فعال: " + ("، ".join(on) if on else "هیچ‌کدام"))
        words = (event.pattern_match.group(1) or "all").lower().split()
        unknown = [w for w in words if w not in LOCK_TYPES]
        if unknown:
            return await event.reply("❌ نوع نامعتبر: " + ", ".join(unknown) + "\nمجاز: " + ", ".join(sorted(set(LOCK_TYPES))))
        changed = []
        for w in words:
            for field in LOCK_TYPES[w]:
                # for lock: True means the right is taken away; unlock gives it back
                flags[field] = lock
                changed.append(LOCK_LABELS[field])
        try:
            await client(EditChatDefaultBannedRightsRequest(peer=await client.get_input_entity(event.chat_id), banned_rights=types.ChatBannedRights(until_date=None, **flags)))
        except RPCError as exc:
            return await event.reply(f"❌ انجام نشد: {explain_error(exc)}")
        await event.reply(("🔒 قفل شد: " if lock else "🔓 باز شد: ") + "، ".join(dict.fromkeys(changed)))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}lock(?:\s+(?!status$)(.+))?$"))
    async def lock(event):
        await _change_default_rights(event, True)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}unlock(?:\s+(.+))?$"))
    async def unlock(event):
        await _change_default_rights(event, False)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}lock\s+status$"))
    async def lock_status(event):
        await _change_default_rights(event, None)

    # ------------------------------------------------------------------ 6. .delall  (clean one user's messages)
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}delall(?:\s+(.+))?$"))
    async def delall(event):
        if not event.is_group:
            return await event.reply("❌ فقط در گروه.")
        perm = await require_group_right(client, event.chat_id, "delete_messages")
        if not perm.allowed:
            return await event.reply("❌ شما دسترسی ندارید: " + perm.reason)
        tokens = (event.pattern_match.group(1) or "").split()
        replied = await get_real_reply(event)
        count = None
        if replied is not None:
            explicit = None
            count = int(tokens[0]) if tokens and tokens[0].isdigit() else None
        else:
            explicit = tokens[0] if tokens else None
            count = int(tokens[1]) if len(tokens) > 1 and tokens[1].isdigit() else None
        user = await resolve_target(event, explicit)
        if user is None:
            return await event.reply(f"❌ Reply کن یا `{PREFIX}delall @user [تعداد]` بزن.")
        if int(user.id) == await my_id(client):
            return await event.reply(f"❌ برای پیام‌های خودت از `{PREFIX}mesdel all` استفاده کن.")
        limit = max(1, min(count or 5000, 20000))
        ids = []
        try:
            async for m in client.iter_messages(event.chat_id, from_user=user, limit=limit):
                ids.append(m.id)
        except RPCError as exc:
            return await event.reply(f"❌ پیام‌ها خوانده نشد: {explain_error(exc)}")
        if not ids:
            return await event.reply("ℹ️ پیامی از این کاربر پیدا نشد.")
        done = await delete_in_batches(client, event.chat_id, ids + [event.id])
        await _temp_note(event.chat_id, f"🧹 {max(done - 1, 0)} پیام از {display_name(user)} حذف شد.")

    # ------------------------------------------------------------------ 7. .poll
    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}poll\s+(.+)$"))
    async def poll(event):
        raw = event.pattern_match.group(1).strip()
        multi = public = False
        while True:  # optional flags in front: multi / public
            head, _, tail = raw.partition(" ")
            if head.lower() == "multi":
                multi, raw = True, tail.strip()
            elif head.lower() == "public":
                public, raw = True, tail.strip()
            else:
                break
        parts = [x.strip() for x in re.split(r"\||\n", raw) if x.strip()]
        if len(parts) < 3:
            return await event.reply(f"فرمت: `{PREFIX}poll [multi] [public] سؤال | گزینه ۱ | گزینه ۲ | ...` (۲ تا ۱۰ گزینه)")
        question, options = parts[0], parts[1:]
        if len(options) > 10:
            return await event.reply("❌ حداکثر ۱۰ گزینه.")
        if len(question) > 255 or any(len(o) > 100 for o in options):
            return await event.reply("❌ سؤال حداکثر ۲۵۵ و هر گزینه حداکثر ۱۰۰ حرف.")
        if len(set(options)) != len(options):
            return await event.reply("❌ گزینه‌ها نباید تکراری باشند.")
        answers = [types.PollAnswer(text=types.TextWithEntities(text=o, entities=[]), option=bytes([i])) for i, o in enumerate(options)]
        poll_obj = types.Poll(id=0, question=types.TextWithEntities(text=question, entities=[]), answers=answers, hash=0,
                              multiple_choice=multi or None, public_voters=public or None)
        try:
            await client.send_file(event.chat_id, types.InputMediaPoll(poll=poll_obj), reply_to=reply_to_id(event))
        except RPCError as exc:
            return await event.reply(f"❌ نظرسنجی ساخته نشد: {explain_error(exc)}")
        await event.delete()

    # ------------------------------------------------------------------ 8. .qr
    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}qr(?:\s+(.+))?$"))
    async def qr(event):
        text = (event.pattern_match.group(1) or "").strip()
        replied = await get_real_reply(event)
        if not text and replied is not None:
            text = (replied.raw_text or "").strip()
        if not text:
            return await event.reply(f"فرمت: `{PREFIX}qr متن یا لینک` (یا روی یک پیام Reply کن)")
        if len(text) > 1000:
            return await event.reply("❌ متن برای QR خیلی طولانی است (حداکثر ۱۰۰۰ حرف).")
        try:
            import qrcode
        except ImportError:
            return await event.reply("❌ کتابخانهٔ qrcode نصب نیست: `pip install \"qrcode[pil]\"`")
        fd, path = tempfile.mkstemp(suffix=".png", prefix="qr_")
        os.close(fd)
        try:
            img = qrcode.make(text, box_size=10, border=3)
            img.save(path)
            await client.send_file(event.chat_id, path, reply_to=reply_to_id(event))
            await event.delete()
        finally:
            try:
                os.remove(path)
            except OSError:
                pass

    # ------------------------------------------------------------------ 9. .pass
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}pass(?:\s+(\d+))?$"))
    async def password(event):
        n = max(8, min(int(event.pattern_match.group(1) or 16), 64))
        symbols = "!@#$%^&*-_=+?"
        alphabet = string.ascii_letters + string.digits + symbols
        while True:
            pwd = "".join(secrets.choice(alphabet) for _ in range(n))
            if (any(c.islower() for c in pwd) and any(c.isupper() for c in pwd)
                    and any(c.isdigit() for c in pwd) and any(c in symbols for c in pwd)):
                break
        await client.send_message("me", f"🔐 رمز {n} کاراکتری:\n`{pwd}`")
        await event.edit("🔐 رمز تصادفی در Saved Messages ارسال شد.")
        await db.insert(
            "INSERT INTO delete_jobs(chat_id,message_ids,run_at,kind,preview,created_at) VALUES(?,?,?,?,?,?)",
            (event.chat_id, f"[{event.id}]", time.time() + 5, "note", "pass", datetime.now(timezone.utc).isoformat()),
        )

    # ------------------------------------------------------------------ 10. .link
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}link(?:\s+(new))?$"))
    async def link(event):
        if not event.is_group:
            return await event.reply("❌ فقط در گروه.")
        make_new = bool(event.pattern_match.group(1))
        chat = await event.get_chat()
        username = getattr(chat, "username", None)
        if username and not make_new:
            return await event.reply(f"🔗 https://t.me/{username}")
        perm = await require_group_right(client, event.chat_id, "invite_users")
        if not perm.allowed:
            return await event.reply("❌ شما دسترسی ندارید: " + perm.reason)
        peer = await client.get_input_entity(event.chat_id)
        try:
            if not make_new and isinstance(peer, types.InputPeerChannel):
                full = await client(GetFullChannelRequest(peer))
                existing = getattr(full.full_chat, "exported_invite", None)
                if existing and getattr(existing, "link", None) and not getattr(existing, "revoked", False):
                    return await event.reply(f"🔗 {existing.link}")
            invite = await client(ExportChatInviteRequest(peer=peer))
            return await event.reply(f"🔗 {invite.link}")
        except RPCError as exc:
            return await event.reply(f"❌ لینک گرفته نشد: {explain_error(exc)}")
