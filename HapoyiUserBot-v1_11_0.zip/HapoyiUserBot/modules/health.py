"""`.health` and `.modules` - moved here from the old fixed-session bootstrap so they still work
now that the userbot client is created dynamically by core/switchboard.py for whichever account
is active."""
from __future__ import annotations

import os
import re

from telethon import events

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}health$"))
    async def health(event):
        registry = getattr(client, "_hapoyi_registry", None)
        await event.reply(
            "🟢 Hāpoyi UserBot\n"
            f"{registry.summary() if registry else 'modules=? loaded=? failed=?'}\n"
            "database=ok\n"
            "telethon=1.45.x"
        )

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}modules$"))
    async def modules_cmd(event):
        registry = getattr(client, "_hapoyi_registry", None)
        if registry is None:
            return await event.reply("ℹ️ اطلاعات ماژول‌ها در دسترس نیست.")
        lines = ["🧩 Modules"]
        for name, info in sorted(registry.modules.items()):
            status = "✅" if info.loaded else "❌"
            lines.append(f"{status} {name}")
        await event.reply("\n".join(lines)[:4000])
