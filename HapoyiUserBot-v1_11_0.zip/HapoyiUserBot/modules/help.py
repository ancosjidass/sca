from __future__ import annotations

import os
import re
from pathlib import Path

from telethon import events

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
BASE = Path(__file__).resolve().parents[1]
HELP_FILE = BASE / "docs" / "HELP.txt"

SECTIONS = {
    "admin": """🛡️ Admin\n{p}ban [user]\n{p}unban [user]\n{p}kick [user]\n{p}mute [user] [duration]\n{p}unmute [user]\n{p}warn [user] [reason]\n{p}warnings [user]\n{p}unwarn [user]\n{p}del (reply)\n{p}purge <count>\n{p}pin / {p}unpin\n{p}promote [user]  (Pin+Delete+Invite+Ban)\n{p}demote [user]\n{p}banned users\n{p}mute users\n{p}admins""",
    "security": """🔐 Security\n{p}autoban on|off [ban|mute|delete]\n{p}whitelist add|del|list [user]\n{p}autodelete enable|disable|list [user]\n{p}filter scope normal|all\n{p}filter add|del|list <text>\n{p}flood on|off <count> <seconds>\n{p}safety on|off|status\n{p}floodguard on|off|status""",
    "chat": """👥 Chat Guard\n{p}welcome on|off [template]\n{p}leave on|off\n{p}linkguard on|off [all|invite] [delete|warn|mute|ban] [duration]
{p}linkguard scope normal|all
{p}linkguard threshold <count> <window> <action> [duration]\n{p}rate <count> <window>\n{p}rate off""",
    "personal": """🧠 Personal\n{p}afk [reason]\n{p}back\n{p}note add|get|del|list\n{p}remind <duration> <text>\n{p}clock\n{p}profileclock on|off|status  (بیو + اسم)\n{p}profileclock name on|off  (Last name = ساعت)\n{p}profileclock bio on|off\n{p}profileclock digits fa|en\n{p}clone [user]  (Reply یا @user/ID)\n{p}unclone\n{p}bio <text>\n{p}stats\n{p}userinfo [user]\n{p}chatinfo\n{p}time <zone>""",
    "relations": """🤝 Friends / Enemies\n{p}friend add|del|on|off|list [user]\n{p}enemy add|del|on|off|list [user]\n{p}friend reply <text>\n{p}enemy reply <text>\n{p}relation reply friend|enemy <text>\n{p}relation replies [friend|enemy]\n{p}relation stats\n{p}relation cooldown friend|enemy <seconds>\n{p}relation clear [friend|enemy]  (کاملاً خالی)\n{p}relation reset [friend|enemy]  (برگشت پیش‌فرض)\nبرای target می‌توانی username/ID بدهی یا روی پیامش Reply کنی. پاسخ‌ها تصادفی‌اند و cooldown دارند.""",
    "crypto": """💰 Market\nدلار / یورو / بیت کوین / تتر / سولانا\n{p}price <symbol>  (دلار/یورو/کریپتو، لحظه‌ای)\n{p}pricesrc  (وضعیت منابع قیمت)\n{p}market\n{p}alert <usd|eur|btc...> >|< <price>\n{p}alerts\n{p}alertdel <id>\n{p}hold add|set|del <coin> <qty>\n{p}portfolio""",
    "tools": """🧰 Tools\n{p}calc <expression>\n{p}msginfo (reply)\n{p}id [user/chat]\n{p}save (reply)\n{p}search <text>\n{p}readall\n{p}react <emoji> (reply)\n{p}rawchat""",
    "media": """🎞️ Media\n{p}download (reply)\n{p}sticker  (Reply روی عکس)\n{p}gif  (Reply روی عکس/ویدیو) (reply photo)\n{p}rename <name> (reply file)\n{p}resize <width> <height> (reply photo)\n{p}watermark <text> (reply photo)""",
    "message": """🧹 Message Tools\n{p}delafter <duration> (reply)\n{p}selfdestruct <duration> <text>\n{p}selfdestruct list | del <id|all> | now <id|all>\n{p}mesdel all | <n>  (پیام‌های خودت در این گپ)\n{p}mesdel all | <n> <chat id یا @username>  (بدون رفتن به گپ)\n{p}reactdel <n|all> [chat id یا @username]  (ری‌اکشن‌های خودت را از n پیام آخر برمی‌دارد؛ بدون گپ = همین گپ)\n{p}cleanme [count]""",
    "games": """🎲 Games\n{p}casino <target>  (با Reply: روی همان پیام ریپلای می‌شود)\n{p}casino smart 777 [max_rolls]\n{p}casino hooshmad 777 [max_rolls]\n{p}dice|dart|bowling|basket|football <target>\n{p}game cancel\n{p}game status\n{p}coin\n{p}rps rock|paper|scissors""",
    "automation": """⏰ Automation\n{p}autoreply add|del|list|on|off\n{p}watch add|del|list\n{p}autoreact <emoji> (Reply = فقط همان کاربر، بدون Reply = کل گپ)\n{p}autoreact off|on|del [user|all] / list / clear\n{p}notify add|del|list <chat> <keyword>\n{p}jobs\n{p}jobdel <id>""",
    "power": """⚡ ابزارهای قدرتی\\n{p}every 5m <متن>  یا  {p}time <متن> 5m  (تکرار در همین گپ)\\n{p}every list [all] | pause|resume <id|all> | del <id|all|allchats>\\n{p}tag [N] | {p}tag admin [N] | {p}tag normal [N] | {p}tag stop  (حداکثر ۳۰۰)\\n{p}later 10m <متن>  (ارسال زمان‌بندی‌شده توسط تلگرام)  | later list | later del <id|all>\\n{p}top [N]  (فعال‌ترین‌ها)\\n{p}export [N]  (پیام‌های گپ → Saved Messages)\\n{p}slowmode off|10s|30s|1m|5m|15m|1h\\n{p}lock [all|media|stickers|gifs|links|polls|invite|pin|info] | {p}unlock ... | {p}lock status\\n{p}delall [@user] [N]  (پیام‌های یک نفر)\\n{p}poll [multi] [public] سؤال | گزینه | گزینه\\n{p}qr <متن>\\n{p}pass [طول]\\n{p}link [new]""",
    "account": """🔐 اکانت، لایسنس و محافظ\n{p}whoami — اکانت فعلی و اعتبار لایسنس\n{p}deactivate — (اکانت‌های لایسنس‌دار) خاموش‌کردن سلف روی همین اکانت؛ با دکمهٔ «فعال‌کردن» در بات کنترل برمی‌گردد\n{p}protect on | off | status — Account Protect: هر لاگین جدیدی که در زمان روشن‌بودن بسازد فوراً بسته می‌شود؛ سشن‌های قبلی و سشن‌های زمان خاموشی دست نمی‌خورند\n\nفقط اکانت اصلی (مالک):\n{p}lic new <12h|3d|1m> [نام] — ساخت لایسنس (کد در Saved Messages)\n{p}lic list | off <id> | on <id> | del <id>\n\nبات کنترل: /start — پنل مالک (ساخت/لیست/خاموش/حذف لایسنس) یا ورود با لایسنس""",
    "echo": """🔁 Echo و ابزارهای روزمره\\n{p}echo add|del [@user|id] (یا Reply)\\n{p}echo list [all] | clear [allchats] | on|off | status\\n{p}echo edit on|off  (ادیت به «اکو از ...»)\\n{p}echo wipe on|off  (پاک‌کردن پیام اکوکننده)\\nکاربر مجاز: «اکو سلام» (Reply = ریپلای روی همان پیام)\\n{p}msginfo (Reply روی پیام)  ← نشان می‌دهد اکو بوده یا نه\\n{p}todo add|list|done|undone|del|clear\\n{p}conv 100 usd [toman]  (دلار/یورو/تومان/کریپتو)\\n{p}ping\\n{p}copy [me|@chat]  (Reply)\\n{p}backup  (دیتابیس → Saved Messages)""",
    "channels": """📢 Channels\n{p}comment <channel> <text>\n{p}comment first <channel> <text>  (کامنت اول خودکار زیر هر پست جدید)\n{p}comment first off|on|del <channel> / list\n{p}comments <channel> <post_id>""",
}


def _build_help() -> str:
    out = ["HĀPOYI USERBOT — COMPLETE HELP", "", "Control Center: .menu", ""]
    for key, section in SECTIONS.items():
        out.append(f"===== {key.upper()} =====")
        out.append(section.format(p=PREFIX))
        out.append("")
    out.append("Notes:")
    out.append("- UserBot uses MTProto/Telethon; Assistant Bot provides the button UI.")
    out.append("- Casino smart mode is rate-limited and stops on flood/slow-mode conditions.")
    out.append("- Friend/Enemy replies use a per-user/per-chat cooldown to avoid message storms.")
    return "\n".join(out) + "\n"


def setup(client, db):
    HELP_FILE.parent.mkdir(exist_ok=True)
    HELP_FILE.write_text(_build_help(), encoding="utf-8")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}help(?:\s+(\w+))?$"))
    async def _help(event):
        section = event.pattern_match.group(1)
        if section and section.lower() in SECTIONS:
            await event.reply(SECTIONS[section.lower()].format(p=PREFIX))
            return
        await client.send_file(event.chat_id, HELP_FILE, caption="🧩 Hāpoyi UserBot — Help.txt")
        try:
            await event.delete()
        except Exception:
            pass
