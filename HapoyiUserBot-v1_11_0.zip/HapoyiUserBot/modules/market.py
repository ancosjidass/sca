from __future__ import annotations

import os
from datetime import datetime
from zoneinfo import ZoneInfo

from telethon import events

from providers.crypto import MarketProvider
from providers.iran import shared
from utils.formatting import fmt_money

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
DEFAULTS = ["BTC", "ETH", "SOL", "USDT", "TON"]
TRIGGERS = {
    "دلار": "USD", "usd": "USD", "یورو": "EUR", "eur": "EUR",
    "بیت کوین": "BTC", "بیتکوین": "BTC", "bitcoin": "BTC", "btc": "BTC",
    "اتریوم": "ETH", "ethereum": "ETH", "eth": "ETH",
    "سولانا": "SOL", "solana": "SOL", "sol": "SOL",
    "تتر": "USDT", "usdt": "USDT", "تون": "TON", "ton": "TON",
}


def _stamp(ts: float | None = None) -> str:
    zone = ZoneInfo(os.getenv("TIMEZONE", "Asia/Tehran"))
    return datetime.fromtimestamp(ts, zone).strftime("%Y-%m-%d %H:%M:%S") if ts else datetime.now(zone).strftime("%Y-%m-%d %H:%M:%S")


def setup(client, db):
    provider = MarketProvider()
    rates = shared()

    async def render(symbol: str) -> str:
        if symbol in {"USD", "EUR"}:
            rate = await (rates.usd_toman() if symbol == "USD" else rates.eur_toman())
            icon, name, flag = ("💵", "دلار / USD", "🇺🇸") if symbol == "USD" else ("💶", "یورو / EUR", "🇪🇺")
            text = f"{icon} {name}\n{flag} 1 {symbol}\n🇮🇷 {fmt_money(rate.toman, 0)} تومان\n🕐 {_stamp(rate.at)}\n📡 {rate.source} (بازار آزاد)"
            return text + (f"\n{rate.note}" if rate.note else "")
        q = await provider.quote(symbol)
        change = "—" if q.change_24h is None else f"{q.change_24h:+.2f}%"
        toman = f"{fmt_money(q.toman, 0)} تومان" if q.toman is not None else "در دسترس نیست"
        return (
            f"🪙 {q.symbol}\n\n"
            f"💵 USD: ${fmt_money(q.usd, 6 if q.usd < 1 else 2)}\n"
            f"🇮🇷 Toman: {toman}\n"
            f"📈 24H: {change}\n"
            f"🕐 {_stamp(q.at)}\n"
            f"📡 {q.source}"
        )

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}pricesrc$"))
    async def price_sources(event):
        """Diagnostics: which price source answers from THIS server, with latency."""
        rows = await rates.diagnostics()
        lines = ["🔧 منابع قیمت (از همین سرور)", ""]
        for r in rows:
            lines.append(f"{'✅' if r.ok else '❌'} {r.name} — {r.ms}ms\n   {r.detail}")
        lines.append("\nاگر همه ❌ بودند: دسترسی اینترنت/فیلتر سرور را چک کن یا IRAN_FX_URL بده.")
        await event.edit("\n".join(lines)[:4000])

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}(?:price|p)\s+(.+)$"))
    async def price_cmd(event):
        raw = event.pattern_match.group(1).strip()
        symbol = TRIGGERS.get(raw.lower(), raw.upper())
        try:
            await event.edit(await render(symbol))
        except Exception as exc:  # noqa: BLE001
            await event.edit(f"❌ دریافت قیمت ناموفق بود: {exc}"[:500])

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}market$"))
    async def market_cmd(event):
        lines = ["📊 Market Dashboard", ""]
        try:
            usd = await rates.usd_toman()
            lines.append(f"💵 USD: {fmt_money(usd.toman, 0)} تومان ({usd.source})")
            lines.append("")
        except Exception as exc:  # noqa: BLE001
            lines.append(f"💵 USD: ❌ {exc.__class__.__name__}\n")
        for symbol in DEFAULTS:
            try:
                q = await provider.quote(symbol)
                toman = fmt_money(q.toman, 0) if q.toman is not None else "—"
                ch = "—" if q.change_24h is None else f"{q.change_24h:+.2f}%"
                lines.append(f"{q.symbol}: ${fmt_money(q.usd, 2)} | {toman} تومان | {ch}")
            except Exception as exc:  # noqa: BLE001
                lines.append(f"{symbol}: ❌ {exc.__class__.__name__}")
        lines.append("\n🕐 " + _stamp())
        await event.edit("\n".join(lines))

    @client.on(events.NewMessage)
    async def natural_price(event):
        if not event.out or not event.raw_text or event.raw_text.startswith(PREFIX):
            return
        text = event.raw_text.strip().lower()
        if text not in TRIGGERS:
            return
        # Edit only the user's own trigger message as requested.
        try:
            await event.edit(await render(TRIGGERS[text]))
        except Exception:
            pass
