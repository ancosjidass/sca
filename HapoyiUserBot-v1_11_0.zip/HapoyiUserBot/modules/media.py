from __future__ import annotations

import os
from pathlib import Path
import tempfile

from telethon import events
from telethon.tl.types import DocumentAttributeAnimated, DocumentAttributeVideo
from PIL import Image, ImageEnhance, ImageOps

from utils.media_convert import ConvertError, image_to_gif_mp4, video_to_gif_mp4

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
MEDIA_DIR = Path(__file__).resolve().parents[1] / "data" / "media"
MEDIA_DIR.mkdir(parents=True, exist_ok=True)


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}download$"))
    async def download(event):
        if not event.is_reply:
            return await event.reply("❌ Reply روی مدیا.")
        m = await event.get_reply_message()
        if not m.media:
            return await event.reply("❌ این پیام مدیا ندارد.")
        path = await m.download_media(file=str(MEDIA_DIR))
        await event.reply(f"✅ دانلود شد:\n{Path(path).name}" if path else "❌ دانلود نشد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}rename\s+(.+)$"))
    async def rename(event):
        if not event.is_reply:
            return await event.reply("❌ Reply روی فایل.")
        m = await event.get_reply_message()
        path = await m.download_media(file=str(MEDIA_DIR))
        if not path:
            return await event.reply("❌ دانلود نشد.")
        new = MEDIA_DIR / event.pattern_match.group(1).strip()
        Path(path).replace(new)
        await client.send_file(event.chat_id, str(new))

    def _is_video(m) -> bool:
        doc = getattr(m, "document", None)
        mime = (getattr(doc, "mime_type", "") or "").lower()
        return bool(getattr(m, "video", None) or getattr(m, "video_note", None) or getattr(m, "gif", None) or mime.startswith("video/"))

    def _is_image(m) -> bool:
        doc = getattr(m, "document", None)
        mime = (getattr(doc, "mime_type", "") or "").lower()
        return bool(getattr(m, "photo", None) or mime in {"image/jpeg", "image/png", "image/webp", "image/bmp"})

    def _cleanup(*paths) -> None:
        for p in paths:
            try:
                if p:
                    os.remove(p)
            except OSError:
                pass

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}sticker$"))
    async def sticker(event):
        if not event.is_reply:
            return await event.reply("❌ روی یک عکس Reply کن.")
        m = await event.get_reply_message()
        if not _is_image(m):
            return await event.reply("❌ فقط روی عکس Reply کن (برای ویدیو از `.gif` استفاده کن).")
        path = await m.download_media(file=tempfile.mkdtemp(dir=MEDIA_DIR) + "/")
        if not path:
            return await event.reply("❌ دانلود نشد.")
        out = None
        try:
            with Image.open(path) as src:
                im = src.convert("RGBA")
            im.thumbnail((512, 512), Image.Resampling.LANCZOS)
            out = str(Path(path).with_suffix(".webp"))
            im.save(out, "WEBP", lossless=True, quality=90)
            await client.send_file(event.chat_id, out, force_document=False, reply_to=event.reply_to_msg_id)
            await event.delete()
        except Exception as exc:  # noqa: BLE001
            await event.reply(f"❌ تبدیل نشد: {exc}")
        finally:
            _cleanup(path, out)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}gif$"))
    async def gif(event):
        """Reply to a photo -> 3s looping zoom GIF; reply to a video / video-note / video-sticker -> real GIF."""
        if not event.is_reply:
            return await event.reply("❌ روی عکس یا ویدیو Reply کن.")
        m = await event.get_reply_message()
        doc = getattr(m, "document", None)
        if doc and (getattr(doc, "mime_type", "") or "") == "application/x-tgsticker":
            return await event.reply("❌ استیکرهای انیمیشنی (tgs) پشتیبانی نمی‌شوند؛ روی عکس/ویدیو/استیکر ویدیویی Reply کن.")
        is_video, is_image = _is_video(m), _is_image(m)
        if not (is_video or is_image):
            return await event.reply("❌ روی عکس یا ویدیو Reply کن.")
        workdir = tempfile.mkdtemp(dir=MEDIA_DIR)
        src = out = None
        try:
            src = await m.download_media(file=workdir + "/")
            if not src:
                return await event.reply("❌ دانلود نشد.")
            out = str(Path(workdir) / "result.mp4")
            info = await (video_to_gif_mp4(src, out) if is_video else image_to_gif_mp4(src, out))
            attrs = [DocumentAttributeAnimated()]
            if info.get("w") and info.get("h"):
                attrs.append(DocumentAttributeVideo(duration=int(info.get("duration") or 1), w=int(info["w"]), h=int(info["h"]), supports_streaming=True))
            await client.send_file(event.chat_id, out, attributes=attrs, mime_type="video/mp4", force_document=False, reply_to=event.reply_to_msg_id)
            await event.delete()
        except ConvertError as exc:
            await event.reply(f"❌ {exc}")
        except Exception as exc:  # noqa: BLE001
            await event.reply(f"❌ GIF ساخته نشد: {exc.__class__.__name__}")
        finally:
            _cleanup(src, out)
            try:
                os.rmdir(workdir)
            except OSError:
                pass

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}resize\s+(\d+)\s+(\d+)$"))
    async def resize(event):
        if not event.is_reply:
            return await event.reply("❌ Reply روی عکس.")
        m = await event.get_reply_message(); path = await m.download_media(file=str(MEDIA_DIR))
        if not path:
            return await event.reply("❌ دانلود نشد.")
        w, h = int(event.pattern_match.group(1)), int(event.pattern_match.group(2))
        if w * h > 20_000_000:
            return await event.reply("❌ اندازه خیلی بزرگ است.")
        im = Image.open(path).convert("RGB").resize((w,h), Image.Resampling.LANCZOS)
        out = str(Path(path).with_name(Path(path).stem + "_resize.jpg")); im.save(out, quality=90)
        await client.send_file(event.chat_id, out)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}watermark\s+(.+)$"))
    async def watermark(event):
        if not event.is_reply:
            return await event.reply("❌ Reply روی عکس.")
        m = await event.get_reply_message(); path = await m.download_media(file=str(MEDIA_DIR))
        if not path:
            return await event.reply("❌ دانلود نشد.")
        try:
            from PIL import ImageDraw, ImageFont
            im = Image.open(path).convert("RGBA")
            draw = ImageDraw.Draw(im)
            text = event.pattern_match.group(1)
            draw.text((20, im.height - 50), text, fill=(255,255,255,180), stroke_width=2, stroke_fill=(0,0,0,180))
            out = str(Path(path).with_name(Path(path).stem + "_wm.png")); im.save(out)
            await client.send_file(event.chat_id, out)
        except Exception as exc:
            await event.reply(f"❌ Watermark failed: {exc}")
