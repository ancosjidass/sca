from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from datetime import datetime, timezone

from telethon import events, utils
from telethon.errors import FloodWaitError, RPCError
from telethon.tl.types import PeerUser

from core.identity import my_id
from core.permissions import explain_error, get_real_reply, require_group_right
from utils.formatting import parse_duration
from utils.react import clear_reaction

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
REACTDEL_MAX = int(os.getenv("REACTDEL_MAX", "5000") or 5000)


def _left(seconds: float) -> str:
    seconds = max(0, int(seconds))
    d, r = divmod(seconds, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    return " ".join(x for x in (f"{d}d" if d else "", f"{h}h" if h else "", f"{m}m" if m else "", f"{s}s" if (s or not (d or h or m)) else "") if x)


async def delete_in_batches(client, chat_id: int, ids: list[int], *, pause: float = 0.35) -> int:
    """Delete messages 100 at a time, surviving FloodWait. Returns how many were handed to Telegram."""
    done = 0
    for i in range(0, len(ids), 100):
        chunk = ids[i:i + 100]
        while True:
            try:
                await client.delete_messages(chat_id, chunk)
                done += len(chunk)
                break
            except FloodWaitError as exc:
                await asyncio.sleep(min(exc.seconds + 1, 120))
            except RPCError as exc:
                log.warning("delete batch failed in %s: %s", chat_id, exc.__class__.__name__)
                break
        if i + 100 < len(ids):
            await asyncio.sleep(pause)
    return done


def setup(client, db):
    # ------------------------------------------------------------------ persistent scheduled deletions
    worker: dict[str, asyncio.Task | None] = {"task": None}

    async def add_job(chat_id: int, ids: list[int], seconds: float, kind: str, preview: str) -> int:
        return await db.insert(
            "INSERT INTO delete_jobs(chat_id,message_ids,run_at,kind,preview,created_at) VALUES(?,?,?,?,?,?)",
            (chat_id, json.dumps(ids), time.time() + seconds, kind, preview[:60], datetime.now(timezone.utc).isoformat()),
        )

    async def run_due() -> None:
        rows = await db.fetchall("SELECT id,chat_id,message_ids FROM delete_jobs WHERE run_at<=? ORDER BY run_at LIMIT 50", (time.time(),))
        for row in rows:
            # claim first so a crash can never delete twice / loop forever
            await db.execute("DELETE FROM delete_jobs WHERE id=?", (row["id"],))
            try:
                await client.delete_messages(row["chat_id"], json.loads(row["message_ids"]))
            except FloodWaitError as exc:
                await asyncio.sleep(min(exc.seconds + 1, 60))
                try:
                    await client.delete_messages(row["chat_id"], json.loads(row["message_ids"]))
                except RPCError:
                    pass
            except RPCError:
                pass

    async def loop() -> None:
        while True:
            try:
                if client.is_connected():
                    await run_due()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                log.warning("delete worker: %s: %s", exc.__class__.__name__, exc)
            await asyncio.sleep(1.0)

    def ensure_worker() -> None:
        t = worker["task"]
        if t is None or t.done():
            worker["task"] = asyncio.get_running_loop().create_task(loop())

    ensure_worker()

    # ------------------------------------------------------------------ .delafter
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}delafter\s+(\S+)$"))
    async def delafter(event):
        try:
            seconds = parse_duration(event.pattern_match.group(1))
        except ValueError as exc:
            return await event.reply("❌ " + str(exc))
        reply = await get_real_reply(event)
        if reply is None:
            return await event.reply("❌ روی پیام Reply کن.")
        if event.is_group and reply.sender_id != await my_id(client):
            p = await require_group_right(client, event.chat_id, "delete_messages")
            if not p.allowed:
                return await event.reply("❌ شما دسترسی ندارید: " + p.reason)
        ensure_worker()
        job = await add_job(event.chat_id, [reply.id, event.id], seconds, "delafter", (reply.raw_text or "[مدیا]"))
        await event.reply(f"🧹 حذف زمان‌بندی شد (#{job}): {event.pattern_match.group(1)}")

    # ------------------------------------------------------------------ .selfdestruct
    HELP = (
        "💣 SelfDestruct\n"
        f"`{PREFIX}selfdestruct <زمان> <متن>` — پیام می‌فرستد و بعد از زمان پاک می‌شود (مثال: 30s, 5m, 2h)\n"
        f"`{PREFIX}selfdestruct list` — عملیات فعال (همهٔ گپ‌ها)\n"
        f"`{PREFIX}selfdestruct del <id|all>` — لغو عملیات (پیام می‌ماند و دیگر پاک نمی‌شود)\n"
        f"`{PREFIX}selfdestruct now <id|all>` — همین الان پیام را پاک کن"
    )

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}selfdestruct(?:\s+(.+))?$"))
    async def selfdestruct(event):
        arg = (event.pattern_match.group(1) or "").strip()
        if not arg:
            return await event.reply(HELP)
        parts = arg.split(maxsplit=1)
        word = parts[0].lower()
        ensure_worker()

        if word == "list":
            rows = await db.fetchall("SELECT id,chat_id,run_at,kind,preview FROM delete_jobs ORDER BY run_at")
            if not rows:
                return await event.reply("💣 عملیات فعالی وجود ندارد.")
            now = time.time()
            lines = [f"💣 عملیات فعال ({len(rows)})"]
            for r in rows:
                here = " (این گپ)" if r["chat_id"] == event.chat_id else ""
                lines.append(f"#{r['id']} [{r['kind']}] chat={r['chat_id']}{here} — {_left(r['run_at'] - now)} مانده\n   «{r['preview'] or '—'}»")
            return await event.reply("\n".join(lines)[:3900])

        if word in {"del", "cancel", "now"}:
            if len(parts) < 2:
                return await event.reply(f"فرمت: `{PREFIX}selfdestruct {word} <id|all>`")
            which = parts[1].strip().lower()
            if which == "all":
                rows = await db.fetchall("SELECT id,chat_id,message_ids FROM delete_jobs")
            elif which.lstrip("#").isdigit():
                rows = await db.fetchall("SELECT id,chat_id,message_ids FROM delete_jobs WHERE id=?", (int(which.lstrip("#")),))
            else:
                return await event.reply("❌ شمارهٔ عملیات یا all بده.")
            if not rows:
                return await event.reply("ℹ️ عملیاتی با این شماره پیدا نشد.")
            for r in rows:
                await db.execute("DELETE FROM delete_jobs WHERE id=?", (r["id"],))
                if word == "now":
                    try:
                        await client.delete_messages(r["chat_id"], json.loads(r["message_ids"]))
                    except RPCError:
                        pass
            return await event.reply(f"✅ {len(rows)} عملیات " + ("اجرا و پاک شد." if word == "now" else "لغو شد (پیام‌ها می‌مانند)."))

        try:
            seconds = parse_duration(parts[0])
        except ValueError as exc:
            return await event.reply("❌ " + str(exc) + "\n\n" + HELP)
        if len(parts) < 2 or not parts[1].strip():
            return await event.reply("❌ متن را هم بنویس.\n\n" + HELP)
        text = parts[1].strip()
        # the command message itself is deleted right away; the text goes out as a fresh message
        msg = await client.send_message(event.chat_id, text, reply_to=event.reply_to_msg_id if event.is_reply else None)
        await add_job(event.chat_id, [msg.id], seconds, "selfdestruct", text)
        await event.delete()

    # ------------------------------------------------------------------ .cleanme / .mesdel
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}cleanme(?:\s+(\d+))?$"))
    async def cleanme(event):
        n = max(1, min(int(event.pattern_match.group(1) or 20), 200))
        ids = [m.id async for m in client.iter_messages(event.chat_id, from_user="me", limit=n + 1)]
        if event.id not in ids:
            ids.append(event.id)
        await delete_in_batches(client, event.chat_id, ids)

    async def _resolve_chat(raw: str):
        raw = raw.strip()
        try:
            if re.fullmatch(r"-?\d+", raw):
                n = int(raw)
                return await client.get_entity(PeerUser(n) if n > 0 else n)
            return await client.get_entity(raw)
        except Exception:  # noqa: BLE001
            return None

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}mesdel(?:\s+(all|\d+))?(?:\s+(\S+))?$"))
    async def mesdel(event):
        """Delete MY OWN messages: `.mesdel all|N` here, or `.mesdel all|N <chat id / @username>` from anywhere."""
        arg = event.pattern_match.group(1)
        target_raw = event.pattern_match.group(2)
        if not arg:
            return await event.reply(f"فرمت: `{PREFIX}mesdel all` (همهٔ پیام‌های من در این گپ) یا `{PREFIX}mesdel 10` (۱۰ پیام اخیر من)\n"
                                     f"بدون رفتن به گپ: `{PREFIX}mesdel all <ایدی عددی یا @username>`")
        chat = event.chat_id
        remote = False
        if target_raw:
            entity = await _resolve_chat(target_raw)
            if entity is None:
                return await event.reply("❌ این گپ پیدا نشد (ایدی عددی، @username؛ و عضو آن باشی).")
            chat = entity
            remote = utils.get_peer_id(entity) != event.chat_id
        limit = None if arg == "all" else max(1, int(arg))
        ids: list[int] = []
        try:
            async for m in client.iter_messages(chat, from_user="me", limit=None if limit is None else limit + 1):
                if not remote and m.id == event.id:
                    continue
                ids.append(m.id)
                if limit is not None and len(ids) >= limit:
                    break
        except RPCError as exc:
            return await event.reply(f"❌ پیام‌ها خوانده نشد: {explain_error(exc)}")
        if not remote:
            ids.append(event.id)
        done = await delete_in_batches(client, chat, ids)
        deleted = done if remote else max(done - 1, 0)
        if remote:
            try:
                await event.delete()
            except RPCError:
                pass
        try:
            note = await client.send_message(event.chat_id, f"🗑 {deleted} پیام از خودت حذف شد.")
            await add_job(event.chat_id, [note.id], 5, "note", "mesdel")
        except RPCError:
            pass

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}reactdel(?:\s+(all|\d+))?(?:\s+(\S+))?$"))
    async def reactdel(event):
        """Remove MY reactions from the last N messages: `.reactdel 200` here or `.reactdel 200 <chat id / @username>`."""
        arg = event.pattern_match.group(1)
        target_raw = event.pattern_match.group(2)
        if not arg:
            return await event.reply(f"فرمت: `{PREFIX}reactdel 100` (ری‌اکشن‌های من روی ۱۰۰ پیام آخر این گپ) — "
                                     f"`{PREFIX}reactdel all [گپ]` — گپ دیگر: ایدی عددی یا @username")
        chat = event.chat_id
        if target_raw:
            entity = await _resolve_chat(target_raw)
            if entity is None:
                return await event.reply("❌ این گپ پیدا نشد (ایدی عددی، @username؛ و عضو آن باشی).")
            chat = entity
        limit = REACTDEL_MAX if arg == "all" else min(max(1, int(arg)), REACTDEL_MAX)
        removed = scanned = 0
        try:
            async for m in client.iter_messages(chat, limit=limit):
                scanned += 1
                results = getattr(getattr(m, "reactions", None), "results", None) or []
                if not any(getattr(r, "chosen_order", None) is not None for r in results):
                    continue
                while True:
                    try:
                        await clear_reaction(client, chat, m.id)
                        removed += 1
                        break
                    except FloodWaitError as exc:
                        await asyncio.sleep(min(exc.seconds + 1, 120))
                    except RPCError as exc:
                        log.warning("reactdel: message %s: %s", m.id, exc.__class__.__name__)
                        break
                await asyncio.sleep(0.3)
        except RPCError as exc:
            return await event.reply(f"❌ پیام‌ها خوانده نشد: {explain_error(exc)}")
        try:
            note = await client.send_message(event.chat_id, f"🧽 ری‌اکشن تو از {removed} پیام برداشته شد (از {scanned} پیام بررسی‌شده).")
            await add_job(event.chat_id, [note.id], 8, "note", "reactdel")
        except RPCError:
            pass
