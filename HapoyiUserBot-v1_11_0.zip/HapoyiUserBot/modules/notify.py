from __future__ import annotations

import os
import re
from core.identity import my_id
from telethon import events

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}notify\s+(add|del|list)(?:\s+(.+))?$"))
    async def notify_cmd(event):
        action, needle = event.pattern_match.groups()
        owner = (await my_id(client))
        if action == "list":
            rows = await db.fetchall("SELECT id,chat_id,needle FROM notifications WHERE owner_id=? AND enabled=1 ORDER BY id DESC", (owner,))
            return await event.reply("🔔 Notifications:\n" + "\n".join(f"#{r['id']} chat={r['chat_id']} → {r['needle']}" for r in rows) if rows else "🔔 خالی است.")
        if not needle:
            return await event.reply("مثال: .notify add @group سلام")
        parts = needle.split(maxsplit=1)
        if len(parts) == 1:
            return await event.reply("فرمت: .notify add <chat|id> <keyword>")
        chat_ref, word = parts
        try:
            chat_id = int(chat_ref) if chat_ref.lstrip("-").isdigit() else int((await client.get_entity(chat_ref)).id)
        except Exception:
            return await event.reply("❌ چت پیدا نشد.")
        if action == "add":
            await db.execute("INSERT OR IGNORE INTO notifications(owner_id,chat_id,needle,enabled) VALUES(?,?,?,1)", (owner, chat_id, word.lower()))
            return await event.reply("✅ Notification اضافه شد.")
        await db.execute("DELETE FROM notifications WHERE owner_id=? AND chat_id=? AND needle=?", (owner, chat_id, word.lower()))
        await event.reply("✅ Notification حذف شد.")

    @client.on(events.NewMessage)
    async def notify_handler(event):
        if event.out or not event.raw_text or event.raw_text.startswith(PREFIX):
            return
        rows = await db.fetchall("SELECT owner_id,needle FROM notifications WHERE chat_id=? AND enabled=1", (event.chat_id,))
        for row in rows:
            if row["needle"] in event.raw_text.lower():
                try:
                    await client.send_message(row["owner_id"], f"🔔 Keyword Alert\nChat: {event.chat_id}\n👤 {event.sender_id}\n\n{event.raw_text[:3000]}")
                except Exception:
                    pass
