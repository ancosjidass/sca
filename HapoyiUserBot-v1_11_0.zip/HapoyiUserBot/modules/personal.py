from __future__ import annotations

import ast
import asyncio
import operator
import os
import re
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from core.identity import my_id, my_name
from telethon import events
from telethon.tl.functions.account import UpdateProfileRequest

from core.permissions import resolve_target
from utils.formatting import fmt_money, parse_duration

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod, ast.USub: operator.neg}


def safe_calc(expr: str) -> float:
    if len(expr) > 80:
        raise ValueError("عبارت طولانی است")
    node = ast.parse(expr, mode="eval")
    def walk(n):
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return n.value
        if isinstance(n, ast.UnaryOp) and type(n.op) in OPS:
            return OPS[type(n.op)](walk(n.operand))
        if isinstance(n, ast.BinOp) and type(n.op) in OPS:
            a, b = walk(n.left), walk(n.right)
            if isinstance(n.op, ast.Pow) and abs(b) > 20:
                raise ValueError("توان خیلی بزرگ است")
            return OPS[type(n.op)](a, b)
        raise ValueError("فقط محاسبات عددی مجاز است")
    return float(walk(node.body))


def setup(client, db):
    clock_task: asyncio.Task | None = None
    clock_enabled = False

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}calc\s+(.+)$"))
    async def calc(event):
        try:
            value = safe_calc(event.pattern_match.group(1))
            await event.edit(f"🧮 {value:g}")
        except Exception as exc:
            await event.edit(f"❌ {exc}")

    tz = ZoneInfo(os.getenv("TIMEZONE", "Asia/Tehran"))

    def _since(started_iso: str) -> str:
        try:
            started = datetime.fromisoformat(started_iso)
        except ValueError:
            return started_iso
        secs = max(0, int((datetime.now(timezone.utc) - started).total_seconds()))
        if secs < 60:
            ago = "چند ثانیه"
        elif secs < 3600:
            ago = f"{secs // 60} دقیقه"
        elif secs < 86400:
            ago = f"{secs // 3600} ساعت و {(secs % 3600) // 60} دقیقه"
        else:
            ago = f"{secs // 86400} روز و {(secs % 86400) // 3600} ساعت"
        return f"{ago} پیش ({started.astimezone(tz).strftime('%H:%M')})"

    async def _afk_row(owner: int):
        return await db.fetchone("SELECT reason,started_at,enabled FROM afk WHERE owner_id=? AND enabled=1", (owner,))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}back$"))
    async def back(event):
        owner = await my_id(client)
        row = await _afk_row(owner)
        await db.execute("UPDATE afk SET enabled=0 WHERE owner_id=?", (owner,))
        await db.execute("DELETE FROM afk_notified WHERE owner_id=?", (owner,))
        if row:
            await event.reply(f"✅ AFK خاموش شد. (آفلاین بودی: {_since(row['started_at'])})")
        else:
            await event.reply("ℹ️ AFK فعال نبود.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}afk(?:\s+(.*))?$"))
    async def afk(event):
        owner = await my_id(client)
        reason = (event.pattern_match.group(1) or "").strip() or "بدون دلیل"
        await db.execute("INSERT INTO afk(owner_id,reason,started_at,enabled) VALUES(?,?,?,1) ON CONFLICT(owner_id) DO UPDATE SET reason=excluded.reason,started_at=excluded.started_at,enabled=1", (owner, reason, datetime.now(timezone.utc).isoformat()))
        # A new AFK session: everybody may be told once again.
        await db.execute("DELETE FROM afk_notified WHERE owner_id=?", (owner,))
        await event.reply(f"😴 AFK فعال شد: {reason}\nفقط در پیوی و برای هر نفر یک بار اطلاع می‌دهم.")

    @client.on(events.NewMessage(incoming=True))
    async def afk_replier(event):
        """Tell people who write to me in PRIVATE that I'm away - once per person per AFK session."""
        if not event.is_private or event.out or not event.sender_id:
            return
        if event.sender_id == 777000:  # Telegram service notifications
            return
        owner = await my_id(client)
        if event.sender_id == owner:
            return
        row = await _afk_row(owner)
        if not row:
            return
        sender = await event.get_sender()
        if sender is None or getattr(sender, "bot", False) or getattr(sender, "deleted", False):
            return
        # INSERT OR IGNORE is atomic: rowid is 0 when this person was already told in this session.
        first = await db.insert("INSERT OR IGNORE INTO afk_notified(owner_id,user_id,notified_at) VALUES(?,?,?)", (owner, int(event.sender_id), datetime.now(timezone.utc).isoformat()))
        if not first:
            return
        name = await my_name(client)
        try:
            await event.reply(f"😴 {name} الان آفلاین/AFK است.\nدلیل: {row['reason']}\nاز: {_since(row['started_at'])}\nبعداً جواب می‌دهد.")
        except Exception:  # noqa: BLE001
            # not delivered -> allow a later message to try again
            await db.execute("DELETE FROM afk_notified WHERE owner_id=? AND user_id=?", (owner, int(event.sender_id)))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}stats$"))
    async def stats(event):
        jobs = await db.fetchone("SELECT COUNT(*) AS n FROM jobs WHERE owner_id=? AND enabled=1", ((await my_id(client)),))
        notes = await db.fetchone("SELECT COUNT(*) AS n FROM notes WHERE owner_id=?", ((await my_id(client)),))
        alerts = await db.fetchone("SELECT COUNT(*) AS n FROM price_alerts WHERE owner_id=? AND enabled=1", ((await my_id(client)),))
        await event.reply(f"📊 Stats\n⏰ Jobs: {jobs['n']}\n📝 Notes: {notes['n']}\n🔔 Alerts: {alerts['n']}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}userinfo(?:\s+(\S+))?$"))
    async def userinfo(event):
        target = await resolve_target(event, event.pattern_match.group(1))
        if target is None:
            target = await event.get_sender()
        name = " ".join(x for x in [target.first_name, target.last_name] if x).strip()
        await event.reply(f"👤 {name}\nID: {target.id}\nUsername: @{target.username if target.username else '—'}\nBot: {getattr(target,'bot',False)}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}chatinfo$"))
    async def chatinfo(event):
        chat = await event.get_chat()
        await event.reply(f"💬 {getattr(chat,'title',None) or getattr(chat,'first_name','Private')}\nID: {event.chat_id}\nType: {chat.__class__.__name__}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}note\s+(add|get|del|list)(?:\s+(\S+)(?:\s+(.+))?)?$"))
    async def note(event):
        action, name, value = event.pattern_match.group(1), event.pattern_match.group(2), event.pattern_match.group(3)
        owner = (await my_id(client))
        if action == "list":
            rows = await db.fetchall("SELECT name FROM notes WHERE owner_id=? ORDER BY name", (owner,))
            return await event.reply("📝 Notes:\n" + "\n".join(f"• {r['name']}" for r in rows) if rows else "📝 خالی است.")
        if not name:
            return await event.reply("مثال: .note add vpn 123.45.67.89")
        if action == "add":
            if not value:
                return await event.reply("مقدار را بده.")
            await db.execute("INSERT INTO notes(owner_id,name,value,created_at,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(owner_id,name) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at", (owner,name,value,datetime.now(timezone.utc).isoformat(),datetime.now(timezone.utc).isoformat()))
            return await event.reply("✅ ذخیره شد.")
        if action == "get":
            row = await db.fetchone("SELECT value FROM notes WHERE owner_id=? AND name=?", (owner,name))
            return await event.reply(row["value"] if row else "❌ پیدا نشد.")
        await db.execute("DELETE FROM notes WHERE owner_id=? AND name=?", (owner,name))
        await event.reply("✅ حذف شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}time(?:\s+(.+))?$"))
    async def time_cmd(event):
        from utils.repeatspec import parse_repeat

        if parse_repeat(event.pattern_match.group(1)) is not None:
            return  # `.time متن 5m` is a repeat job (modules/repeat.py), not a timezone lookup
        zone = event.pattern_match.group(1) or os.getenv("TIMEZONE", "Asia/Tehran")
        try:
            now = datetime.now(ZoneInfo(zone))
            await event.reply(f"🕐 {zone}\n{now.strftime('%Y-%m-%d %H:%M:%S %Z')}")
        except Exception:
            await event.reply("❌ timezone نامعتبر است.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}remind\s+(\S+)\s+(.+)$"))
    async def remind(event):
        try:
            delay = parse_duration(event.pattern_match.group(1))
        except ValueError as exc:
            return await event.reply("❌ " + str(exc))
        await db.execute("INSERT INTO jobs(owner_id,chat_id,kind,payload_json,run_at,created_at) VALUES(?,?,?,?,?,?)", ((await my_id(client)), event.chat_id, "remind", __import__('json').dumps({"text":event.pattern_match.group(2)}, ensure_ascii=False), (datetime.now(timezone.utc).timestamp()+delay), datetime.now(timezone.utc).isoformat()))
        await event.reply(f"⏰ یادآوری برای {event.pattern_match.group(1)} ثبت شد.")
