from __future__ import annotations

import asyncio
import logging
import os
import re
from datetime import datetime
from zoneinfo import ZoneInfo

from telethon import events
from telethon.errors import AboutTooLongError, FloodWaitError, RPCError
from telethon.tl.functions.account import UpdateProfileRequest
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.types import InputUserSelf

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)

_FA = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
# a leftover clock at the end of a last name, e.g. "Amiri ۸:۳۶" or "Amiri 08:36"
_TAIL_CLOCK = re.compile(r"\s*[0-9۰-۹]{1,2}:[0-9۰-۹]{2}\s*$")
_BIO_CLOCK = re.compile(r"^🕐 [0-9۰-۹]{1,2}:[0-9۰-۹]{2} • Hāpoyi$")
MAX_LAST_NAME = 64


def format_clock(now: datetime, digits: str = "fa") -> str:
    """8:36 / ۸:۳۶ - hour without leading zero, 24h clock."""
    text = f"{now.hour}:{now.minute:02d}"
    return text.translate(_FA) if digits == "fa" else text


def build_last_name(base: str, clock: str) -> str:
    base = (base or "").strip()
    if not base:
        return clock
    room = MAX_LAST_NAME - len(clock) - 1
    return f"{base[:max(room, 0)].rstrip()} {clock}".strip()


def setup(client, db):
    tz = ZoneInfo(os.getenv("TIMEZONE", "Asia/Tehran"))
    applied: dict[str, str] = {}  # what we last wrote, to avoid useless API calls
    task_holder: dict[str, asyncio.Task | None] = {"task": None}

    async def _state() -> dict:
        return {
            "bio": bool(await db.get_kv("profile_clock", False)),
            "name": bool(await db.get_kv("profile_clock_name", False)),
            "digits": await db.get_kv("profile_clock_digits", "fa") or "fa",
            "orig": await db.get_kv("profile_clock_orig", {}) or {},
        }

    async def _my_about() -> str:
        full = await client(GetFullUserRequest(InputUserSelf()))
        return (getattr(full.full_user, "about", None) or "")

    async def _apply(*, about: str | None = None, last_name: str | None = None) -> None:
        kwargs = {}
        if about is not None:
            kwargs["about"] = about
        if last_name is not None:
            kwargs["last_name"] = last_name
        if not kwargs:
            return
        try:
            await client(UpdateProfileRequest(**kwargs))
        except AboutTooLongError:
            if "about" in kwargs:
                kwargs["about"] = kwargs["about"][:70]
                await client(UpdateProfileRequest(**kwargs))
            else:
                raise
        except RPCError as exc:
            if exc.__class__.__name__ == "FirstNameNotModifiedError":
                return
            raise

    async def tick() -> None:
        st = await _state()
        if not (st["bio"] or st["name"]):
            return
        now = datetime.now(tz)
        clock = format_clock(now, st["digits"])
        about = last = None
        if st["bio"]:
            text = f"🕐 {now.strftime('%H:%M')} • Hāpoyi"
            if applied.get("about") != text:
                about = text
        if st["name"]:
            text = build_last_name((st["orig"] or {}).get("last_name", ""), clock)
            if applied.get("last_name") != text:
                last = text
        if about is None and last is None:
            return
        await _apply(about=about, last_name=last)
        if about is not None:
            applied["about"] = about
        if last is not None:
            applied["last_name"] = last

    async def clock_loop() -> None:
        while True:
            try:
                await tick()
            except asyncio.CancelledError:
                raise
            except FloodWaitError as exc:
                log.warning("profile clock flood wait %ss", exc.seconds)
                await asyncio.sleep(exc.seconds + 1)
                continue
            except Exception as exc:  # noqa: BLE001
                log.warning("profile clock tick failed: %s: %s", exc.__class__.__name__, exc)
            now = datetime.now(tz)
            # wake up right after the minute changes so 8:36 -> 8:37 flips on time
            await asyncio.sleep(max(1.0, 60.5 - now.second - now.microsecond / 1e6))

    def ensure_task() -> None:
        t = task_holder["task"]
        if t is None or t.done():
            task_holder["task"] = asyncio.get_running_loop().create_task(clock_loop())

    ensure_task()

    async def _enable(mode: str) -> str:
        st = await _state()
        orig = dict(st["orig"])
        me = await client.get_me()
        if mode == "name":
            if "last_name" not in orig:
                orig["last_name"] = _TAIL_CLOCK.sub("", me.last_name or "")
            await db.set_kv("profile_clock_orig", orig)
            await db.set_kv("profile_clock_name", True)
            applied.pop("last_name", None)
        else:
            if "about" not in orig:
                about = await _my_about()
                orig["about"] = "" if _BIO_CLOCK.match(about) else about
            await db.set_kv("profile_clock_orig", orig)
            await db.set_kv("profile_clock", True)
            applied.pop("about", None)
        ensure_task()
        await tick()
        return "ok"

    async def _disable(mode: str) -> None:
        st = await _state()
        orig = dict(st["orig"])
        if mode == "name":
            await db.set_kv("profile_clock_name", False)
            if "last_name" in orig:
                await _apply(last_name=orig.pop("last_name"))
            applied.pop("last_name", None)
        else:
            await db.set_kv("profile_clock", False)
            if "about" in orig:
                await _apply(about=orig.pop("about")[:140])
            applied.pop("about", None)
        await db.set_kv("profile_clock_orig", orig)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}profileclock(?:\s+(.*))?$"))
    async def profile_clock(event):
        args = (event.pattern_match.group(1) or "").split()
        help_text = (
            "🕐 Profile Clock\n"
            f"`{PREFIX}profileclock on|off` — ساعت هم در بیو، هم در اسم (Last name)\n"
            f"`{PREFIX}profileclock name on|off` — فقط Last name (مثلاً ۸:۳۶، هر دقیقه عوض می‌شود)\n"
            f"`{PREFIX}profileclock bio on|off` — فقط بیو\n"
            f"`{PREFIX}profileclock digits fa|en` — ارقام فارسی یا انگلیسی\n"
            f"`{PREFIX}profileclock status`"
        )
        if not args or args[0] == "status":
            st = await _state()
            orig = st["orig"]
            return await event.reply(
                f"🕐 بیو: {'ON' if st['bio'] else 'OFF'} | اسم: {'ON' if st['name'] else 'OFF'} | ارقام: {st['digits']}\n"
                + (f"Last name اصلی: «{orig.get('last_name', '')}»\n" if "last_name" in orig else "")
                + f"الان: {format_clock(datetime.now(tz), st['digits'])}\n\n{help_text}"
            )
        if args[0] == "digits":
            if len(args) < 2 or args[1] not in {"fa", "en"}:
                return await event.reply("❌ `.profileclock digits fa` یا `en`")
            await db.set_kv("profile_clock_digits", args[1])
            applied.pop("last_name", None)
            await tick()
            return await event.reply(f"✅ ارقام ساعت: {'فارسی ۸:۳۶' if args[1] == 'fa' else 'انگلیسی 8:36'}")
        mode, action = "all", None
        if args[0] in {"on", "off"}:
            action = args[0]
        elif args[0] in {"name", "bio"} and len(args) > 1 and args[1] in {"on", "off"}:
            mode, action = args[0], args[1]
        else:
            return await event.reply(help_text)
        modes = ["bio", "name"] if mode == "all" else [mode]
        for m in modes:
            if action == "on":
                await _enable(m)
            else:
                await _disable(m)
        label = {"all": "بیو + اسم", "bio": "بیو", "name": "اسم (Last name)"}[mode]
        await event.reply(f"🕐 Profile Clock ({label}) " + ("روشن شد." if action == "on" else "خاموش شد؛ مقدار قبلی برگردانده شد."))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}bio\s+(.+)$"))
    async def bio(event):
        text = event.pattern_match.group(1)[:140]
        await client(UpdateProfileRequest(about=text))
        st = await _state()
        if st["bio"]:
            await event.reply("✅ Bio تغییر کرد (ولی Profile Clock بیو روشن است و دقیقهٔ بعد آن را عوض می‌کند).")
        else:
            await event.reply("✅ Bio تغییر کرد.")
