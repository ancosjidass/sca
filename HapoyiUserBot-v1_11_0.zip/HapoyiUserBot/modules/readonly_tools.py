from __future__ import annotations
import os
from telethon import events
PREFIX=os.getenv("COMMAND_PREFIX",".") or "."

def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}rawchat$"))
    async def rawchat(event):
        chat=await event.get_chat()
        attrs=[]
        for key in ("id","title","username","broadcast","megagroup","forum","verified","scam","fake"):
            if hasattr(chat,key): attrs.append(f"{key}={getattr(chat,key)}")
        await event.reply("🧬 Chat\n"+"\n".join(attrs))
