from __future__ import annotations

import os
import random
import re
import time
from datetime import datetime, timezone

from core.identity import my_id
from telethon import events

from core.permissions import resolve_target
from utils.targets import target_label

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."

DEFAULT_ENEMY_REPLIES = [
    "تروخدا از ما بکش بیرون 😭",
    "داداش یکم فاصله لطفاً 😂",
    "باز تو؟ 😐",
    "من با شما کاری ندارم 😭",
    "لطفاً مزاحم نشو 😂",
    "اعصاب ندارم، بعداً بیا 😶",
    "پیامت رسید، جواب قلبی ندارم 😭",
    "برو یه دور دیگه بیا 😐",
    "درخواستت رد شد 😂",
    "من الان در حالت بی‌توجهی‌ام.",
    "لطفاً از این چت عبور کنید 😭",
    "هنوزم دشمنی؟ 😂",
    "فاصله اجتماعی لطفاً.",
    "بهتره سایلنت کنیم همدیگه رو 😐",
    "پیام دریافت شد، علاقه دریافت نشد 😂",
    "تروخدا دوباره شروع نکن 😭",
    "من وانمود می‌کنم این پیام رو ندیدم.",
    "دشمنی با موفقیت ثبت شد ✅",
    "جواب این یکی رو سیستم انتخاب کرد 😂",
    "بعدی! 😐",
]

DEFAULT_FRIEND_REPLIES = [
    "❤️ داداشی",
    "قربونت برم 😄",
    "دمت گرم 🫶",
    "عشقی ❤️",
    "مرسی رفیق 😎",
    "پایتم داداش.",
    "فدات 😄",
    "دمت گرم که هستی ❤️",
    "رفیق خودمی.",
    "❤️❤️",
    "دمت گرم که یادم بودی 😄",
    "بگو ببینم چی شده رفیق.",
    "با تو همیشه پایه‌ام.",
    "مرام داری ❤️",
    "آفرین رفیق 😎",
    "قربون مرامت.",
    "رفاقت برقرار ❤️",
    "تو دیگه خودی‌ای.",
    "دمت گرم که اومدی.",
    "❤️ رفیق قدیمی منی.",
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def setup(client, db):
    cooldowns: dict[tuple[int, int, str], float] = {}
    seeded: set[int] = set()

    async def _seed(owner_id: int, kind: str, values: list[str]) -> None:
        for value in values:
            await db.execute(
                "INSERT INTO relation_replies(owner_id,kind,reply_text,created_at) VALUES(?,?,?,?)",
                (owner_id, kind, value, _now()),
            )

    async def ensure_defaults(owner_id: int) -> None:
        """Seed the default reply pools exactly once per account.

        A later `.relation clear` really empties the pool and it STAYS empty (the old code
        re-seeded the defaults whenever a pool was empty).
        """
        if owner_id in seeded:
            return
        if await db.get_kv(f"relations_seeded:{owner_id}", False):
            seeded.add(owner_id)
            return
        for kind, values in (("enemy", DEFAULT_ENEMY_REPLIES), ("friend", DEFAULT_FRIEND_REPLIES)):
            row = await db.fetchone("SELECT COUNT(*) AS n FROM relation_replies WHERE owner_id=? AND kind=?", (owner_id, kind))
            if not row or row["n"] == 0:
                await _seed(owner_id, kind, values)
        await db.set_kv(f"relations_seeded:{owner_id}", True)
        seeded.add(owner_id)

    async def _target(event, raw: str | None):
        try:
            return await resolve_target(event, raw)
        except Exception:
            return None

    def _user_id(target) -> int:
        return int(getattr(target, "id", target))

    async def _set_relation(event, kind: str, target, enabled: bool = True):
        owner = (await my_id(client))
        uid = _user_id(target)
        if uid == owner:
            return await event.reply("❌ نمی‌شود خودت را دوست/دشمن تنظیم کرد.")
        if enabled:
            await db.execute("DELETE FROM relations WHERE owner_id=? AND user_id=?", (owner, uid))
            await db.execute(
                "INSERT INTO relations(owner_id,user_id,kind,enabled,cooldown_seconds,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                (owner, uid, kind, 1, 8.0, _now(), _now()),
            )
            label = target_label(target)
            return await event.reply(f"✅ {label} به لیست {kind} اضافه شد.")
        await db.execute("DELETE FROM relations WHERE owner_id=? AND user_id=? AND kind=?", (owner, uid, kind))
        return await event.reply("✅ حذف شد.")

    async def _relation_command(event, kind: str):
        action, raw = event.pattern_match.group(1), event.pattern_match.group(2)
        owner = await my_id(client)
        await ensure_defaults(owner)
        icon = "❤️" if kind == "friend" else "😈"
        if action == "list":
            rows = await db.fetchall("SELECT user_id,enabled,cooldown_seconds FROM relations WHERE owner_id=? AND kind=? ORDER BY user_id", (owner, kind))
            if not rows:
                return await event.reply(f"{icon} لیست {'دوست‌ها' if kind == 'friend' else 'دشمن‌ها'} خالی است.")
            return await event.reply(f"{icon} {kind.title()} List\n" + "\n".join(f"• {r['user_id']} | {'ON' if r['enabled'] else 'OFF'} | cooldown={r['cooldown_seconds']}s" for r in rows))

        # Target: explicit @username/ID, otherwise the author of the replied-to message.
        target = await _target(event, raw)
        if target is None:
            if action in {"on", "off"} and not raw and not event.is_reply:
                flag = 1 if action == "on" else 0
                await db.execute("UPDATE relations SET enabled=?,updated_at=? WHERE owner_id=? AND kind=?", (flag, _now(), owner, kind))
                return await event.reply(f"{'✅ پاسخ‌گویی همهٔ' if flag else '⏸ پاسخ‌گویی همهٔ'} {kind} {'روشن' if flag else 'خاموش'} شد.")
            return await event.reply(f"❌ کاربر پیدا نشد. روی پیامش Reply کن یا `{PREFIX}{kind} {action} @username` بزن.")
        uid = _user_id(target)
        label = target_label(target)
        if action in {"del", "remove"}:
            n = await db.execute("DELETE FROM relations WHERE owner_id=? AND user_id=? AND kind=?", (owner, uid, kind))
            return await event.reply(f"✅ {label} از لیست {kind} حذف شد." if n else f"ℹ️ {label} در لیست {kind} نبود.")
        if action in {"on", "off"}:
            flag = 1 if action == "on" else 0
            n = await db.execute("UPDATE relations SET enabled=?,updated_at=? WHERE owner_id=? AND user_id=? AND kind=?", (flag, _now(), owner, uid, kind))
            if not n:
                return await event.reply(f"ℹ️ {label} در لیست {kind} نیست؛ اول `{PREFIX}{kind} add` بزن.")
            return await event.reply(f"✅ پاسخ‌گویی {kind} برای {label} روشن شد." if flag else f"⏸ پاسخ‌گویی {kind} برای {label} خاموش شد.")
        return await _set_relation(event, kind, target, True)

    REL_ACTIONS = r"(add|del|remove|list|on|off)(?:\s+(\S+))?$"

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}(?:friend|دوست)\s+{REL_ACTIONS}"))
    async def friend_cmd(event):
        await _relation_command(event, "friend")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}(?:enemy|دشمن)\s+{REL_ACTIONS}"))
    async def enemy_cmd(event):
        await _relation_command(event, "enemy")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}(?:friend|دوست)\s+reply\s+(.+)$"))
    async def friend_reply_add(event):
        owner = (await my_id(client))
        await ensure_defaults(owner)
        text = event.pattern_match.group(1).strip()
        if not text or len(text) > 500:
            return await event.reply("❌ پاسخ باید بین 1 تا 500 کاراکتر باشد.")
        await db.execute(
            "INSERT INTO relation_replies(owner_id,kind,reply_text,created_at) VALUES(?,?,?,?)",
            (owner, "friend", text, _now()),
        )
        await event.reply("✅ پاسخ جدید برای دوست‌ها اضافه شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}(?:enemy|دشمن)\s+reply\s+(.+)$"))
    async def enemy_reply_add(event):
        owner = (await my_id(client))
        await ensure_defaults(owner)
        text = event.pattern_match.group(1).strip()
        if not text or len(text) > 500:
            return await event.reply("❌ پاسخ باید بین 1 تا 500 کاراکتر باشد.")
        await db.execute(
            "INSERT INTO relation_replies(owner_id,kind,reply_text,created_at) VALUES(?,?,?,?)",
            (owner, "enemy", text, _now()),
        )
        await event.reply("✅ پاسخ جدید برای دشمن‌ها اضافه شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}relation\s+reply\s+(friend|enemy)\s+(.+)$"))
    async def relation_reply_alias(event):
        kind = event.pattern_match.group(1)
        text = event.pattern_match.group(2).strip()
        owner = (await my_id(client))
        await ensure_defaults(owner)
        if not text or len(text) > 500:
            return await event.reply("❌ پاسخ باید بین 1 تا 500 کاراکتر باشد.")
        await db.execute(
            "INSERT INTO relation_replies(owner_id,kind,reply_text,created_at) VALUES(?,?,?,?)",
            (owner, kind, text, _now()),
        )
        await event.reply(f"✅ پاسخ جدید برای {kind} اضافه شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}relation\s+cooldown\s+(friend|enemy)\s+(\d+(?:\.\d+)?)$"))
    async def relation_cooldown(event):
        kind = event.pattern_match.group(1)
        seconds = max(2.0, min(float(event.pattern_match.group(2)), 3600.0))
        owner = (await my_id(client))
        await db.execute("UPDATE relations SET cooldown_seconds=?,updated_at=? WHERE owner_id=? AND kind=?", (seconds, _now(), owner, kind))
        await event.reply(f"✅ cooldown برای {kind} روی {seconds:g} ثانیه تنظیم شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}relation\s+(replies|stats|clear|reset)(?:\s+(friend|enemy))?$"))
    async def relation_tools(event):
        action, kind = event.pattern_match.group(1), event.pattern_match.group(2)
        owner = await my_id(client)
        await ensure_defaults(owner)
        kinds = [kind] if kind else ["friend", "enemy"]
        if action == "clear":
            for k in kinds:
                await db.execute("DELETE FROM relation_replies WHERE owner_id=? AND kind=?", (owner, k))
            names = " و ".join(kinds)
            return await event.reply(
                f"🗑 همهٔ پاسخ‌های {names} کاملاً پاک شد (به پیش‌فرض برنگشت).\n"
                f"تا وقتی با `{PREFIX}friend reply` / `{PREFIX}enemy reply` پاسخ جدید اضافه نکنی، جوابی فرستاده نمی‌شود.\n"
                f"برگرداندن پیش‌فرض‌ها: `{PREFIX}relation reset {kinds[0] if kind else 'friend|enemy'}`"
            )
        if action == "reset":
            for k in kinds:
                await db.execute("DELETE FROM relation_replies WHERE owner_id=? AND kind=?", (owner, k))
                await _seed(owner, k, DEFAULT_FRIEND_REPLIES if k == "friend" else DEFAULT_ENEMY_REPLIES)
            return await event.reply("♻️ پاسخ‌های پیش‌فرض " + " و ".join(kinds) + " برگردانده شد.")
        if action == "stats":
            rel = await db.fetchall("SELECT kind,COUNT(*) AS n FROM relations WHERE owner_id=? GROUP BY kind", (owner,))
            rep = await db.fetchall("SELECT kind,COUNT(*) AS n FROM relation_replies WHERE owner_id=? AND enabled=1 GROUP BY kind", (owner,))
            counts = {r['kind']: r['n'] for r in rel}
            reps = {r['kind']: r['n'] for r in rep}
            return await event.reply(f"🤝 Relations\n❤️ friend={counts.get('friend',0)} | replies={reps.get('friend',0)}\n😈 enemy={counts.get('enemy',0)} | replies={reps.get('enemy',0)}")
        rows = await db.fetchall("SELECT kind,reply_text FROM relation_replies WHERE owner_id=? AND enabled=1 ORDER BY rowid", (owner,))
        if kind:
            rows = [r for r in rows if r["kind"] == kind]
        if not rows:
            return await event.reply("خالی است.")
        text = "\n".join(f"{i+1}. [{r['kind']}] {r['reply_text']}" for i, r in enumerate(rows))
        await event.reply("🗂 Reply Pool\n" + text[:3900])

    @client.on(events.NewMessage(incoming=True))
    async def relation_responder(event):
        if event.out or not event.sender_id:
            return
        text = event.raw_text or ""
        if text.startswith(PREFIX):
            return
        owner = await my_id(client)
        row = await db.fetchone(
            "SELECT kind,enabled,cooldown_seconds FROM relations WHERE owner_id=? AND user_id=?",
            (owner, event.sender_id),
        )
        if not row or not row["enabled"]:
            return
        await ensure_defaults(owner)
        key = (int(event.chat_id), int(event.sender_id), row["kind"])
        now = time.monotonic()
        cooldown = max(2.0, float(row["cooldown_seconds"] or 8.0))
        if now - cooldowns.get(key, 0) < cooldown:
            return
        replies = await db.fetchall(
            "SELECT reply_text FROM relation_replies WHERE owner_id=? AND kind=? AND enabled=1",
            (owner, row["kind"]),
        )
        if not replies:
            return  # pool was cleared on purpose -> stay silent
        answer = random.choice(replies)["reply_text"]
        cooldowns[key] = now
        try:
            await event.reply(answer)  # always as a reply to THEIR message
        except Exception:  # noqa: BLE001 - e.g. their message was deleted meanwhile
            try:
                await client.send_message(event.chat_id, answer)
            except Exception:  # noqa: BLE001
                pass
