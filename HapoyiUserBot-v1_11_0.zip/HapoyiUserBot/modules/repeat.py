"""`.every 5m <text>` / `.time <text> 5m` - repeat a message in THIS chat until you stop it.

    .every 5m سلام            every 5 minutes (also: .time سلام 5m  /  .loop 5m سلام)
    .every 30s ping x10       only 10 times
    (as a reply)              every repetition replies to the replied message
    .every list [all]         operations of this chat (all = every chat)
    .every pause|resume <id|all>
    .every del <id|all|allchats>

Jobs live in the database, so they survive a restart. Each job runs only in the chat it was created in.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from datetime import datetime, timezone

from telethon import events
from telethon.errors import FloodWaitError, RPCError

from core.permissions import explain_error, reply_to_id
from utils.repeatspec import parse_repeat

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
MIN_INTERVAL = int(os.getenv("REPEAT_MIN_SECONDS", "10") or 10)
MAX_JOBS_PER_CHAT = 10
MAX_JOBS_TOTAL = 50
PERMANENT = {
    "ChatWriteForbiddenError", "UserBannedInChannelError", "ChannelPrivateError", "ChatIdInvalidError",
    "PeerIdInvalidError", "ChatAdminRequiredError", "ChannelInvalidError", "ChatRestrictedError", "InputUserDeactivatedError",
}
SELF_REFERENCE = re.compile(rf"^\s*{P}(?:every|loop|time)\b", re.IGNORECASE)


def _left(seconds: float) -> str:
    seconds = max(0, int(seconds))
    d, r = divmod(seconds, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    return " ".join(x for x in (f"{d}d" if d else "", f"{h}h" if h else "", f"{m}m" if m else "", f"{s}s" if (s or not (d or h or m)) else "") if x)


def setup(client, db):
    worker: dict[str, asyncio.Task | None] = {"task": None}

    # ------------------------------------------------------------------ worker
    async def run_due() -> None:
        now = time.time()
        rows = await db.fetchall(
            "SELECT id,chat_id,text,interval_s,next_run,remaining,reply_to FROM repeat_jobs WHERE enabled=1 AND next_run<=? ORDER BY next_run LIMIT 20",
            (now,),
        )
        for job in rows:
            nxt = job["next_run"] + job["interval_s"]
            if nxt < now:  # we were offline / late: do not fire a burst, just continue from now
                nxt = now + job["interval_s"]
            try:
                await client.send_message(job["chat_id"], job["text"], reply_to=job["reply_to"])
            except FloodWaitError as exc:
                await db.execute("UPDATE repeat_jobs SET next_run=?,last_error=? WHERE id=?", (now + exc.seconds + 1, f"FloodWait {exc.seconds}s", job["id"]))
                continue
            except RPCError as exc:
                name = exc.__class__.__name__
                if name in PERMANENT:
                    await db.execute("UPDATE repeat_jobs SET enabled=0,last_error=? WHERE id=?", (explain_error(exc), job["id"]))
                else:
                    await db.execute("UPDATE repeat_jobs SET next_run=?,last_error=? WHERE id=?", (nxt, name, job["id"]))
                continue
            except (ConnectionError, OSError):
                continue  # offline: keep the job, retry on the next loop
            remaining = job["remaining"]
            if remaining is not None and remaining <= 1:
                await db.execute("DELETE FROM repeat_jobs WHERE id=?", (job["id"],))
            else:
                await db.execute(
                    "UPDATE repeat_jobs SET sent=sent+1,next_run=?,remaining=?,last_error=NULL WHERE id=?",
                    (nxt, None if remaining is None else remaining - 1, job["id"]),
                )

    async def loop() -> None:
        while True:
            try:
                if client.is_connected():
                    await run_due()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                log.warning("repeat worker: %s: %s", exc.__class__.__name__, exc)
            await asyncio.sleep(1.0)

    def ensure_worker() -> None:
        t = worker["task"]
        if t is None or t.done():
            worker["task"] = asyncio.get_running_loop().create_task(loop())

    ensure_worker()

    # ------------------------------------------------------------------ commands
    HELP = (
        "🔁 Repeat\n"
        f"`{PREFIX}every 5m متن` یا `{PREFIX}time متن 5m` — هر ۵ دقیقه در همین گپ می‌فرستد (s,m,h,d,w)\n"
        f"`{PREFIX}every 30s متن x10` — فقط ۱۰ بار\n"
        "اگر روی یک پیام Reply کنی، هر بار روی همان پیام ریپلای می‌شود\n"
        f"`{PREFIX}every list [all]` — لیست عملیات این گپ (all = همهٔ گپ‌ها)\n"
        f"`{PREFIX}every pause|resume <id|all>`\n"
        f"`{PREFIX}every del <id|all|allchats>`"
    )

    async def _select(chat_id: int, which: str, *, all_chats: bool = False):
        which = which.strip().lstrip("#").lower()
        if which == "all":
            return await db.fetchall("SELECT id FROM repeat_jobs" + ("" if all_chats else " WHERE chat_id=?"), () if all_chats else (chat_id,))
        if which == "allchats":
            return await db.fetchall("SELECT id FROM repeat_jobs")
        if which.isdigit():
            return await db.fetchall("SELECT id FROM repeat_jobs WHERE id=? AND chat_id=?", (int(which), chat_id))
        return None

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}(every|loop|time)(?:\s+(.*))?$"))
    async def every(event):
        keyword = event.pattern_match.group(1).lower()
        arg = (event.pattern_match.group(2) or "").strip()
        spec = parse_repeat(arg)

        if spec is not None:
            seconds, text, times = spec
            if seconds < MIN_INTERVAL:
                return await event.reply(f"❌ حداقل فاصله {MIN_INTERVAL} ثانیه است (برای جلوگیری از FloodWait و بن).")
            if SELF_REFERENCE.match(text):
                return await event.reply("❌ متن نباید خودش دستور every/time باشد (حلقهٔ بی‌نهایت).")
            if len(text) > 4000:
                return await event.reply("❌ متن خیلی طولانی است.")
            per_chat = await db.fetchone("SELECT COUNT(*) AS n FROM repeat_jobs WHERE chat_id=?", (event.chat_id,))
            total = await db.fetchone("SELECT COUNT(*) AS n FROM repeat_jobs")
            if per_chat["n"] >= MAX_JOBS_PER_CHAT or total["n"] >= MAX_JOBS_TOTAL:
                return await event.reply(f"❌ سقف عملیات پر است ({MAX_JOBS_PER_CHAT} در هر گپ، {MAX_JOBS_TOTAL} کل). با `{PREFIX}every del` پاک کن.")
            ensure_worker()
            job_id = await db.insert(
                "INSERT INTO repeat_jobs(chat_id,text,interval_s,next_run,remaining,enabled,sent,reply_to,created_at) VALUES(?,?,?,?,?,1,0,?,?)",
                (event.chat_id, text, seconds, time.time() + seconds, times, reply_to_id(event), datetime.now(timezone.utc).isoformat()),
            )
            return await event.reply(
                f"🔁 عملیات #{job_id} ثبت شد: هر {_left(seconds)} در همین گپ"
                + (f"، {times} بار" if times else "")
                + f"\n«{text[:80]}»\nمدیریت: `{PREFIX}every list` / `{PREFIX}every del {job_id}`"
            )

        if keyword == "time":
            return  # plain `.time` / `.time <timezone>` is the clock command in personal.py

        parts = arg.split(None, 2)
        word = parts[0].lower() if parts else ""
        if not word:
            return await event.reply(HELP)

        if word == "list":
            everywhere = len(parts) > 1 and parts[1].lower() == "all"
            rows = await db.fetchall(
                "SELECT id,chat_id,text,interval_s,next_run,remaining,enabled,sent,last_error FROM repeat_jobs"
                + ("" if everywhere else " WHERE chat_id=?") + " ORDER BY id",
                () if everywhere else (event.chat_id,),
            )
            if not rows:
                return await event.reply("🔁 عملیات تکرار فعالی وجود ندارد." if everywhere else f"🔁 در این گپ عملیاتی نیست. (`{PREFIX}every list all` همهٔ گپ‌ها)")
            now = time.time()
            lines = [f"🔁 عملیات ({len(rows)})"]
            for r in rows:
                state = "ON" if r["enabled"] else "OFF"
                nxt = f" | بعدی: {_left(r['next_run'] - now)}" if r["enabled"] else ""
                left = "∞" if r["remaining"] is None else str(r["remaining"])
                where = f" | chat={r['chat_id']}" if everywhere else ""
                err = f"\n   ⚠️ {r['last_error']}" if r["last_error"] else ""
                lines.append(f"#{r['id']} [{state}] هر {_left(r['interval_s'])}{where} | ارسال‌شده: {r['sent']} | باقی: {left}{nxt}\n   «{r['text'][:60]}»{err}")
            return await event.reply("\n".join(lines)[:3900])

        if word in {"del", "delete", "rm", "stop", "pause", "resume"}:
            if len(parts) < 2:
                return await event.reply(f"فرمت: `{PREFIX}every {word} <id|all>`")
            rows = await _select(event.chat_id, parts[1])
            if rows is None:
                return await event.reply("❌ شمارهٔ عملیات یا all بده.")
            if not rows:
                return await event.reply("ℹ️ عملیاتی با این مشخصات در این گپ پیدا نشد.")
            for r in rows:
                if word == "pause":
                    await db.execute("UPDATE repeat_jobs SET enabled=0 WHERE id=?", (r["id"],))
                elif word == "resume":
                    await db.execute("UPDATE repeat_jobs SET enabled=1,last_error=NULL,next_run=?+interval_s WHERE id=?", (time.time(), r["id"]))
                else:
                    await db.execute("DELETE FROM repeat_jobs WHERE id=?", (r["id"],))
            verb = {"pause": "متوقف شد", "resume": "دوباره شروع شد"}.get(word, "حذف شد")
            return await event.reply(f"✅ {len(rows)} عملیات {verb}.")

        await event.reply("❌ فرمت نامعتبر.\n\n" + HELP)
