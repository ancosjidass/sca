"""`.tag` - mention members of the group (only when YOU are admin/owner).

    .tag                 the 300 most active members
    .tag 50              the 50 most active
    .tag admin [N]       the owner + admins (as many as exist, max N)
    .tag normal [N]      normal members, most active first
    .tag 20 text...      the text goes in front of the first message
    .tag stop            stop a running tag

Never an error because the group is small: you simply get everybody who exists (max 300).
Activity = number of messages in the last TAG_SCAN_LIMIT (default 5000) messages.
Persian: `.تگ`, `ادمین`, `عادی`, `همه`.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from datetime import datetime, timezone

from telethon import events
from telethon.errors import FloodWaitError, RPCError
from telethon.tl.types import ChannelParticipantCreator, ChannelParticipantsAdmins, ChatParticipantCreator

from core.permissions import explain_error, reply_to_id, require_admin
from core.identity import my_id
from utils.activity import display_name, scan_activity

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
MAX_TAG = 300
PER_MESSAGE = max(1, min(int(os.getenv("TAG_PER_MESSAGE", "8") or 8), 50))
PAUSE = float(os.getenv("TAG_PAUSE_SECONDS", "1.5") or 1.5)
SCAN_LIMIT = int(os.getenv("TAG_SCAN_LIMIT", "5000") or 5000)
MEMBER_CAP = 20000

ADMIN_WORDS = {"admin", "admins", "ادمین", "ادمین‌ها", "ادمینا", "ادمینها"}
NORMAL_WORDS = {"normal", "member", "members", "عادی", "عادی‌ها", "عادیا", "عادیها", "اعضا"}
ALL_WORDS = {"all", "همه"}
STOP_WORDS = {"stop", "cancel", "توقف", "لغو", "استپ"}
_FA = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
_BAD_NAME_CHARS = re.compile(r"[\[\]()\\*_~`|<>#\r\n]")


def parse_tag_args(args: str | None) -> dict:
    """{'mode': all|admin|normal|stop, 'n': 1..300, 'text': str}"""
    mode, n, text_words = "all", MAX_TAG, []
    tokens = (args or "").split()
    seen_mode = seen_n = False
    for i, tok in enumerate(tokens):
        low = tok.lower()
        norm = tok.translate(_FA)
        if not seen_mode and low in STOP_WORDS:
            return {"mode": "stop", "n": 0, "text": ""}
        if not seen_mode and low in ADMIN_WORDS:
            mode, seen_mode = "admin", True
        elif not seen_mode and low in NORMAL_WORDS:
            mode, seen_mode = "normal", True
        elif not seen_mode and low in ALL_WORDS:
            mode, seen_mode = "all", True
        elif not seen_n and norm.isdigit():
            n, seen_n = max(1, min(int(norm), MAX_TAG)), True
        else:
            text_words = tokens[i:]  # everything from the first non-option word on is the message text
            break
    return {"mode": mode, "n": n, "text": " ".join(text_words)}


def mention(user) -> str:
    name = _BAD_NAME_CHARS.sub("", display_name(user, "👤")).strip()[:25] or "👤"
    return f"[{name}](tg://user?id={int(user.id)})"


def usable(user, me_id: int) -> bool:
    return not (getattr(user, "bot", False) or getattr(user, "deleted", False) or int(user.id) == me_id)


def is_creator(user) -> bool:
    return isinstance(getattr(user, "participant", None), (ChannelParticipantCreator, ChatParticipantCreator))


def pick_targets(*, mode: str, n: int, me_id: int, members: list, admins: list, counts) -> list:
    """Pure selection logic (unit tested). `members`/`admins` are user entities, owner/admins first in `admins`."""
    admin_ids = {int(u.id) for u in admins}
    if mode == "admin":
        pool = [u for u in admins if usable(u, me_id)]
    elif mode == "normal":
        pool = [u for u in members if int(u.id) not in admin_ids and usable(u, me_id)]
    else:
        pool = [u for u in members if usable(u, me_id)]
    seen, unique = set(), []
    for u in pool:
        if int(u.id) not in seen:
            seen.add(int(u.id))
            unique.append(u)
    if len(unique) <= n:
        return unique if mode == "admin" else sorted(unique, key=lambda u: -counts.get(int(u.id), 0)) if counts else unique
    order = {int(u.id): i for i, u in enumerate(unique)}
    return sorted(unique, key=lambda u: (-counts.get(int(u.id), 0), order[int(u.id)]))[:n]


def setup(client, db):
    running: dict[int, asyncio.Task] = {}

    async def _members(chat_id: int, admins_only: bool = False) -> list:
        out = []
        kwargs = {"filter": ChannelParticipantsAdmins} if admins_only else {}
        async for u in client.iter_participants(chat_id, limit=MEMBER_CAP, **kwargs):
            out.append(u)
        if admins_only:
            out.sort(key=lambda u: 0 if is_creator(u) else 1)  # stable: owner first
        return out

    async def _send_all(chat_id: int, targets: list, header: str, reply_to: int | None) -> int:
        sent = 0
        chunks = [targets[i:i + PER_MESSAGE] for i in range(0, len(targets), PER_MESSAGE)]
        for idx, chunk in enumerate(chunks):
            body = " ".join(mention(u) for u in chunk)
            text = f"{header}\n{body}" if (header and idx == 0) else body
            while True:
                try:
                    await client.send_message(chat_id, text, parse_mode="md", reply_to=reply_to, link_preview=False)
                    sent += len(chunk)
                    break
                except FloodWaitError as exc:
                    await asyncio.sleep(min(exc.seconds + 1, 120))
                except RPCError as exc:
                    log.warning("tag send failed in %s: %s", chat_id, exc.__class__.__name__)
                    return sent
            if idx + 1 < len(chunks):
                await asyncio.sleep(PAUSE)
        return sent

    async def _note(chat_id: int, text: str, seconds: float = 8) -> None:
        try:
            msg = await client.send_message(chat_id, text)
            await db.insert(
                "INSERT INTO delete_jobs(chat_id,message_ids,run_at,kind,preview,created_at) VALUES(?,?,?,?,?,?)",
                (chat_id, f"[{msg.id}]", time.time() + seconds, "note", "tag", datetime.now(timezone.utc).isoformat()),
            )
        except RPCError:
            pass

    async def _job(chat_id: int, targets: list, header: str, reply_to: int | None) -> None:
        try:
            sent = await _send_all(chat_id, targets, header, reply_to)
            await _note(chat_id, f"🏷 {sent} نفر تگ شدند.")
        except asyncio.CancelledError:
            await _note(chat_id, "🛑 تگ متوقف شد.")
            raise
        finally:
            running.pop(chat_id, None)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}(?:tag|تگ)(?:\s+(.*))?$"))
    async def tag(event):
        opts = parse_tag_args(event.pattern_match.group(1))
        chat = event.chat_id
        if opts["mode"] == "stop":
            task = running.get(chat)
            if not task:
                return await event.reply("ℹ️ تگ فعالی در این گپ نیست.")
            task.cancel()
            return await event.delete()
        if not event.is_group:
            return await event.reply("❌ تگ فقط در گروه کار می‌کند.")
        perm = await require_admin(client, chat)
        if not perm.allowed:
            return await event.reply("❌ " + perm.reason)
        if chat in running and not running[chat].done():
            return await event.reply(f"⚠️ یک تگ در حال اجراست؛ `{PREFIX}tag stop` بزن.")
        me = await my_id(client)
        try:
            admins = await _members(chat, admins_only=True)
            members = admins if opts["mode"] == "admin" else await _members(chat)
            pool_size = len(members)
            counts = {}
            if opts["mode"] != "admin" and pool_size > opts["n"]:
                counts, _ = await scan_activity(client, chat, SCAN_LIMIT)
        except RPCError as exc:
            return await event.reply(f"❌ لیست اعضا گرفته نشد: {explain_error(exc)}")
        targets = pick_targets(mode=opts["mode"], n=opts["n"], me_id=me, members=members, admins=admins, counts=counts)
        if not targets:
            return await event.reply("ℹ️ کسی برای تگ کردن پیدا نشد.")
        reply_to = reply_to_id(event)
        await event.delete()
        running[chat] = asyncio.get_running_loop().create_task(_job(chat, targets, opts["text"], reply_to))
