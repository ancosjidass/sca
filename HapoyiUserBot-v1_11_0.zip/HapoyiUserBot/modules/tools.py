from __future__ import annotations

import asyncio
import os
import re
from datetime import datetime
from zoneinfo import ZoneInfo

from telethon import events
from telethon.errors import RPCError

from core.permissions import explain_error, get_real_reply
from utils.react import send_reaction

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}id(?:\s+(\S+))?$"))
    async def ident(event):
        arg = event.pattern_match.group(1)
        target = await event.get_sender() if not arg else (int(arg) if arg.lstrip("-").isdigit() else await client.get_entity(arg))
        if not arg and event.is_group:
            chat = await event.get_chat()
            return await event.reply(f"🆔 Chat ID: `{event.chat_id}`\nType: {chat.__class__.__name__}")
        await event.reply(f"🆔 ID: `{getattr(target,'id',target)}`\nUsername: `@{getattr(target,'username',None) or '—'}`")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}msginfo$"))
    async def msginfo(event):
        if not event.is_reply:
            return await event.reply("❌ Reply کن.")
        m = await event.get_reply_message()
        text = f"📨 Message\nID: {m.id}\nSender: {m.sender_id}\nDate: {m.date}\nReply: {m.reply_to_msg_id}\nMedia: {type(m.media).__name__ if m.media else 'none'}\nViews: {m.views or 0}\nForwards: {m.forwards or 0}"
        # Is this message one that the Echo feature sent on somebody's behalf?
        row = await db.fetchone("SELECT source_user_id,source_name,source_msg_id,text,created_at FROM echo_messages WHERE chat_id=? AND message_id=?", (event.chat_id, m.id))
        if row:
            text += (
                "\n\n🔁 Echo: بله\n"
                f"از: {row['source_name'] or '—'} ({row['source_user_id']})\n"
                f"پیام محرک: #{row['source_msg_id']}\n"
                f"متن اولیه: {row['text']}\n"
                f"زمان: {row['created_at']}"
            )
        else:
            text += "\n\n🔁 Echo: خیر"
        await event.reply(text)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}save$"))
    async def save(event):
        m = await get_real_reply(event)
        if m is None:
            return await event.reply("❌ Reply کن.")
        try:
            if not getattr(m, "noforwards", False):
                await client.forward_messages("me", m)
                return await event.reply("✅ به Saved Messages فوروارد شد.")
        except RPCError:
            pass  # forwarding restricted -> fall back to a copy below
        # Protected chat / restricted forwarding: send a COPY (download + upload) instead.
        import os as _os
        import tempfile as _tempfile

        try:
            if m.media:
                workdir = _tempfile.mkdtemp()
                path = await m.download_media(file=workdir + "/")
                if not path:
                    return await event.reply("❌ دانلود نشد (مدیای مخرب‌شونده/محافظت‌شده ممکن است قابل ذخیره نباشد).")
                try:
                    await client.send_file("me", path, caption=m.raw_text or None)
                finally:
                    try:
                        _os.remove(path)
                        _os.rmdir(workdir)
                    except OSError:
                        pass
            elif m.raw_text:
                await client.send_message("me", m.raw_text)
            else:
                return await event.reply("❌ چیزی برای ذخیره نبود.")
        except RPCError as exc:
            return await event.reply(f"❌ ذخیره نشد: {explain_error(exc)}")
        await event.reply("✅ کپی در Saved Messages ذخیره شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}search\s+(.+)$"))
    async def search(event):
        needle = event.pattern_match.group(1)
        rows = []
        async for m in client.iter_messages(event.chat_id, search=needle, limit=20):
            rows.append(f"• {m.id} | {m.date.strftime('%Y-%m-%d %H:%M')} | {m.raw_text[:120]}")
        await event.reply("🔎 Search\n" + "\n".join(rows) if rows else "🔎 چیزی پیدا نشد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}readall(?:\s+(all))?$"))
    async def readall(event):
        if not event.pattern_match.group(1):
            await client.send_read_acknowledge(event.chat_id, clear_mentions=True, clear_reactions=True)
            return await event.reply("✅ این گپ خوانده شد. (`.readall all` = همهٔ گپ‌ها)")
        n = 0
        async for d in client.iter_dialogs():
            if d.unread_count or getattr(d, "unread_mentions_count", 0) or getattr(d.dialog, "unread_reactions_count", 0):
                try:
                    await client.send_read_acknowledge(d.entity, clear_mentions=True, clear_reactions=True)
                    n += 1
                except RPCError:
                    continue
                await asyncio.sleep(0.15)
        await event.reply(f"✅ {n} گپ خوانده شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}react\s+(\S+)$"))
    async def react(event):
        m = await get_real_reply(event)
        if m is None:
            return await event.reply("❌ Reply کن.")
        await send_reaction(client, event.chat_id, m.id, event.pattern_match.group(1))
        await event.delete()
