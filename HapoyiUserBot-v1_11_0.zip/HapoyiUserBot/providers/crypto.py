from __future__ import annotations

import asyncio
import logging
import os
import time
from dataclasses import dataclass
from typing import Any

import aiohttp

from providers.iran import IranRates, RateUnavailable, shared

log = logging.getLogger(__name__)

COINGECKO = {
    "btc": "bitcoin", "bitcoin": "bitcoin", "بیت کوین": "bitcoin", "بیتکوین": "bitcoin",
    "eth": "ethereum", "ethereum": "ethereum", "اتریوم": "ethereum",
    "sol": "solana", "solana": "solana", "سولانا": "solana",
    "usdt": "tether", "tether": "tether", "تتر": "tether",
    "bnb": "binancecoin", "xrp": "ripple", "doge": "dogecoin",
    "ton": "the-open-network", "toncoin": "the-open-network", "تون": "the-open-network",
    "ada": "cardano", "cardano": "cardano", "trx": "tron", "ترون": "tron",
    "avax": "avalanche-2", "dot": "polkadot", "link": "chainlink",
}
FA_SYMBOL = {
    "bitcoin": "BTC", "ethereum": "ETH", "solana": "SOL", "tether": "USDT", "the-open-network": "TON",
    "binancecoin": "BNB", "ripple": "XRP", "dogecoin": "DOGE", "cardano": "ADA", "tron": "TRX",
    "avalanche-2": "AVAX", "polkadot": "DOT", "chainlink": "LINK",
}


@dataclass
class Quote:
    symbol: str
    name: str
    usd: float
    toman: float | None
    change_24h: float | None
    source: str
    at: float


class MarketProvider:
    """Crypto quotes. Priority: Nobitex (USDT + Toman in one call) > Binance > CoinGecko.

    Toman for coins that Nobitex does not list = USD price x live free-market dollar (providers/iran.py).
    """

    def __init__(self, cache_seconds: int = 3, rates: IranRates | None = None):
        self.cache_seconds = cache_seconds
        self.rates = rates or shared()
        self.cache: dict[str, tuple[float, Quote]] = {}
        self._lock = asyncio.Lock()

    def resolve(self, raw: str) -> str | None:
        key = raw.strip().lower().replace("₿", "btc")
        return COINGECKO.get(key)

    async def _get_json(self, session: aiohttp.ClientSession, url: str, *, params: dict[str, Any] | None = None) -> dict[str, Any]:
        headers = {"User-Agent": "HapoyiUserBot/1.0"}
        api_key = os.getenv("COINGECKO_API_KEY", "").strip()
        if api_key and "coingecko" in url:
            headers["x-cg-demo-api-key"] = api_key
        async with session.get(url, params=params, headers=headers, timeout=aiohttp.ClientTimeout(total=10)) as r:
            r.raise_for_status()
            return await r.json()

    async def _usd_toman_or_none(self) -> float | None:
        try:
            return (await self.rates.usd_toman()).toman
        except RateUnavailable:
            return None

    async def quote(self, raw: str) -> Quote:
        coin_id = self.resolve(raw)
        if not coin_id:
            raise ValueError("ارز ناشناخته است")
        async with self._lock:
            cached = self.cache.get(coin_id)
            if cached and time.monotonic() - cached[0] < self.cache_seconds:
                return cached[1]
            q = await self._fetch_quote(coin_id)
            self.cache[coin_id] = (time.monotonic(), q)
            return q

    async def _fetch_quote(self, coin_id: str) -> Quote:
        sym = self.display_symbol(coin_id)
        errors: list[str] = []

        # 1) Nobitex: live USDT price + live Toman price + 24h change
        try:
            data = (await self.rates.nobitex_coins([sym])).get(sym)
            if data and data["usd"] is not None:
                toman = data["toman"]
                if toman is None:
                    ut = await self._usd_toman_or_none()
                    toman = data["usd"] * ut if ut else None
                return Quote(sym, coin_id, data["usd"], toman, data["change"], "Nobitex", time.time())
        except Exception as exc:  # noqa: BLE001
            errors.append(f"Nobitex: {exc.__class__.__name__}")

        # 2) Binance (USD) + live dollar
        try:
            b = await self.rates.binance(sym)
            ut = await self._usd_toman_or_none()
            return Quote(sym, coin_id, b["usd"], b["usd"] * ut if ut else None, b["change"], "Binance" + (" + بازار آزاد" if ut else ""), time.time())
        except Exception as exc:  # noqa: BLE001
            errors.append(f"Binance: {exc.__class__.__name__}")

        # 3) CoinGecko (USD) + live dollar
        try:
            async with aiohttp.ClientSession() as session:
                cg = await self._get_json(session, "https://api.coingecko.com/api/v3/simple/price",
                                          params={"ids": coin_id, "vs_currencies": "usd", "include_24hr_change": "true"})
            item = cg.get(coin_id) or {}
            usd = float(item["usd"])
            change = item.get("usd_24h_change")
            ut = await self._usd_toman_or_none()
            return Quote(sym, coin_id, usd, usd * ut if ut else None, float(change) if change is not None else None,
                         "CoinGecko" + (" + بازار آزاد" if ut else ""), time.time())
        except Exception as exc:  # noqa: BLE001
            errors.append(f"CoinGecko: {exc.__class__.__name__}")

        raise RateUnavailable("هیچ منبعی قیمت " + sym + " را نداد (" + ", ".join(errors) + ")")

    @staticmethod
    def display_symbol(coin_id: str) -> str:
        return FA_SYMBOL.get(coin_id, coin_id.upper())

    async def market(self, symbols: list[str]) -> list[Quote]:
        quotes = []
        for symbol in symbols:
            try:
                quotes.append(await self.quote(symbol))
            except Exception:  # noqa: BLE001
                continue
        return quotes
