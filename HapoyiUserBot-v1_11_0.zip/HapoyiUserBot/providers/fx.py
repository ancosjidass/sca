from __future__ import annotations

from providers.iran import IranRates, RateUnavailable, shared


class FXProvider:
    """Kept for backward compatibility. Values now come from the Iranian free market (see providers/iran.py)."""

    def __init__(self, cache_seconds: int = 60, rates: IranRates | None = None):
        self.rates = rates or shared()

    async def usd_to_irr(self) -> float:
        """USD price in Rial (Toman x 10). Raises RateUnavailable instead of returning a wrong number."""
        return (await self.rates.usd_toman()).toman * 10.0


__all__ = ["FXProvider", "RateUnavailable"]
