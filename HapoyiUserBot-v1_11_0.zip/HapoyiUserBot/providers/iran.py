"""Live Iranian market rates (USD/EUR in Toman, crypto in Toman).

Why this exists: the old code used a *reference* FX endpoint (open.er-api.com). That returns the
official/reference IRR rate, which is nowhere near the free-market price (that is how you got "133"
for a dollar that costs 270k). Here every number comes from an Iranian market source and an
implausible / missing value is an *error* - we never invent or fall back to a reference rate.

Sources (all free, no API key) - tried in this priority order for USD:
  custom (IRAN_FX_URL) > Navasan (NAVASAN_API_KEY, optional) > TGJU (free-market dollar) > Nobitex USDT/IRT > Wallex USDT/TMN
Crypto prices come from Nobitex (USDT + Toman in one call), then Binance, then CoinGecko.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

import aiohttp

log = logging.getLogger(__name__)

UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"
PLAUSIBLE_TOMAN = (1_000.0, 50_000_000.0)  # per 1 USD / EUR; outside this => bad data
_FA_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


class RateUnavailable(RuntimeError):
    """No source could give a trustworthy value."""


@dataclass
class Rate:
    toman: float
    source: str
    at: float = field(default_factory=time.time)
    note: str = ""


@dataclass
class SourceStatus:
    name: str
    ok: bool
    detail: str
    ms: int


def parse_number(value: Any) -> float:
    """'1,234,500' / '۱۲۳۴۵۰۰' / 1234500 -> 1234500.0"""
    if value is None:
        raise ValueError("empty")
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).translate(_FA_DIGITS)
    text = re.sub(r"[^0-9.\-]", "", text.replace("٬", "").replace(",", ""))
    if not text or text in {"-", "."}:
        raise ValueError(f"not a number: {value!r}")
    return float(text)


def _check(toman: float, what: str) -> float:
    lo, hi = PLAUSIBLE_TOMAN
    if not (lo <= toman <= hi):
        raise ValueError(f"{what} implausible: {toman:g} toman")
    return toman


FetchJson = Callable[..., Awaitable[Any]]


class IranRates:
    CACHE_SECONDS = float(os.getenv("PRICE_CACHE_SECONDS", "4") or 4)

    def __init__(self, fetch_json: FetchJson | None = None, cache_seconds: float | None = None):
        self._fetch = fetch_json or self._http_json
        self.cache_seconds = self.CACHE_SECONDS if cache_seconds is None else cache_seconds
        self._cache: tuple[float, dict[str, Any]] | None = None
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------ http
    @staticmethod
    async def _http_json(url: str, *, params: dict | None = None, headers: dict | None = None, timeout: float = 7.0) -> Any:
        h = {"User-Agent": UA, "Accept": "application/json,text/plain,*/*"}
        h.update(headers or {})
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params, headers=h, timeout=aiohttp.ClientTimeout(total=timeout)) as r:
                r.raise_for_status()
                return await r.json(content_type=None)

    # ------------------------------------------------------------------ sources
    async def _src_custom(self) -> dict[str, float]:
        url = os.getenv("IRAN_FX_URL", "").strip()
        if not url:
            raise ValueError("IRAN_FX_URL not set")
        headers = {}
        key = os.getenv("IRAN_FX_KEY", "").strip()
        if key:
            headers["Authorization"] = f"Bearer {key}"
        data = await self._fetch(url, headers=headers)
        irr = None
        for cand in (data.get("USD_IRR"), data.get("usd_irr"), data.get("rate"),
                     (data.get("rates") or {}).get("IRR"), (data.get("rates") or {}).get("irr")):
            if cand is not None:
                irr = parse_number(cand)
                break
        if irr is None:
            raise ValueError("IRR rate not found in custom response")
        return {"usd": _check(irr / 10.0, "custom usd")}

    async def _src_navasan(self) -> dict[str, float]:
        """Optional keyed source (NAVASAN_API_KEY): quotes are already in Toman."""
        key = os.getenv("NAVASAN_API_KEY", "").strip()
        if not key:
            raise ValueError("NAVASAN_API_KEY not set")
        params = {"api_key": key, "item": "usd_sell,eur_sell"}
        try:
            # Navasan's own docs show plain http://, so try that first and fall back to https.
            data = await self._fetch("http://api.navasan.tech/latest/", params=params)
        except Exception:  # noqa: BLE001
            data = await self._fetch("https://api.navasan.tech/latest/", params=params)
        out: dict[str, float] = {}
        for item, name in (("usd_sell", "usd"), ("eur_sell", "eur")):
            node = data.get(item)
            raw = node.get("value") if isinstance(node, dict) else node
            if raw not in (None, ""):
                out[name] = _check(parse_number(raw), f"navasan {name}")
        if "usd" not in out:
            raise ValueError("usd_sell missing in Navasan response")
        return out

    async def _src_tgju(self) -> dict[str, float]:
        data = await self._fetch("https://call4.tgju.org/ajax.json", headers={"Referer": "https://www.tgju.org/"})
        cur = data.get("current") if isinstance(data, dict) and isinstance(data.get("current"), dict) else data
        out: dict[str, float] = {}
        for key, name in (("price_dollar_rl", "usd"), ("price_eur", "eur")):
            item = cur.get(key) if isinstance(cur, dict) else None
            if item is None:
                continue
            raw = item.get("p") if isinstance(item, dict) else item
            try:
                out[name] = _check(parse_number(raw) / 10.0, f"tgju {name}")  # TGJU quotes Rial
            except ValueError as exc:
                log.debug("tgju %s skipped: %s", name, exc)
        if "usd" not in out:
            raise ValueError("price_dollar_rl missing in TGJU response")
        return out

    async def _src_nobitex(self) -> dict[str, float]:
        data = await self._fetch("https://api.nobitex.ir/market/stats", params={"srcCurrency": "usdt", "dstCurrency": "rls"})
        item = (data.get("stats") or {}).get("usdt-rls")
        if not item:
            raise ValueError("usdt-rls missing")
        return {"usd": _check(parse_number(item["latest"]) / 10.0, "nobitex usdt")}  # Rial -> Toman

    async def _src_wallex(self) -> dict[str, float]:
        data = await self._fetch("https://api.wallex.ir/v1/markets")
        item = ((data.get("result") or {}).get("symbols") or {}).get("USDTTMN")
        if not item:
            raise ValueError("USDTTMN missing")
        return {"usd": _check(parse_number((item.get("stats") or {}).get("lastPrice")), "wallex usdt")}  # already Toman

    SOURCES: tuple[tuple[str, str], ...] = (
        ("custom", "_src_custom"),
        ("Navasan", "_src_navasan"),
        ("TGJU", "_src_tgju"),
        ("Nobitex", "_src_nobitex"),
        ("Wallex", "_src_wallex"),
    )

    async def _gather(self) -> dict[str, Any]:
        """Query every source in parallel. Returns {name: dict | Exception}."""
        names, tasks = [], []
        for name, attr in self.SOURCES:
            if name == "custom" and not os.getenv("IRAN_FX_URL", "").strip():
                continue
            if name == "Navasan" and not os.getenv("NAVASAN_API_KEY", "").strip():
                continue
            names.append(name)
            tasks.append(self._timed(getattr(self, attr)))
        results = await asyncio.gather(*tasks)
        return dict(zip(names, results))

    @staticmethod
    async def _timed(fn: Callable[[], Awaitable[dict]]) -> dict[str, Any]:
        t0 = time.monotonic()
        try:
            values = await asyncio.wait_for(fn(), timeout=9)
            return {"ok": True, "values": values, "ms": int((time.monotonic() - t0) * 1000)}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": f"{exc.__class__.__name__}: {exc}"[:160], "ms": int((time.monotonic() - t0) * 1000)}

    async def snapshot(self, force: bool = False) -> dict[str, Any]:
        async with self._lock:
            now = time.monotonic()
            if not force and self._cache and now - self._cache[0] < self.cache_seconds:
                return self._cache[1]
            snap = await self._gather()
            if any(v["ok"] for v in snap.values()):
                self._cache = (now, snap)
            return snap

    # ------------------------------------------------------------------ public API
    @staticmethod
    def _pick(snap: dict[str, Any], key: str) -> Rate:
        picked = None
        others: list[float] = []
        for name, res in snap.items():  # dict order == priority order
            if res["ok"] and key in res["values"]:
                if picked is None:
                    picked = (name, res["values"][key])
                else:
                    others.append(res["values"][key])
        if picked is None:
            tried = ", ".join(f"{n}: {r.get('error', 'no ' + key)}" for n, r in snap.items())
            raise RateUnavailable(f"هیچ منبعی قیمت {key.upper()} را نداد ({tried})")
        name, value = picked
        note = ""
        if others and max(abs(value - o) / value for o in others) > 0.08:
            note = "⚠️ منابع بیش از ۸٪ با هم اختلاف دارند"
        return Rate(value, name, time.time(), note)

    async def usd_toman(self) -> Rate:
        return self._pick(await self.snapshot(), "usd")

    async def eur_toman(self) -> Rate:
        snap = await self.snapshot()
        try:
            return self._pick(snap, "eur")
        except RateUnavailable:
            pass
        # cross rate: USD(Toman) / (EUR per USD)
        usd = self._pick(snap, "usd")
        data = await self._fetch("https://open.er-api.com/v6/latest/USD")
        eur_per_usd = parse_number((data.get("rates") or {})["EUR"])
        return Rate(usd.toman / eur_per_usd, f"{usd.source} × cross", time.time(), "نرخ یورو از روی cross محاسبه شد")

    async def diagnostics(self) -> list[SourceStatus]:
        snap = await self.snapshot(force=True)
        rows = []
        for name, res in snap.items():
            if res["ok"]:
                vals = ", ".join(f"{k}={v:,.0f}" for k, v in res["values"].items())
                rows.append(SourceStatus(name, True, vals, res["ms"]))
            else:
                rows.append(SourceStatus(name, False, res["error"], res["ms"]))
        return rows

    # ------------------------------------------------------------------ crypto
    async def nobitex_coins(self, symbols: list[str]) -> dict[str, dict[str, float | None]]:
        """{'BTC': {'usd': 67000.0, 'toman': 4.1e9, 'change': -0.5}} straight from Nobitex."""
        syms = ",".join(s.lower() for s in symbols)
        data = await self._fetch("https://api.nobitex.ir/market/stats", params={"srcCurrency": syms, "dstCurrency": "usdt,rls"})
        stats = data.get("stats") or {}
        out: dict[str, dict[str, float | None]] = {}
        for s in symbols:
            low = s.lower()
            usdt = stats.get(f"{low}-usdt")
            rls = stats.get(f"{low}-rls")
            entry: dict[str, float | None] = {"usd": None, "toman": None, "change": None}
            if low == "usdt":
                entry["usd"] = 1.0
            elif usdt and usdt.get("latest") not in (None, "", "0"):
                entry["usd"] = parse_number(usdt["latest"])
                if usdt.get("dayChange") not in (None, ""):
                    entry["change"] = parse_number(usdt["dayChange"])
            if rls and rls.get("latest") not in (None, "", "0"):
                entry["toman"] = parse_number(rls["latest"]) / 10.0
                if entry["change"] is None and rls.get("dayChange") not in (None, ""):
                    entry["change"] = parse_number(rls["dayChange"])
            if entry["usd"] is not None or entry["toman"] is not None:
                out[s.upper()] = entry
        return out

    async def binance(self, symbol: str) -> dict[str, float]:
        data = await self._fetch("https://api.binance.com/api/v3/ticker/24hr", params={"symbol": f"{symbol.upper()}USDT"})
        return {"usd": parse_number(data["lastPrice"]), "change": parse_number(data["priceChangePercent"])}


_shared: IranRates | None = None


def shared() -> IranRates:
    global _shared
    if _shared is None:
        _shared = IranRates()
    return _shared
