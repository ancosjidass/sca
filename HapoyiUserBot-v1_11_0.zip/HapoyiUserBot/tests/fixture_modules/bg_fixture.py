import asyncio


def setup(client, db):
    """A module with a background loop, like scheduler/alerts: it must die with its account."""
    client.ticks = 0

    async def loop():
        while True:
            client.ticks += 1
            await asyncio.sleep(0.01)

    asyncio.create_task(loop())
