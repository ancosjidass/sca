def setup(client, db):
    @client.on(None)
    async def handler(event):
        pass
