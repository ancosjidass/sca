from modules.personal import safe_calc


def test_calc():
    assert safe_calc('2+3*4') == 14
    assert safe_calc('(10-2)/4') == 2
