from providers.crypto import MarketProvider


def test_crypto_resolution():
    p = MarketProvider()
    assert p.resolve('bitcoin') == 'bitcoin'
    assert p.resolve('بیت کوین') == 'bitcoin'
    assert p.resolve('solana') == 'solana'
    assert p.resolve('unknown') is None
