import asyncio
from pathlib import Path

from core.database import Database


def test_database_roundtrip(tmp_path: Path):
    async def run():
        db = Database(tmp_path / 'x.db')
        await db.connect()
        await db.set_kv('x', {'a': 1})
        assert await db.get_kv('x') == {'a': 1}
        await db.update_chat_settings(123, flood_enabled=True, flood_count=5)
        assert (await db.get_chat_settings(123))['flood_count'] == 5
        await db.close()
    asyncio.run(run())
