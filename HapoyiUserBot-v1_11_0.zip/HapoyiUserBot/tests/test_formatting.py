from utils.formatting import fmt_money, parse_duration


def test_money():
    assert fmt_money(1234567.89) == '1,234,567.89'


def test_duration():
    assert parse_duration('5m') == 300
    assert parse_duration('2h') == 7200
