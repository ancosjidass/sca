from core.parser import CommandParser


def test_parser_command():
    p = CommandParser('.')
    c = p.parse('.ban @amir')
    assert c and c.name == 'ban' and c.args == ['@amir']


def test_non_command():
    assert CommandParser('.').parse('hello') is None
