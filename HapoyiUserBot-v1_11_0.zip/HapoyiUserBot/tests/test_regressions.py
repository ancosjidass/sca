"""Regression tests for the 1.6.1 bug-fix release (group commands, owner-only, AFK)."""
from __future__ import annotations

import ast
import asyncio
import importlib
import os
import pathlib
import re
import sys
import tempfile
from types import SimpleNamespace

import pytest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from telethon import events  # noqa: E402
from telethon.errors import ChatAdminRequiredError  # noqa: E402
from telethon.tl.types import InputPeerChannel, InputPeerUser  # noqa: E402

from core.database import Database  # noqa: E402
from core.guard import install_handler_guard  # noqa: E402
from utils.rights import ban_rights, mute_rights, open_rights  # noqa: E402


# ----------------------------------------------------------------- static guards
def _modules():
    return [p for p in (ROOT / "modules").glob("*.py") if not p.name.startswith("_")]


def test_every_command_handler_is_outgoing_only():
    """A command (NewMessage with pattern=) must never be reachable by other people."""
    offenders = []
    for path in _modules() + [ROOT / "core" / "bootstrap.py"]:
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "NewMessage":
                kw = {k.arg: k.value for k in node.keywords}
                if "pattern" in kw:
                    out = kw.get("outgoing")
                    if not (isinstance(out, ast.Constant) and out.value is True):
                        offenders.append(f"{path.name}:{node.lineno}")
    assert not offenders, offenders


def test_no_always_true_owner_filter():
    assert "not e.out or e.out" not in (ROOT / "utils" / "command.py").read_text()


def test_chatbannedrights_never_built_without_until_date():
    """ChatBannedRights(until_date, ...) needs until_date; building it without crashed admin.py at import."""
    bad = []
    for path in _modules():
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and getattr(node.func, "id", "") == "ChatBannedRights":
                bad.append(f"{path.name}:{node.lineno}")
    assert not bad, bad


def test_all_modules_import_and_setup():
    class Fake:
        def __init__(self):
            self.n = 0

        def on(self, ev):
            def deco(fn):
                self.n += 1
                return fn
            return deco

    async def run():
        db = Database(tempfile.mktemp())
        await db.connect()
        for p in _modules():
            m = importlib.import_module(f"modules.{p.stem}")
            setup = getattr(m, "setup", None)
            if setup:
                r = setup(Fake(), db)
                if hasattr(r, "__await__"):
                    await r
        await db.close()

    asyncio.run(run())


def test_admin_module_registers_moderation_commands():
    class Fake:
        def __init__(self):
            self.names = []

        def on(self, ev):
            def deco(fn):
                self.names.append(fn.__name__)
                return fn
            return deco

    from modules import admin

    f = Fake()
    admin.setup(f, None)
    assert {"ban", "unban", "kick", "mute", "unmute", "pin", "unpin", "purge", "delete", "admins"} <= set(f.names)


# ----------------------------------------------------------------- rights
def test_rights_helpers():
    assert ban_rights().view_messages is True
    assert mute_rights(60).send_messages is True and mute_rights(60).until_date is not None
    assert mute_rights().until_date is None
    r = open_rights()
    assert not r.view_messages and not r.send_messages


def test_has_rights_reads_participant_properties():
    from core.permissions import has_rights

    admin_ok = SimpleNamespace(is_creator=False, is_admin=True, ban_users=True, delete_messages=False)
    assert has_rights(admin_ok, "ban_users")
    assert not has_rights(admin_ok, "delete_messages")
    assert has_rights(SimpleNamespace(is_creator=True, is_admin=True), "ban_users")
    assert not has_rights(SimpleNamespace(is_creator=False, is_admin=False, ban_users=True), "ban_users")
    assert not has_rights(None, "ban_users")


# ----------------------------------------------------------------- fake telethon plumbing
class FakeMessage:
    def __init__(self, text, out, sender_id, mid=1, reply_to=None):
        self.message = text
        self.out = out
        self.sender_id = sender_id
        self.id = mid
        self.reply_to = reply_to
        self.fwd_from = None


class FakeClient:
    """Just enough of TelegramClient to drive handlers."""

    def __init__(self, me=100, perms=None):
        self.handlers = []
        self.me = me
        self.calls = []
        self.perms = perms
        self._hapoyi_me_id = me

    def on(self, builder=None):
        def decorator(fn):
            self.handlers.append((builder, fn))
            return fn
        return decorator

    async def get_permissions(self, chat, user):
        if user == "me":
            return self.perms
        return SimpleNamespace(is_admin=False, is_creator=False)

    async def get_entity(self, ref):
        return SimpleNamespace(id=555, username="bob", first_name="Bob", last_name=None)

    async def get_input_entity(self, x):
        if isinstance(x, int) and x < 0:
            return InputPeerChannel(1, 1)
        return InputPeerUser(getattr(x, "id", x), 1)

    async def __call__(self, request):
        self.calls.append(request)
        if getattr(self, "fail_with", None):
            raise self.fail_with
        return True

    def is_connected(self):
        return True

    async def send_message(self, *a, **k):
        self.calls.append(("send", a, k))
        return SimpleNamespace(id=900 + len(self.calls))


class FakeEvent:
    def __init__(self, client, text, *, out=True, sender_id=100, private=False, group=True, reply_user=None, chat_id=-1001):
        self.client = client
        self.message = FakeMessage(text, out, sender_id, reply_to=SimpleNamespace(reply_to_msg_id=5, forum_topic=False, reply_to_top_id=None) if reply_user else None)
        self.out = out
        self.sender_id = sender_id
        self.raw_text = text
        self.is_private = private
        self.is_group = group
        self.chat_id = chat_id
        self.id = 9
        self.is_reply = reply_user is not None
        self._reply_user = reply_user
        self.replies = []
        self.pattern_match = None
        self.reply_to_msg_id = 5 if reply_user is not None else None
        self.deleted = False

    async def reply(self, text, **kw):
        self.replies.append(text)

    async def delete(self):
        self.deleted = True

    async def get_reply_message(self):
        user = self._reply_user
        return SimpleNamespace(id=5, sender_id=user.id, get_sender=_async(user))

    async def get_input_chat(self):
        return InputPeerChannel(1, 1)

    async def get_sender(self):
        return SimpleNamespace(id=self.sender_id, bot=False, deleted=False, first_name="X")


def _async(value):
    async def f():
        return value
    return f


def _find(client, name):
    for b, fn in client.handlers:
        if fn.__name__ == name:
            return b, fn
    raise KeyError(name)


async def _dispatch(client, name, event):
    builder, fn = _find(client, name)
    builder.resolved = True  # normally done by client.start(); the filter ignores unresolved builders
    probe = SimpleNamespace(message=event.message)
    if builder.filter(probe) is None:
        return False
    event.pattern_match = probe.pattern_match
    await fn(event)
    return True


ADMIN = SimpleNamespace(is_creator=False, is_admin=True, ban_users=True, delete_messages=True, pin_messages=True)
OWNER = SimpleNamespace(is_creator=True, is_admin=True, ban_users=True, delete_messages=True, pin_messages=True)
PLAIN = SimpleNamespace(is_creator=False, is_admin=False, ban_users=False)


def _setup_admin(client):
    from modules import admin

    install_handler_guard(client)
    admin.setup(client, None)


def test_mute_works_for_owner_and_replies_success():
    async def run():
        c = FakeClient(perms=OWNER)
        _setup_admin(c)
        ev = FakeEvent(c, ".mute", reply_user=SimpleNamespace(id=555, username="bob"))
        assert await _dispatch(c, "mute", ev)
        assert ev.replies and "mute شد" in ev.replies[0] and "با موفقیت" in ev.replies[0]
        assert len(c.calls) == 1 and c.calls[0].banned_rights.send_messages

    asyncio.run(run())


def test_mute_duration_only_argument_is_not_a_username():
    async def run():
        c = FakeClient(perms=ADMIN)
        _setup_admin(c)
        ev = FakeEvent(c, ".mute 10m", reply_user=SimpleNamespace(id=555, username="bob"))
        assert await _dispatch(c, "mute", ev)
        assert "10m" in ev.replies[0] and c.calls[0].banned_rights.until_date is not None

    asyncio.run(run())


def test_mute_under_30_seconds_is_refused_instead_of_becoming_permanent():
    async def run():
        c = FakeClient(perms=ADMIN)
        _setup_admin(c)
        ev = FakeEvent(c, ".mute 10s", reply_user=SimpleNamespace(id=555, username="bob"))
        await _dispatch(c, "mute", ev)
        assert "30" in ev.replies[0] and not c.calls

    asyncio.run(run())


def test_no_rights_gives_clear_failure_message():
    async def run():
        c = FakeClient(perms=PLAIN)
        _setup_admin(c)
        ev = FakeEvent(c, ".ban", reply_user=SimpleNamespace(id=555, username="bob"))
        await _dispatch(c, "ban", ev)
        assert ev.replies and ev.replies[0].startswith("❌") and "ادمین" in ev.replies[0]
        assert not c.calls

    asyncio.run(run())


def test_telegram_rpc_error_is_reported_not_swallowed():
    async def run():
        c = FakeClient(perms=ADMIN)
        c.fail_with = ChatAdminRequiredError(request=None)
        _setup_admin(c)
        ev = FakeEvent(c, ".ban @bob", reply_user=SimpleNamespace(id=555, username="bob"))
        await _dispatch(c, "ban", ev)
        assert ev.replies and "❌" in ev.replies[0] and "بن نشد" in ev.replies[0]

    asyncio.run(run())


def test_cannot_target_self_or_admin():
    async def run():
        c = FakeClient(perms=OWNER)
        _setup_admin(c)
        ev = FakeEvent(c, ".mute", reply_user=SimpleNamespace(id=100, username="me"))
        await _dispatch(c, "mute", ev)
        assert "خودت" in ev.replies[0] and not c.calls

    asyncio.run(run())


def test_other_people_cannot_run_commands():
    """The original bug: someone else typing .mute/.ban made the account act."""
    async def run():
        c = FakeClient(perms=OWNER)
        _setup_admin(c)
        stranger = FakeEvent(c, ".mute", out=False, sender_id=777, reply_user=SimpleNamespace(id=555, username="bob"))
        for name in ("ban", "mute", "kick", "purge", "delete"):
            assert not await _dispatch(c, name, stranger)
        assert not c.calls and not stranger.replies

    asyncio.run(run())


def test_guard_blocks_even_a_handler_registered_without_outgoing():
    async def run():
        c = FakeClient()
        install_handler_guard(c)
        hit = []

        @c.on(events.NewMessage(pattern=r"^\.x$"))
        async def x(event):
            hit.append(1)

        _, fn = _find(c, "x")
        await fn(FakeEvent(c, ".x", out=False, sender_id=7))
        assert not hit
        await fn(FakeEvent(c, ".x", out=True))
        assert hit == [1]

    asyncio.run(run())


def test_guard_reports_unexpected_errors_to_owner():
    async def run():
        c = FakeClient()
        install_handler_guard(c)

        @c.on(events.NewMessage(outgoing=True, pattern=r"^\.boom$"))
        async def boom(event):
            raise RuntimeError("kaput")

        _, fn = _find(c, "boom")
        ev = FakeEvent(c, ".boom")
        await fn(ev)
        assert ev.replies and ev.replies[0].startswith("❌")

    asyncio.run(run())


# ----------------------------------------------------------------- AFK
def _setup_personal(db, c):
    from modules import personal

    install_handler_guard(c)
    personal.setup(c, db)


async def _afk_env():
    db = Database(tempfile.mktemp())
    await db.connect()
    c = FakeClient(me=100)

    async def get_me():
        return SimpleNamespace(id=100, first_name="Amir", last_name=None, username="amir")

    c.get_me = get_me
    c._hapoyi_me_id = None
    _setup_personal(db, c)
    return db, c


def test_afk_replies_only_in_private_and_only_once_per_person():
    async def run():
        db, c = await _afk_env()
        on = FakeEvent(c, ".afk رفتم بیرون")
        await _dispatch(c, "afk", on)
        assert "AFK فعال شد" in on.replies[0]

        _, replier = _find(c, "afk_replier")

        # group message -> no announcement
        g = FakeEvent(c, "سلام", out=False, sender_id=7, group=True, private=False)
        await replier(g)
        assert not g.replies

        # private: first message -> one notice
        p1 = FakeEvent(c, "سلام", out=False, sender_id=7, group=False, private=True)
        await replier(p1)
        assert len(p1.replies) == 1 and "رفتم بیرون" in p1.replies[0] and "Amir" in p1.replies[0]

        # same person writes again -> NO second notice
        p2 = FakeEvent(c, "هستی؟", out=False, sender_id=7, group=False, private=True)
        await replier(p2)
        assert not p2.replies

        # a different person -> own notice
        p3 = FakeEvent(c, "hi", out=False, sender_id=8, group=False, private=True)
        await replier(p3)
        assert len(p3.replies) == 1

        # new AFK session -> person 7 may be told again, exactly once
        await _dispatch(c, "afk", FakeEvent(c, ".afk دوباره"))
        p4 = FakeEvent(c, "yo", out=False, sender_id=7, group=False, private=True)
        await replier(p4)
        p5 = FakeEvent(c, "yo2", out=False, sender_id=7, group=False, private=True)
        await replier(p5)
        assert len(p4.replies) == 1 and not p5.replies

        # .back -> silent again
        await _dispatch(c, "back", FakeEvent(c, ".back"))
        p6 = FakeEvent(c, "yo3", out=False, sender_id=9, group=False, private=True)
        await replier(p6)
        assert not p6.replies

    asyncio.run(run())


def test_afk_ignores_bots_service_and_own_messages():
    async def run():
        db, c = await _afk_env()
        await _dispatch(c, "afk", FakeEvent(c, ".afk x"))
        _, replier = _find(c, "afk_replier")

        tg = FakeEvent(c, "code 12345", out=False, sender_id=777000, private=True, group=False)
        await replier(tg)
        own = FakeEvent(c, "note to self", out=True, sender_id=100, private=True, group=False)
        await replier(own)

        bot = FakeEvent(c, "hello", out=False, sender_id=55, private=True, group=False)

        async def get_sender():
            return SimpleNamespace(id=55, bot=True, deleted=False)

        bot.get_sender = get_sender
        await replier(bot)
        assert not (tg.replies or own.replies or bot.replies)

    asyncio.run(run())


def test_afk_retries_if_notice_could_not_be_sent():
    async def run():
        db, c = await _afk_env()
        await _dispatch(c, "afk", FakeEvent(c, ".afk x"))
        _, replier = _find(c, "afk_replier")

        failing = FakeEvent(c, "hi", out=False, sender_id=7, private=True, group=False)

        async def bad_reply(text, **kw):
            raise RuntimeError("flood")

        failing.reply = bad_reply
        await replier(failing)
        ok = FakeEvent(c, "hi again", out=False, sender_id=7, private=True, group=False)
        await replier(ok)
        assert len(ok.replies) == 1

    asyncio.run(run())


def test_other_people_cannot_toggle_afk():
    async def run():
        db, c = await _afk_env()
        assert not await _dispatch(c, "afk", FakeEvent(c, ".afk spam", out=False, sender_id=7, private=True, group=False))
        row = await db.fetchone("SELECT 1 FROM afk WHERE enabled=1")
        assert row is None

    asyncio.run(run())
