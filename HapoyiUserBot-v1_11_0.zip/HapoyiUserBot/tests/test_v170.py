"""Tests for the 1.7.0 features (prices, relations, autoreact, first-comment, clock, clone, casino reply)."""
from __future__ import annotations

import asyncio
import sys
import tempfile
import pathlib
from datetime import datetime
from types import SimpleNamespace

import pytest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from core.database import Database  # noqa: E402
from core.guard import install_handler_guard  # noqa: E402
from core.permissions import reply_to_id  # noqa: E402
from providers.iran import IranRates, RateUnavailable, parse_number  # noqa: E402
from tests.test_regressions import FakeClient, FakeEvent, _async, _dispatch, _find  # noqa: E402


# ------------------------------------------------------------------ prices
def test_parse_number_variants():
    assert parse_number("1,234,500") == 1234500
    assert parse_number("۲۷۰٬۰۰۰") == 270000
    assert parse_number(5) == 5.0
    with pytest.raises(ValueError):
        parse_number("—")


def _rates(payloads):
    async def fetch(url, **kw):
        for key, val in payloads.items():
            if key in url:
                if isinstance(val, Exception):
                    raise val
                return val
        raise RuntimeError("blocked: " + url)

    return IranRates(fetch_json=fetch, cache_seconds=0)


TGJU = {"current": {"price_dollar_rl": {"p": "2,700,000"}, "price_eur": {"p": "3,100,000"}}}
NOBITEX_USDT = {"status": "ok", "stats": {"usdt-rls": {"latest": "2705000", "dayChange": "0.1"}}}
WALLEX = {"result": {"symbols": {"USDTTMN": {"stats": {"lastPrice": "270400"}}}}}


def test_usd_is_real_market_rate_in_toman_not_reference_rate():
    async def run():
        r = _rates({"tgju": TGJU, "nobitex": NOBITEX_USDT, "wallex": WALLEX})
        usd = await r.usd_toman()
        assert usd.source == "TGJU" and usd.toman == 270_000  # Rial -> Toman
        eur = await r.eur_toman()
        assert eur.toman == 310_000

    asyncio.run(run())


def test_falls_back_when_primary_down_and_never_invents_a_number():
    async def run():
        r = _rates({"tgju": RuntimeError("403"), "nobitex": NOBITEX_USDT, "wallex": WALLEX})
        usd = await r.usd_toman()
        assert usd.source == "Nobitex" and usd.toman == 270_500
        dead = _rates({"tgju": RuntimeError("x"), "nobitex": RuntimeError("x"), "wallex": RuntimeError("x")})
        with pytest.raises(RateUnavailable):
            await dead.usd_toman()

    asyncio.run(run())


def test_implausible_value_is_rejected():
    """The old bug: a dollar shown as 133 Toman. Anything absurd must be treated as a failure."""
    async def run():
        bad = {"current": {"price_dollar_rl": {"p": "1,330"}}}
        r = _rates({"tgju": bad, "nobitex": RuntimeError("x"), "wallex": RuntimeError("x")})
        with pytest.raises(RateUnavailable):
            await r.usd_toman()

    asyncio.run(run())


def test_disagreeing_sources_are_flagged():
    async def run():
        wallex = {"result": {"symbols": {"USDTTMN": {"stats": {"lastPrice": "320000"}}}}}
        r = _rates({"tgju": TGJU, "nobitex": NOBITEX_USDT, "wallex": wallex})
        assert "اختلاف" in (await r.usd_toman()).note

    asyncio.run(run())


def test_crypto_from_nobitex_has_usd_toman_and_change():
    async def run():
        stats = {"status": "ok", "stats": {
            "btc-usdt": {"latest": "67000.5", "dayChange": "-1.25"},
            "btc-rls": {"latest": "181000000000", "dayChange": "-1.2"},
        }}
        r = _rates({"nobitex": stats})
        out = await r.nobitex_coins(["BTC"])
        assert out["BTC"]["usd"] == 67000.5
        assert out["BTC"]["toman"] == 18_100_000_000  # Rial/10
        assert out["BTC"]["change"] == -1.25

    asyncio.run(run())


def test_market_provider_uses_nobitex_first():
    from providers.crypto import MarketProvider

    async def run():
        stats = {"stats": {"eth-usdt": {"latest": "3000", "dayChange": "2"}, "eth-rls": {"latest": "8100000000"}}}
        mp = MarketProvider(cache_seconds=0, rates=_rates({"nobitex": stats}))
        q = await mp.quote("eth")
        assert q.source == "Nobitex" and q.usd == 3000 and q.toman == 810_000_000 and q.change_24h == 2

    asyncio.run(run())


# ------------------------------------------------------------------ reply targets
def test_reply_to_id():
    plain = SimpleNamespace(message=SimpleNamespace(reply_to=None))
    assert reply_to_id(plain) is None
    rep = SimpleNamespace(message=SimpleNamespace(reply_to=SimpleNamespace(reply_to_msg_id=77)))
    assert reply_to_id(rep) == 77


# ------------------------------------------------------------------ relations
async def _rel_env():
    db = Database(tempfile.mktemp())
    await db.connect()
    c = FakeClient(me=100)

    async def get_me():
        return SimpleNamespace(id=100, first_name="Me", last_name="L", username="me", premium=False)

    c.get_me = get_me
    c._hapoyi_me_id = None
    install_handler_guard(c)
    from modules import relations

    relations.setup(c, db)
    return db, c


def test_friend_add_and_off_work_with_reply_only():
    async def run():
        db, c = await _rel_env()
        bob = SimpleNamespace(id=555, username="bob", first_name="Bob", last_name=None)
        ev = FakeEvent(c, ".friend add", reply_user=bob)
        assert await _dispatch(c, "friend_cmd", ev)
        assert "اضافه شد" in ev.replies[0]
        assert (await db.fetchone("SELECT kind FROM relations WHERE user_id=555"))["kind"] == "friend"
        off = FakeEvent(c, ".friend off", reply_user=bob)
        await _dispatch(c, "friend_cmd", off)
        assert (await db.fetchone("SELECT enabled FROM relations WHERE user_id=555"))["enabled"] == 0
        delete = FakeEvent(c, ".friend del", reply_user=bob)
        await _dispatch(c, "friend_cmd", delete)
        assert await db.fetchone("SELECT 1 FROM relations WHERE user_id=555") is None

    asyncio.run(run())


def test_responder_replies_to_the_senders_message():
    async def run():
        db, c = await _rel_env()
        bob = SimpleNamespace(id=555, username="bob", first_name="Bob", last_name=None)
        await _dispatch(c, "enemy_cmd", FakeEvent(c, ".enemy add", reply_user=bob))
        _, responder = _find(c, "relation_responder")
        msg = FakeEvent(c, "سلام", out=False, sender_id=555, group=True)
        await responder(msg)
        assert len(msg.replies) == 1  # went through event.reply -> reply_to=their message
        again = FakeEvent(c, "باز؟", out=False, sender_id=555, group=True)
        await responder(again)
        assert not again.replies  # cooldown

    asyncio.run(run())


def test_clear_really_clears_and_stays_empty():
    async def run():
        db, c = await _rel_env()
        bob = SimpleNamespace(id=555, username="bob", first_name="Bob", last_name=None)
        await _dispatch(c, "friend_cmd", FakeEvent(c, ".friend add", reply_user=bob))
        clear = FakeEvent(c, ".relation clear friend")
        await _dispatch(c, "relation_tools", clear)
        assert (await db.fetchone("SELECT COUNT(*) n FROM relation_replies WHERE kind='friend'"))["n"] == 0
        # a later command/message must NOT re-seed the defaults
        _, responder = _find(c, "relation_responder")
        msg = FakeEvent(c, "hi", out=False, sender_id=555)
        await responder(msg)
        assert not msg.replies
        assert (await db.fetchone("SELECT COUNT(*) n FROM relation_replies WHERE kind='friend'"))["n"] == 0
        # custom pool works, reset restores defaults
        await _dispatch(c, "friend_reply_add", FakeEvent(c, ".friend reply فقط این"))
        assert (await db.fetchone("SELECT COUNT(*) n FROM relation_replies WHERE kind='friend'"))["n"] == 1
        await _dispatch(c, "relation_tools", FakeEvent(c, ".relation reset friend"))
        assert (await db.fetchone("SELECT COUNT(*) n FROM relation_replies WHERE kind='friend'"))["n"] > 5

    asyncio.run(run())


# ------------------------------------------------------------------ autoreact
def test_autoreact_per_user_per_chat():
    async def run():
        import modules.automation as automation
        sent = []

        async def fake_send(client, chat, msg_id, emoji):
            sent.append((chat, msg_id, emoji))

        automation.send_reaction = fake_send
        db = Database(tempfile.mktemp())
        await db.connect()
        c = FakeClient(me=100)
        c._hapoyi_me_id = 100
        install_handler_guard(c)
        automation.setup(c, db)
        ali = SimpleNamespace(id=7, username="ali", first_name="Ali", last_name=None)

        mafia, cityland = -1001, -1002
        ev = FakeEvent(c, ".autoreact 🤣", reply_user=ali, chat_id=mafia)
        assert await _dispatch(c, "autoreact_cmd", ev)
        assert "روشن شد" in ev.replies[0]

        _, handler = _find(c, "autoreact_handler")
        await handler(FakeEvent(c, "x", out=False, sender_id=7, chat_id=mafia))      # Ali in mafia -> react
        await handler(FakeEvent(c, "x", out=False, sender_id=8, chat_id=mafia))      # someone else -> no
        await handler(FakeEvent(c, "x", out=False, sender_id=7, chat_id=cityland))   # Ali elsewhere -> no
        assert [(s[0], s[2]) for s in sent if s[0] == mafia] == [(mafia, "🤣")] * 2 or len([s for s in sent if s[0] == mafia]) >= 1
        reacted = [(s[0]) for s in sent]
        assert reacted.count(cityland) == 0
        before = len(sent)

        off = FakeEvent(c, ".autoreact off", reply_user=ali, chat_id=mafia)
        await _dispatch(c, "autoreact_cmd", off)
        await handler(FakeEvent(c, "x", out=False, sender_id=7, chat_id=mafia))
        assert len(sent) == before  # switched off for him
        on = FakeEvent(c, ".autoreact on", reply_user=ali, chat_id=mafia)
        await _dispatch(c, "autoreact_cmd", on)
        await handler(FakeEvent(c, "x", out=False, sender_id=7, chat_id=mafia))
        assert len(sent) == before + 1

    asyncio.run(run())


def test_autoreact_rejects_non_emoji():
    async def run():
        import modules.automation as automation
        db = Database(tempfile.mktemp())
        await db.connect()
        c = FakeClient(me=100)
        c._hapoyi_me_id = 100
        install_handler_guard(c)
        automation.setup(c, db)
        ev = FakeEvent(c, ".autoreact hello")
        await _dispatch(c, "autoreact_cmd", ev)
        assert "ایموجی" in ev.replies[0]

    asyncio.run(run())


# ------------------------------------------------------------------ first comment
def test_first_comment_enable_and_post_once_per_album():
    async def run():
        import modules.channel as channel
        db = Database(tempfile.mktemp())
        await db.connect()
        c = FakeClient(me=100)
        c._hapoyi_me_id = 100
        posted = []

        async def send_message(chat, text, **kw):
            posted.append((chat, text, kw.get("comment_to")))

        c.send_message = send_message
        from telethon import types as tl_types
        from datetime import timezone
        chan = tl_types.Channel(id=1234, title="News", photo=tl_types.ChatPhotoEmpty(), date=datetime.now(timezone.utc), broadcast=True, access_hash=1)

        async def get_entity(ref):
            return chan

        c.get_entity = get_entity
        install_handler_guard(c)
        channel.setup(c, db)

        ev = FakeEvent(c, ".comment first @news اول!", out=True)
        assert await _dispatch(c, "comment_first_cmd", ev)
        assert "فعال شد" in ev.replies[0]
        # the plain .comment command must NOT swallow "first"
        plain = FakeEvent(c, ".comment first @news اول!", out=True)
        from telethon import events
        b, _ = _find(c, "comment")
        b.resolved = True
        assert b.filter(SimpleNamespace(message=plain.message)) is None

        from telethon import utils
        cid = utils.get_peer_id(chan)
        _, watcher = _find(c, "first_comment_watcher")
        post = FakeEvent(c, "new post", out=False, chat_id=cid)
        post.message.post = True
        post.message.grouped_id = None
        await watcher(post)
        assert posted and posted[0][1] == "اول!"
        # album: 3 messages, 1 comment
        posted.clear()
        for i in range(3):
            m = FakeEvent(c, "", out=False, chat_id=cid)
            m.message.post = True
            m.message.grouped_id = 999
            await watcher(m)
        assert len(posted) == 1
        # other channel: nothing
        other = FakeEvent(c, "x", out=False, chat_id=-100999)
        other.message.post = True
        other.message.grouped_id = None
        posted.clear()
        await watcher(other)
        assert not posted
        off = FakeEvent(c, ".comment first off @news")
        await _dispatch(c, "comment_first_cmd", off)
        post2 = FakeEvent(c, "p2", out=False, chat_id=cid)
        post2.message.post = True
        post2.message.grouped_id = None
        await watcher(post2)
        assert not posted

    asyncio.run(run())


# ------------------------------------------------------------------ profile clock
def test_clock_format_and_last_name():
    from modules.profile import build_last_name, format_clock

    now = datetime(2026, 10, 4, 8, 36)
    assert format_clock(now, "fa") == "۸:۳۶" and format_clock(now, "en") == "8:36"
    assert format_clock(datetime(2026, 1, 1, 20, 5), "en") == "20:05"
    assert build_last_name("", "۸:۳۶") == "۸:۳۶"
    assert build_last_name("Amiri", "۸:۳۷") == "Amiri ۸:۳۷"
    assert len(build_last_name("x" * 200, "۸:۳۷")) <= 64


def test_clock_updates_last_name_each_minute_and_restores():
    async def run():
        import modules.profile as profile
        db = Database(tempfile.mktemp())
        await db.connect()
        calls = []
        c = FakeClient(me=100)

        async def get_me():
            return SimpleNamespace(id=100, first_name="Me", last_name="Amiri 08:30", username="me")

        c.get_me = get_me

        async def call(req):
            calls.append(req)
            return SimpleNamespace(full_user=SimpleNamespace(about="my bio"))

        c.__class__ = type("C2", (FakeClient,), {"__call__": lambda self, req: call(req)})
        c._hapoyi_me_id = 100
        install_handler_guard(c)
        profile.setup(c, db)
        on = FakeEvent(c, ".profileclock name on")
        assert await _dispatch(c, "profile_clock", on)
        assert "روشن شد" in on.replies[0]
        sets = [r for r in calls if r.__class__.__name__ == "UpdateProfileRequest"]
        assert sets and sets[-1].last_name.startswith("Amiri ") and ":" in sets[-1].last_name
        assert "08:30" not in sets[-1].last_name  # stale leftover clock removed from the base
        off = FakeEvent(c, ".profileclock name off")
        await _dispatch(c, "profile_clock", off)
        last = [r for r in calls if r.__class__.__name__ == "UpdateProfileRequest"][-1]
        assert last.last_name == "Amiri"

    asyncio.run(run())


# ------------------------------------------------------------------ clone
def test_clone_username_candidates():
    from itertools import islice
    from modules.clone import username_candidates

    assert list(islice(username_candidates("mol"), 3)) == ["mol_baraman", "mol10", "mol11"]
    assert list(islice(username_candidates(None), 3)) == ["baraman", "baraman1", "baraman2"]
    assert all(c[0].isalpha() and 5 <= len(c) <= 32 for c in islice(username_candidates("x"), 10))


def test_clone_refuses_self_and_unclone_without_backup():
    async def run():
        import modules.clone as clone
        db = Database(tempfile.mktemp())
        await db.connect()
        c = FakeClient(me=100)

        async def get_me():
            return SimpleNamespace(id=100, first_name="Me", last_name=None, username="me", premium=False)

        c.get_me = get_me
        c._hapoyi_me_id = 100
        install_handler_guard(c)
        clone.setup(c, db)
        me_user = SimpleNamespace(id=100, username="me", first_name="Me", last_name=None)
        # not a telethon User -> refused gracefully
        ev = FakeEvent(c, ".clone", reply_user=me_user)
        await _dispatch(c, "clone", ev)
        assert ev.replies and ev.replies[0].startswith("❌")
        ev2 = FakeEvent(c, ".unclone")
        await _dispatch(c, "unclone", ev2)
        assert "کلون فعالی" in ev2.replies[0]

    asyncio.run(run())


def test_navasan_optional_source(monkeypatch):
    async def run():
        monkeypatch.setenv("NAVASAN_API_KEY", "k")
        payload = {"usd_sell": {"value": "270500", "change": -100}, "eur_sell": {"value": "311000"}}
        r = _rates({"navasan": payload, "tgju": RuntimeError("x"), "nobitex": RuntimeError("x"), "wallex": RuntimeError("x")})
        usd = await r.usd_toman()
        assert usd.source == "Navasan" and usd.toman == 270_500
        assert (await r.eur_toman()).toman == 311_000

    asyncio.run(run())
