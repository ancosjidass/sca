"""1.7.1: rights-based moderation (no 'is he an admin' pre-check), promote, lists, mesdel, selfdestruct, scopes."""
from __future__ import annotations

import asyncio
import json
import pathlib
import sys
import tempfile
import time
from types import SimpleNamespace

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from telethon.errors import UserAdminInvalidError  # noqa: E402
from telethon.tl.types import ChannelParticipantAdmin, ChannelParticipantCreator  # noqa: E402

from core.database import Database  # noqa: E402
from core.guard import install_handler_guard  # noqa: E402
from tests.test_regressions import ADMIN, OWNER, PLAIN, FakeClient, FakeEvent, _dispatch, _find  # noqa: E402

BOB = SimpleNamespace(id=555, username="bob", first_name="Bob", last_name=None)


def _admin_env(perms):
    from modules import admin

    c = FakeClient(perms=perms)
    install_handler_guard(c)
    admin.setup(c, None)
    return c


def test_ban_attempts_even_when_target_is_admin_and_reports_telegram_verdict():
    async def run():
        # target IS an admin; creator may still ban him -> the request must simply be sent
        c = _admin_env(OWNER)
        async def perms(chat, user):
            if user == "me":
                return OWNER
            return SimpleNamespace(is_admin=True, is_creator=False)
        c.get_permissions = perms
        ev = FakeEvent(c, ".ban", reply_user=BOB)
        await _dispatch(c, "ban", ev)
        assert c.calls and "بن شد" in ev.replies[0]

        # Telegram says no -> clear "no access higher than him" text
        c2 = _admin_env(ADMIN)
        c2.fail_with = UserAdminInvalidError(request=None)
        ev2 = FakeEvent(c2, ".mute", reply_user=BOB)
        await _dispatch(c2, "mute", ev2)
        assert "دسترسی بالاتر" in ev2.replies[0]

    asyncio.run(run())


def test_mute_users_is_the_list_command_not_a_target():
    async def run():
        c = _admin_env(ADMIN)
        ev = FakeEvent(c, ".mute users")
        assert not await _dispatch(c, "mute", ev)
        assert await _dispatch(c, "muted_users", FakeEvent(c, ".mute users"))
        assert await _dispatch(c, "banned_users", FakeEvent(c, ".banned users"))
        assert not await _dispatch(c, "ban", FakeEvent(c, ".banned users"))

    asyncio.run(run())


def _warn_env(my_perm, target_participant):
    from modules import moderation

    async def go():
        db = Database(tempfile.mktemp())
        await db.connect()
        c = FakeClient(perms=my_perm)

        async def get_permissions(chat, user):
            if user == "me":
                return my_perm
            return SimpleNamespace(is_admin=target_participant is not None, is_creator=False, participant=target_participant)

        c.get_permissions = get_permissions
        install_handler_guard(c)
        moderation.setup(c, db)
        return db, c

    return go()


def test_warn_requires_real_rights_and_ability_to_act_on_target():
    async def run():
        # 1) I am a plain member -> no warning is stored
        db, c = await _warn_env(PLAIN, None)
        ev = FakeEvent(c, ".warn spam", reply_user=BOB)
        await _dispatch(c, "warn", ev)
        assert "شما دسترسی ندارید" in ev.replies[0]
        assert await db.fetchone("SELECT 1 FROM warnings") is None

        # 2) I am admin but target is an admin I did not promote -> refused, nothing stored
        other_admin = ChannelParticipantAdmin(user_id=555, inviter_id=1, promoted_by=2, date=None, admin_rights=None, can_edit=False)
        db, c = await _warn_env(ADMIN, other_admin)
        ev = FakeEvent(c, ".warn", reply_user=BOB)
        await _dispatch(c, "warn", ev)
        assert "شما دسترسی ندارید" in ev.replies[0] and await db.fetchone("SELECT 1 FROM warnings") is None

        # 3) target is the creator -> refused
        boss = ChannelParticipantCreator(user_id=555, admin_rights=None)
        db, c = await _warn_env(ADMIN, boss)
        ev = FakeEvent(c, ".warn", reply_user=BOB)
        await _dispatch(c, "warn", ev)
        assert "شما دسترسی ندارید" in ev.replies[0]

        # 4) admin I CAN edit (promoted by me) -> warned like anybody else
        mine = ChannelParticipantAdmin(user_id=555, inviter_id=1, promoted_by=100, date=None, admin_rights=None, can_edit=True)
        db, c = await _warn_env(ADMIN, mine)
        ev = FakeEvent(c, ".warn rude", reply_user=BOB)
        await _dispatch(c, "warn", ev)
        assert "Warning 1/3" in ev.replies[0]

        # 5) normal member -> warned
        db, c = await _warn_env(ADMIN, None)
        ev = FakeEvent(c, ".warn rude", reply_user=BOB)
        await _dispatch(c, "warn", ev)
        assert "Warning 1/3" in ev.replies[0]

    asyncio.run(run())


def test_promote_gives_only_rights_the_account_has():
    async def run():
        limited = SimpleNamespace(is_creator=False, is_admin=True, add_admins=True, delete_messages=True, ban_users=False, pin_messages=True, invite_users=False)
        c = _admin_env(limited)
        got = {}

        async def edit_admin(chat, user, **kw):
            got.update(kw)

        c.edit_admin = edit_admin
        ev = FakeEvent(c, ".promote", reply_user=BOB)
        await _dispatch(c, "promote", ev)
        assert got == {"pin_messages": True, "delete_messages": True, "invite_users": False, "ban_users": False}
        assert "ادمین شد" in ev.replies[0] and "داده نشد" in ev.replies[0]

        full = _admin_env(OWNER)
        got2 = {}

        async def edit2(chat, user, **kw):
            got2.update(kw)

        full.edit_admin = edit2
        await _dispatch(full, "promote", FakeEvent(full, ".promote", reply_user=BOB))
        assert all(got2.values()) and set(got2) == {"pin_messages", "delete_messages", "invite_users", "ban_users"}

        # no Add Admins right -> clear refusal
        noadd = _admin_env(ADMIN)
        ev3 = FakeEvent(noadd, ".promote", reply_user=BOB)
        await _dispatch(noadd, "promote", ev3)
        assert "دسترسی" in ev3.replies[0] and "❌" in ev3.replies[0]

    asyncio.run(run())


def test_banned_and_muted_lists():
    async def run():
        from telethon.tl.types import ChatBannedRights

        c = _admin_env(ADMIN)
        muted = SimpleNamespace(id=1, first_name="M", last_name=None, username="m",
                                participant=SimpleNamespace(banned_rights=ChatBannedRights(until_date=None, send_messages=True)))
        banned_in_muted_filter = SimpleNamespace(id=2, first_name="B", last_name=None, username=None,
                                                 participant=SimpleNamespace(banned_rights=ChatBannedRights(until_date=None, view_messages=True)))

        async def iter_participants(chat, filter=None, limit=None):
            name = getattr(filter, "__name__", "")
            items = [SimpleNamespace(id=9, first_name="K", last_name=None, username="kicked")] if name == "ChannelParticipantsKicked" else [muted, banned_in_muted_filter]
            for it in items:
                yield it

        c.iter_participants = iter_participants
        ev = FakeEvent(c, ".mute users")
        await _dispatch(c, "muted_users", ev)
        assert "(1)" in ev.replies[0] and "دائمی" in ev.replies[0] and "(2)" not in ev.replies[0]
        ev2 = FakeEvent(c, ".banned users")
        await _dispatch(c, "banned_users", ev2)
        assert "kicked" in ev2.replies[0]

    asyncio.run(run())


def _lifecycle(db):
    from modules import message_lifecycle

    c = FakeClient(me=100)
    c._hapoyi_me_id = 100
    install_handler_guard(c)
    message_lifecycle.setup(c, db)
    return c


def test_mesdel_all_and_count():
    async def run():
        db = Database(tempfile.mktemp())
        await db.connect()
        c = _lifecycle(db)
        mine = list(range(1300, 1000, -1))  # 300 of my messages, newest first
        deleted = []

        async def iter_messages(chat, from_user=None, limit=None, **kw):
            for i, mid in enumerate(mine):
                if limit is not None and i >= limit:
                    return
                yield SimpleNamespace(id=mid)

        async def delete_messages(chat, ids, **kw):
            deleted.extend(ids)

        c.iter_messages, c.delete_messages = iter_messages, delete_messages
        ev = FakeEvent(c, ".mesdel 5")
        await _dispatch(c, "mesdel", ev)
        assert sorted(deleted) == sorted([1300, 1299, 1298, 1297, 1296, ev.id])  # 5 previous + the command

        deleted.clear()
        ev2 = FakeEvent(c, ".mesdel all")
        await _dispatch(c, "mesdel", ev2)
        assert len(deleted) == 301  # all 300 + command (batched by 100)

    asyncio.run(run())


def test_selfdestruct_add_list_cancel_now():
    async def run():
        db = Database(tempfile.mktemp())
        await db.connect()
        c = _lifecycle(db)
        removed = []

        async def delete_messages(chat, ids, **kw):
            removed.append(ids)

        c.delete_messages = delete_messages
        ev = FakeEvent(c, ".selfdestruct 10m سلام این پاک میشه")
        await _dispatch(c, "selfdestruct", ev)
        rows = await db.fetchall("SELECT id,run_at,kind FROM delete_jobs")
        assert len(rows) == 1 and rows[0]["kind"] == "selfdestruct" and 590 < rows[0]["run_at"] - time.time() <= 600

        lst = FakeEvent(c, ".selfdestruct list")
        await _dispatch(c, "selfdestruct", lst)
        assert "#" in lst.replies[0] and "سلام" in lst.replies[0]

        job = rows[0]["id"]
        cancel = FakeEvent(c, f".selfdestruct del {job}")
        await _dispatch(c, "selfdestruct", cancel)
        assert await db.fetchone("SELECT 1 FROM delete_jobs") is None and not removed

        await _dispatch(c, "selfdestruct", FakeEvent(c, ".selfdestruct 1h دوباره"))
        await _dispatch(c, "selfdestruct", FakeEvent(c, ".selfdestruct now all"))
        assert removed and await db.fetchone("SELECT 1 FROM delete_jobs") is None

        bad = FakeEvent(c, ".selfdestruct")
        await _dispatch(c, "selfdestruct", bad)
        assert "SelfDestruct" in bad.replies[0]

    asyncio.run(run())


def test_due_jobs_are_executed_by_the_worker():
    async def run():
        db = Database(tempfile.mktemp())
        await db.connect()
        c = _lifecycle(db)
        removed = []

        async def delete_messages(chat, ids, **kw):
            removed.append((chat, ids))

        c.delete_messages = delete_messages
        await db.execute("INSERT INTO delete_jobs(chat_id,message_ids,run_at,kind,preview,created_at) VALUES(?,?,?,?,?,?)",
                         (-1001, json.dumps([7, 8]), time.time() - 1, "selfdestruct", "x", "now"))
        await asyncio.sleep(1.6)
        assert removed == [(-1001, [7, 8])]
        assert await db.fetchone("SELECT 1 FROM delete_jobs") is None

    asyncio.run(run())


def test_filter_and_linkguard_scope_normal_vs_all():
    async def run():
        from modules import security

        db = Database(tempfile.mktemp())
        await db.connect()
        c = FakeClient(perms=ADMIN)

        async def get_permissions(chat, user):
            if user == "me":
                return ADMIN
            return SimpleNamespace(is_admin=True, is_creator=False)  # the author is an admin

        c.get_permissions = get_permissions
        install_handler_guard(c)
        security.setup(c, db)
        await _dispatch(c, "filter_cmd", FakeEvent(c, ".filter add badword"))

        _, handler = _find(c, "filter_handler")
        msg = FakeEvent(c, "this has BADWORD inside", out=False, sender_id=77)
        await handler(msg)
        assert not msg.deleted  # scope normal (default): admins are exempt

        sc = FakeEvent(c, ".filter scope all")
        assert await _dispatch(c, "filter_scope_cmd", sc)
        msg2 = FakeEvent(c, "this has BADWORD inside", out=False, sender_id=77)
        await handler(msg2)
        assert msg2.deleted  # scope all: even admins

    asyncio.run(run())


def test_gif_and_sticker_commands_registered():
    class Fake:
        def __init__(self):
            self.names = []

        def on(self, ev):
            def deco(fn):
                self.names.append(fn.__name__)
                return fn
            return deco

    from modules import media

    f = Fake()
    media.setup(f, None)
    assert {"gif", "sticker"} <= set(f.names)
