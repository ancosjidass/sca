"""1.8.0: repeat jobs (.every/.time), .tag, and the ten extra tools."""
from __future__ import annotations

import asyncio
import json
import os
import pathlib
import sys
import tempfile
import time
from collections import Counter
from datetime import datetime, timezone
from types import SimpleNamespace

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from telethon import types  # noqa: E402
from telethon.errors import ChatWriteForbiddenError  # noqa: E402

from core.database import Database  # noqa: E402
from core.guard import install_handler_guard  # noqa: E402
from tests.test_regressions import ADMIN, OWNER, PLAIN, FakeClient, FakeEvent, _dispatch, _find  # noqa: E402
from utils.repeatspec import parse_repeat  # noqa: E402


async def _db():
    db = Database(tempfile.mktemp())
    await db.connect()
    return db


def _client(perms=ADMIN):
    c = FakeClient(perms=perms)
    c._hapoyi_me_id = 100
    return c


# ============================================================ repeat
def test_parse_repeat_forms():
    assert parse_repeat("میو 5m") == (300, "میو", None)
    assert parse_repeat("5m میو") == (300, "میو", None)
    assert parse_repeat("hello world 30s x10") == (30, "hello world", 10)
    assert parse_repeat("x3 1h hi there") == (3600, "hi there", 3)
    assert parse_repeat("Asia/Tehran") is None and parse_repeat("5m") is None and parse_repeat("") is None


def test_every_create_list_pause_delete():
    async def run():
        from modules import repeat

        db = await _db()
        c = _client()
        install_handler_guard(c)
        repeat.setup(c, db)
        ev = FakeEvent(c, ".time میو 5m", chat_id=-1001)
        assert await _dispatch(c, "every", ev)
        assert "#1" in ev.replies[0] and "5m" in ev.replies[0]
        row = await db.fetchone("SELECT chat_id,text,interval_s,remaining FROM repeat_jobs")
        assert (row["chat_id"], row["text"], row["interval_s"], row["remaining"]) == (-1001, "میو", 300, None)

        # job belongs to ITS chat: other chat sees nothing, `list all` sees it
        other = FakeEvent(c, ".every list", chat_id=-1002)
        await _dispatch(c, "every", other)
        assert "عملیاتی نیست" in other.replies[0]
        everywhere = FakeEvent(c, ".every list all", chat_id=-1002)
        await _dispatch(c, "every", everywhere)
        assert "#1" in everywhere.replies[0]
        wrong = FakeEvent(c, ".every del 1", chat_id=-1002)
        await _dispatch(c, "every", wrong)
        assert await db.fetchone("SELECT 1 FROM repeat_jobs") is not None  # cannot delete from another chat

        await _dispatch(c, "every", FakeEvent(c, ".every pause 1", chat_id=-1001))
        assert (await db.fetchone("SELECT enabled FROM repeat_jobs"))["enabled"] == 0
        await _dispatch(c, "every", FakeEvent(c, ".every resume 1", chat_id=-1001))
        assert (await db.fetchone("SELECT enabled FROM repeat_jobs"))["enabled"] == 1
        await _dispatch(c, "every", FakeEvent(c, ".every del all", chat_id=-1001))
        assert await db.fetchone("SELECT 1 FROM repeat_jobs") is None

    asyncio.run(run())


def test_plain_time_command_is_not_hijacked():
    async def run():
        from modules import personal, repeat

        db = await _db()
        c = _client()
        install_handler_guard(c)
        repeat.setup(c, db)
        personal.setup(c, db)
        tz = FakeEvent(c, ".time Asia/Tehran")
        await _dispatch(c, "every", tz)
        assert not tz.replies and await db.fetchone("SELECT 1 FROM repeat_jobs") is None
        await _dispatch(c, "time_cmd", tz)
        assert "Asia/Tehran" in tz.replies[0]
        rep = FakeEvent(c, ".time میو 5m")
        await _dispatch(c, "time_cmd", rep)
        assert not rep.replies  # personal.py steps aside for repeat specs

    asyncio.run(run())


def test_every_guards():
    async def run():
        from modules import repeat

        db = await _db()
        c = _client()
        install_handler_guard(c)
        repeat.setup(c, db)
        short = FakeEvent(c, ".every 3s hi")
        await _dispatch(c, "every", short)
        assert "حداقل" in short.replies[0]
        loop = FakeEvent(c, ".every 1m .every 1m x")
        await _dispatch(c, "every", loop)
        assert "حلقه" in loop.replies[0]
        for i in range(10):
            await _dispatch(c, "every", FakeEvent(c, f".every 1m msg{i}"))
        full = FakeEvent(c, ".every 1m one more")
        await _dispatch(c, "every", full)
        assert "سقف" in full.replies[0]

    asyncio.run(run())


def test_worker_sends_counts_down_and_handles_errors():
    async def run():
        from modules import repeat

        db = await _db()
        c = _client()
        sent = []

        async def send_message(chat, text, **kw):
            sent.append((chat, text, kw.get("reply_to")))
            return SimpleNamespace(id=1)

        c.send_message = send_message
        install_handler_guard(c)
        repeat.setup(c, db)
        now = time.time()
        await db.execute("INSERT INTO repeat_jobs(chat_id,text,interval_s,next_run,remaining,reply_to,created_at) VALUES(-1,'a',60,?,2,77,'x')", (now - 1,))
        await db.execute("INSERT INTO repeat_jobs(chat_id,text,interval_s,next_run,remaining,created_at) VALUES(-2,'b',60,?,NULL,'x')", (now - 1,))
        await asyncio.sleep(1.5)
        assert (-1, "a", 77) in sent and (-2, "b", None) in sent
        a = await db.fetchone("SELECT remaining,sent,next_run FROM repeat_jobs WHERE chat_id=-1")
        assert a["remaining"] == 1 and a["sent"] == 1 and a["next_run"] > now + 50  # no burst, next in ~60s
        await db.execute("UPDATE repeat_jobs SET next_run=? WHERE chat_id=-1", (time.time() - 1,))
        await asyncio.sleep(1.5)
        assert await db.fetchone("SELECT 1 FROM repeat_jobs WHERE chat_id=-1") is None  # finished (x2)

        async def forbidden(chat, text, **kw):
            raise ChatWriteForbiddenError(request=None)

        c.send_message = forbidden
        await db.execute("UPDATE repeat_jobs SET next_run=? WHERE chat_id=-2", (time.time() - 1,))
        await asyncio.sleep(1.5)
        row = await db.fetchone("SELECT enabled,last_error FROM repeat_jobs WHERE chat_id=-2")
        assert row["enabled"] == 0 and row["last_error"]  # permanent error -> disabled, reason kept

    asyncio.run(run())


def test_repeat_as_reply_stores_reply_target():
    async def run():
        from modules import repeat

        db = await _db()
        c = _client()
        install_handler_guard(c)
        repeat.setup(c, db)
        bob = SimpleNamespace(id=5, username="b", first_name="B", last_name=None)
        ev = FakeEvent(c, ".every 1m سلام", reply_user=bob)
        ev.message.reply_to = SimpleNamespace(reply_to_msg_id=42, forum_topic=False, reply_to_top_id=None)
        await _dispatch(c, "every", ev)
        assert (await db.fetchone("SELECT reply_to FROM repeat_jobs"))["reply_to"] == 42

    asyncio.run(run())


# ============================================================ tag
def _u(i, **kw):
    base = dict(id=i, first_name=f"U{i}", last_name=None, username=None, bot=False, deleted=False, participant=None)
    base.update(kw)
    return SimpleNamespace(**base)


def test_tag_arg_parsing():
    from modules.tagger import parse_tag_args as p

    assert p(None) == {"mode": "all", "n": 300, "text": ""}
    assert p("50")["n"] == 50 and p("999")["n"] == 300 and p("۲۰")["n"] == 20
    assert p("admin")["mode"] == "admin" and p("ادمین 10") == {"mode": "admin", "n": 10, "text": ""}
    assert p("عادی 100 سلام بچه ها") == {"mode": "normal", "n": 100, "text": "سلام بچه ها"}
    assert p("stop")["mode"] == "stop"


def test_pick_targets_rules():
    from modules.tagger import pick_targets

    admins = [_u(1), _u(2)]
    members = [_u(i) for i in range(1, 11)] + [_u(50, bot=True), _u(51, deleted=True), _u(100)]  # 100 = me
    counts = Counter({7: 90, 9: 50, 3: 10, 1: 5})
    allp = pick_targets(mode="all", n=300, me_id=100, members=members, admins=admins, counts=counts)
    ids = [u.id for u in allp]
    assert len(ids) == 10 and 100 not in ids and 50 not in ids and 51 not in ids  # small group -> everybody, no error
    assert ids[:2] == [7, 9]  # most active first
    top3 = [u.id for u in pick_targets(mode="all", n=3, me_id=100, members=members, admins=admins, counts=counts)]
    assert top3 == [7, 9, 3]
    adm = [u.id for u in pick_targets(mode="admin", n=300, me_id=100, members=members, admins=admins, counts={})]
    assert adm == [1, 2]
    norm = [u.id for u in pick_targets(mode="normal", n=300, me_id=100, members=members, admins=admins, counts=counts)]
    assert 1 not in norm and 2 not in norm and len(norm) == 8
    fill = [u.id for u in pick_targets(mode="normal", n=5, me_id=100, members=members, admins=admins, counts=counts)]
    assert fill[:3] == [7, 9, 3] and len(fill) == 5  # actives first, then filled up


def test_tag_command_sends_chunks_and_respects_rights():
    async def run():
        from modules import tagger

        tagger.PAUSE = 0
        tagger.PER_MESSAGE = 8
        db = await _db()
        c = _client(ADMIN)
        users = [_u(i) for i in range(1, 21)]
        sent = []

        async def iter_participants(chat, limit=None, filter=None):
            for u in (users[:2] if filter is not None else users):
                yield u

        async def iter_messages(chat, limit=None, **kw):
            for i in range(30):
                yield SimpleNamespace(sender_id=users[i % 5].id, sender=users[i % 5], action=None)

        async def send_message(chat, text, **kw):
            sent.append((text, kw))
            return SimpleNamespace(id=len(sent))

        c.iter_participants, c.iter_messages, c.send_message = iter_participants, iter_messages, send_message
        install_handler_guard(c)
        tagger.setup(c, db)

        ev = FakeEvent(c, ".tag 20 سلام")
        await _dispatch(c, "tag", ev)
        await asyncio.sleep(0.3)
        tags = [t for t, _ in sent if "tg://user?id=" in t]
        assert len(tags) == 3  # 20 users / 8 per message
        assert tags[0].startswith("سلام\n") and sum(t.count("tg://user?id=") for t in tags) == 20
        assert all(kw.get("parse_mode") == "md" for _, kw in sent if "tg://user" in _)
        assert ev.deleted

        # plain member -> refused, nothing sent
        sent.clear()
        c2 = _client(PLAIN)
        c2.iter_participants, c2.iter_messages, c2.send_message = iter_participants, iter_messages, send_message
        install_handler_guard(c2)
        tagger.setup(c2, db)
        denied = FakeEvent(c2, ".tag")
        await _dispatch(c2, "tag", denied)
        assert "ادمین" in denied.replies[0] and not sent

        # tag admin in a group with 2 admins and a request for 300 -> just the 2
        c3 = _client(OWNER)
        c3.iter_participants, c3.iter_messages, c3.send_message = iter_participants, iter_messages, send_message
        install_handler_guard(c3)
        tagger.setup(c3, db)
        await _dispatch(c3, "tag", FakeEvent(c3, ".تگ ادمین"))
        await asyncio.sleep(0.3)
        assert sum(t.count("tg://user?id=") for t, _ in sent if "tg://user" in t) == 2

    asyncio.run(run())


# ============================================================ extras
def _extras(perms=ADMIN, **fake):
    async def go():
        from modules import extras

        db = await _db()
        c = _client(perms)
        for k, v in fake.items():
            setattr(c, k, v)
        install_handler_guard(c)
        extras.setup(c, db)
        return db, c

    return go()


def test_later_schedules_with_telegram():
    async def run():
        got = {}

        async def send_message(chat, text, **kw):
            got.update(chat=chat, text=text, **kw)
            return SimpleNamespace(id=1)

        db, c = await _extras(send_message=send_message)
        ev = FakeEvent(c, ".later 10m سلام بعداً")
        await _dispatch(c, "later", ev)
        assert got["text"] == "سلام بعداً" and got["schedule"].total_seconds() == 600
        short = FakeEvent(c, ".later 5s x")
        await _dispatch(c, "later", short)
        assert "حداقل" in short.replies[0]

    asyncio.run(run())


def test_poll_builds_valid_telegram_object():
    async def run():
        sent = {}

        async def send_file(chat, media, **kw):
            sent["media"] = media
            return SimpleNamespace(id=1)

        db, c = await _extras(send_file=send_file)
        ev = FakeEvent(c, ".poll multi کدام بهتر است؟ | الف | ب | ج")
        await _dispatch(c, "poll", ev)
        media = sent["media"]
        assert isinstance(media, types.InputMediaPoll) and media.poll.multiple_choice
        assert [a.text.text for a in media.poll.answers] == ["الف", "ب", "ج"]
        assert bytes(media)  # serialises -> Telegram will accept the structure
        bad = FakeEvent(c, ".poll فقط سؤال | یک گزینه")
        await _dispatch(c, "poll", bad)
        assert "فرمت" in bad.replies[0]
        dup = FakeEvent(c, ".poll q | a | a")
        await _dispatch(c, "poll", dup)
        assert "تکراری" in dup.replies[0]

    asyncio.run(run())


def test_lock_unlock_keep_other_rights():
    async def run():
        calls = []

        async def call(self, req):
            calls.append(req)
            return True

        db, c = await _extras(OWNER)
        c.__class__ = type("C3", (FakeClient,), {"__call__": call})
        existing = types.ChatBannedRights(until_date=None, send_stickers=True, pin_messages=True)

        async def get_chat():
            return SimpleNamespace(default_banned_rights=existing)

        ev = FakeEvent(c, ".lock media links")
        ev.get_chat = get_chat
        await _dispatch(c, "lock", ev)
        rights = calls[-1].banned_rights
        assert rights.send_media and rights.embed_links and rights.send_stickers and rights.pin_messages and not rights.send_messages
        ev2 = FakeEvent(c, ".unlock stickers")
        ev2.get_chat = get_chat
        await _dispatch(c, "unlock", ev2)
        assert not calls[-1].banned_rights.send_stickers and calls[-1].banned_rights.pin_messages
        bad = FakeEvent(c, ".lock banana")
        bad.get_chat = get_chat
        await _dispatch(c, "lock", bad)
        assert "نامعتبر" in bad.replies[0]
        denied_db, c2 = await _extras(PLAIN)
        d = FakeEvent(c2, ".lock")
        d.get_chat = get_chat
        await _dispatch(c2, "lock", d)
        assert "دسترسی" in d.replies[0]

    asyncio.run(run())


def test_slowmode_values_and_rights():
    async def run():
        calls = []

        async def call(self, req):
            calls.append(req)
            return True

        async def get_input_entity(x):
            return types.InputPeerChannel(1, 2)

        db, c = await _extras(OWNER)
        c.__class__ = type("C4", (FakeClient,), {"__call__": call})
        c.get_input_entity = get_input_entity
        await _dispatch(c, "slowmode", FakeEvent(c, ".slowmode 30s"))
        assert calls[-1].seconds == 30
        await _dispatch(c, "slowmode", FakeEvent(c, ".slowmode off"))
        assert calls[-1].seconds == 0
        n = len(calls)
        bad = FakeEvent(c, ".slowmode 45s")
        await _dispatch(c, "slowmode", bad)
        assert len(calls) == n and "تلگرام" in bad.replies[0]

    asyncio.run(run())


def test_delall_needs_right_and_deletes_only_that_user():
    async def run():
        deleted = []
        bob = SimpleNamespace(id=555, username="bob", first_name="Bob", last_name=None)

        async def iter_messages(chat, from_user=None, limit=None, **kw):
            assert from_user.id == 555
            for mid in (11, 12, 13):
                yield SimpleNamespace(id=mid)

        async def delete_messages(chat, ids, **kw):
            deleted.extend(ids)

        db, c = await _extras(ADMIN, iter_messages=iter_messages, delete_messages=delete_messages)
        ev = FakeEvent(c, ".delall", reply_user=bob)
        await _dispatch(c, "delall", ev)
        assert {11, 12, 13} <= set(deleted) and ev.id in deleted
        db2, c2 = await _extras(PLAIN, iter_messages=iter_messages, delete_messages=delete_messages)
        deleted.clear()
        no = FakeEvent(c2, ".delall", reply_user=bob)
        await _dispatch(c2, "delall", no)
        assert "دسترسی" in no.replies[0] and not deleted

    asyncio.run(run())


def test_qr_generates_real_png_and_pass_goes_to_saved():
    async def run():
        sent = {}

        async def send_file(chat, path, **kw):
            with open(path, "rb") as fh:
                sent["png"] = fh.read(8)
            return SimpleNamespace(id=1)

        msgs = []

        async def send_message(chat, text, **kw):
            msgs.append((chat, text))
            return SimpleNamespace(id=1)

        db, c = await _extras(send_file=send_file, send_message=send_message)
        ev = FakeEvent(c, ".qr https://example.com")
        await _dispatch(c, "qr", ev)
        assert sent["png"].startswith(b"\x89PNG") and ev.deleted

        async def edit(text):
            ev2.replies.append(text)

        ev2 = FakeEvent(c, ".pass 24")
        ev2.edit = edit
        await _dispatch(c, "password", ev2)
        chat, text = msgs[-1]
        pwd = text.split("`")[1]
        assert chat == "me" and len(pwd) == 24 and any(ch.isdigit() for ch in pwd) and any(ch.isupper() for ch in pwd)
        assert "me" not in ev2.replies[0] and "Saved" in ev2.replies[0]  # the password itself never appears in the chat

    asyncio.run(run())


def test_top_and_export():
    async def run():
        files = {}

        async def iter_messages(chat, limit=None, **kw):
            sender_a = SimpleNamespace(id=1, first_name="Ali", last_name=None, username=None)
            sender_b = SimpleNamespace(id=2, first_name="Bob", last_name=None, username=None)
            for i in range(5, -1, -1):  # Telegram yields NEWEST first
                s = sender_a if i < 4 else sender_b
                yield SimpleNamespace(id=i, sender_id=s.id, sender=s, action=None, raw_text=f"msg {i}\nline2", date=datetime(2026, 10, 4, 8, i, tzinfo=timezone.utc),
                                      media=None, photo=None, sticker=None, voice=None, video_note=None, video=None, gif=None, audio=None, poll=None, document=None)

        async def send_file(chat, path, **kw):
            files["chat"] = chat
            files["text"] = open(path, encoding="utf-8").read()
            return SimpleNamespace(id=1)

        db, c = await _extras(iter_messages=iter_messages, send_file=send_file)
        ev = FakeEvent(c, ".top 5")
        await _dispatch(c, "top", ev)
        assert ev.replies[0].index("Ali") < ev.replies[0].index("Bob") and "4 پیام" in ev.replies[0]
        ex = FakeEvent(c, ".export 10")
        await _dispatch(c, "export", ex)
        assert files["chat"] == "me" and "Ali: msg 0" in files["text"] and files["text"].index("msg 0") < files["text"].index("msg 5")

    asyncio.run(run())


def test_link_public_and_private():
    async def run():
        db, c = await _extras(OWNER)
        ev = FakeEvent(c, ".link")

        async def get_chat():
            return SimpleNamespace(username="mygroup")

        ev.get_chat = get_chat
        await _dispatch(c, "link", ev)
        assert "https://t.me/mygroup" in ev.replies[0]

    asyncio.run(run())


# ============================================================ upgraded save / readall
def test_save_falls_back_to_copy_when_forwarding_is_restricted():
    async def run():
        from modules import tools

        db = await _db()
        c = _client()
        out = []

        async def send_message(chat, text, **kw):
            out.append((chat, text))
            return SimpleNamespace(id=1)

        c.send_message = send_message
        install_handler_guard(c)
        tools.setup(c, db)
        bob = SimpleNamespace(id=5, username="b", first_name="B", last_name=None)
        ev = FakeEvent(c, ".save", reply_user=bob)

        async def reply_msg():
            return SimpleNamespace(id=5, sender_id=5, noforwards=True, media=None, raw_text="محتوای محافظت‌شده", get_sender=lambda: None)

        ev.get_reply_message = reply_msg
        await _dispatch(c, "save", ev)
        assert out == [("me", "محتوای محافظت‌شده")] and "ذخیره شد" in ev.replies[0]

    asyncio.run(run())


def test_readall_all_chats():
    async def run():
        from modules import tools

        db = await _db()
        c = _client()
        acked = []

        async def iter_dialogs():
            for i, unread in enumerate((3, 0, 5)):
                yield SimpleNamespace(unread_count=unread, unread_mentions_count=0, dialog=SimpleNamespace(unread_reactions_count=0), entity=f"e{i}")

        async def ack(entity, **kw):
            acked.append(entity)

        c.iter_dialogs, c.send_read_acknowledge = iter_dialogs, ack
        install_handler_guard(c)
        tools.setup(c, db)
        ev = FakeEvent(c, ".readall all")
        await _dispatch(c, "readall", ev)
        assert acked == ["e0", "e2"] and "2" in ev.replies[0]

    asyncio.run(run())


# ============================================================ alerts on USD in Toman
def test_usd_alert_is_saved_in_toman_and_fires():
    async def run():
        import modules.alerts as alerts
        from providers.iran import Rate

        class FakeRates:
            async def usd_toman(self):
                return Rate(281_000.0, "TGJU")

            async def eur_toman(self):
                return Rate(300_000.0, "TGJU")

        alerts.shared = lambda: FakeRates()
        db = await _db()
        c = _client()
        sent = []

        async def send_message(chat, text, **kw):
            sent.append((chat, text))
            return SimpleNamespace(id=1)

        c.send_message = send_message
        install_handler_guard(c)
        alerts.setup(c, db)
        ev = FakeEvent(c, ".alert usd >= 280,000", chat_id=-1001)
        await _dispatch(c, "alert_add", ev)
        assert "USD" in ev.replies[0] and "280,000" in ev.replies[0] and "281,000" in ev.replies[0]
        row = await db.fetchone("SELECT symbol,target,chat_id FROM price_alerts")
        assert (row["symbol"], row["target"], row["chat_id"]) == ("USD", 280000.0, -1001)
        fa = FakeEvent(c, ".alert دلار >= ۲۹۰۰۰۰")
        await _dispatch(c, "alert_add", fa)
        assert (await db.fetchone("SELECT target FROM price_alerts WHERE id=2"))["target"] == 290000.0
        bad = FakeEvent(c, ".alert banana > 5")
        await _dispatch(c, "alert_add", bad)
        assert "ناشناخته" in bad.replies[0]
        await asyncio.sleep(1.0)  # background loop checks immediately
        assert any("280,000" in t or "281,000" in t for _, t in sent), sent
        assert (await db.fetchone("SELECT enabled FROM price_alerts WHERE id=1"))["enabled"] == 0  # fired once
        assert (await db.fetchone("SELECT enabled FROM price_alerts WHERE id=2"))["enabled"] == 1  # 290k not reached

    asyncio.run(run())
