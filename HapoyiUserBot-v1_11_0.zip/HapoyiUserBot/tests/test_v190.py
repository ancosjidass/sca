"""1.9.0: Echo (per-chat allowed users, anti-self-command, msginfo) and the daily helpers."""
from __future__ import annotations

import asyncio
import os
import pathlib
import sqlite3
import sys
import tempfile
import time
from types import SimpleNamespace

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from core.database import Database  # noqa: E402
from core.guard import install_handler_guard  # noqa: E402
from tests.test_regressions import ADMIN, PLAIN, FakeClient, FakeEvent, _dispatch, _find  # noqa: E402

ALI = SimpleNamespace(id=700, username="ali", first_name="Ali", last_name=None, bot=False, deleted=False)
HASAN = SimpleNamespace(id=800, username="hasan", first_name="Hasan", last_name=None)


async def _db():
    db = Database(tempfile.mktemp())
    await db.connect()
    return db


class Env:
    """Echo environment: records every send/edit/delete."""

    def __init__(self, perms):
        self.sent, self.edits = [], []
        c = FakeClient(perms=perms)
        c._hapoyi_me_id = 100
        self.c = c
        counter = {"n": 5000}

        async def send_message(chat, text, **kw):
            counter["n"] += 1
            self.sent.append((chat, text, kw))
            return SimpleNamespace(id=counter["n"])

        async def edit_message(chat, mid, text, **kw):
            self.edits.append((chat, mid, text, kw))

        c.send_message, c.edit_message = send_message, edit_message


def _echo_event(c, text, *, sender=ALI, reply_to=None, chat_id=-1001, media=None):
    ev = FakeEvent(c, text, out=False, sender_id=sender.id, chat_id=chat_id)
    ev.message.media = media
    ev.message.reply_to = SimpleNamespace(reply_to_msg_id=reply_to, forum_topic=False, reply_to_top_id=None) if reply_to else None

    async def get_sender():
        return sender

    ev.get_sender = get_sender
    return ev


async def _setup_echo(perms=ADMIN):
    from modules import echo

    from core import permissions

    permissions._perm_cache.clear()  # the 30s permission cache must not leak between tests
    echo.EDIT_DELAY = 0.05
    echo.COOLDOWN = 0.0
    env = Env(perms)
    db = await _db()
    install_handler_guard(env.c)
    echo.setup(env.c, db)
    return env, db


async def _allow(env, user=ALI, chat_id=-1001):
    ev = FakeEvent(env.c, ".echo add", reply_user=user, chat_id=chat_id)
    await _dispatch(env.c, "echo_cmd", ev)
    return ev


def test_echo_list_management_is_per_chat():
    async def run():
        env, db = await _setup_echo()
        ev = await _allow(env)
        assert "مجاز به اکو شد" in ev.replies[0]
        # other chat has its own (empty) list
        lst = FakeEvent(env.c, ".echo list", chat_id=-1002)
        await _dispatch(env.c, "echo_cmd", lst)
        assert "خالی" in lst.replies[0]
        lst_all = FakeEvent(env.c, ".echo list all", chat_id=-1002)
        await _dispatch(env.c, "echo_cmd", lst_all)
        assert "Ali" in lst_all.replies[0] and "-1001" in lst_all.replies[0]
        await _dispatch(env.c, "echo_cmd", FakeEvent(env.c, ".echo del", reply_user=ALI, chat_id=-1001))
        assert await db.fetchone("SELECT 1 FROM echo_users") is None
        await _allow(env)
        await _allow(env, chat_id=-1002)
        await _dispatch(env.c, "echo_cmd", FakeEvent(env.c, ".echo clear", chat_id=-1001))
        assert (await db.fetchone("SELECT COUNT(*) n FROM echo_users"))["n"] == 1  # only chat -1001 emptied
        await _dispatch(env.c, "echo_cmd", FakeEvent(env.c, ".echo clear allchats", chat_id=-1001))
        assert (await db.fetchone("SELECT COUNT(*) n FROM echo_users"))["n"] == 0
        # nobody else can manage the list
        stranger = FakeEvent(env.c, ".echo add", out=False, sender_id=9, reply_user=ALI)
        assert not await _dispatch(env.c, "echo_cmd", stranger)

    asyncio.run(run())


def test_allowed_user_echo_replies_to_the_replied_message_deletes_trigger_and_edits():
    async def run():
        env, db = await _setup_echo(ADMIN)
        await _allow(env)
        _, watcher = _find(env.c, "echo_watcher")
        ev = _echo_event(env.c, "اکو سلام دوستان", reply_to=321)
        await watcher(ev)
        chat, text, kw = env.sent[0]
        assert (chat, text, kw["reply_to"]) == (-1001, "سلام دوستان", 321)  # raw text first, as a reply to HASAN's message
        assert ev.deleted  # I am admin with delete right -> trigger removed
        await asyncio.sleep(0.2)
        chat, mid, edited, kw = env.edits[0]
        assert edited.startswith("اکو از ") and "tg://user?id=700" in edited and kw["parse_mode"] == "md"
        row = await db.fetchone("SELECT source_user_id,source_name,text FROM echo_messages")
        assert (row["source_user_id"], row["source_name"], row["text"]) == (700, "Ali", "سلام دوستان")

    asyncio.run(run())


def test_without_reply_plain_message_and_without_delete_right_trigger_stays():
    async def run():
        no_delete = SimpleNamespace(is_creator=False, is_admin=True, ban_users=True, delete_messages=False, pin_messages=True)
        env, db = await _setup_echo(no_delete)
        await _allow(env)
        _, watcher = _find(env.c, "echo_watcher")
        ev = _echo_event(env.c, "echo hello")
        await watcher(ev)
        assert env.sent[0][1] == "hello" and env.sent[0][2]["reply_to"] is None
        assert not ev.deleted  # no delete right -> his message stays, mine still goes out
        env2, _ = await _setup_echo(PLAIN)
        await _allow(env2)
        _, w2 = _find(env2.c, "echo_watcher")
        ev2 = _echo_event(env2.c, "اکو سلام")
        await w2(ev2)
        assert env2.sent and not ev2.deleted

    asyncio.run(run())


def test_not_on_list_text_only_and_switches():
    async def run():
        env, db = await _setup_echo()
        await _allow(env)
        _, watcher = _find(env.c, "echo_watcher")
        stranger = SimpleNamespace(id=999, username=None, first_name="X", last_name=None)
        await watcher(_echo_event(env.c, "اکو سلام", sender=stranger))
        assert not env.sent  # ignored silently: nothing sent, nothing replied
        await watcher(_echo_event(env.c, "اکو سلام", media=SimpleNamespace(photo=1)))
        assert not env.sent  # media is never echoed
        await watcher(_echo_event(env.c, "سلام بدون کلید"))
        assert not env.sent
        await _dispatch(env.c, "echo_cmd", FakeEvent(env.c, ".echo off"))
        await watcher(_echo_event(env.c, "اکو سلام"))
        assert not env.sent
        await _dispatch(env.c, "echo_cmd", FakeEvent(env.c, ".echo on"))
        await _dispatch(env.c, "echo_cmd", FakeEvent(env.c, ".echo edit off"))
        await _dispatch(env.c, "echo_cmd", FakeEvent(env.c, ".echo wipe off"))
        ev = _echo_event(env.c, "اکو سلام")
        await watcher(ev)
        await asyncio.sleep(0.2)
        assert env.sent and not env.edits and not ev.deleted

    asyncio.run(run())


def test_echoed_text_never_runs_as_my_own_command_but_my_real_commands_still_do():
    async def run():
        from modules import admin

        env, db = await _setup_echo(ADMIN)
        admin.setup(env.c, db)
        await _allow(env)
        _, watcher = _find(env.c, "echo_watcher")
        _, ban = _find(env.c, "ban")
        check = env.c._hapoyi_echo_check

        # Race: the outgoing update shows up BEFORE send_message() returned -> recognised by pending text
        fired = []
        env.c.send_message_orig = env.c.send_message

        async def racing_send(chat, text, **kw):
            out = FakeEvent(env.c, text, out=True, sender_id=100, chat_id=chat)
            out.id = 7777
            fired.append(check(out))
            return await env.c.send_message_orig(chat, text, **kw)

        env.c.send_message = racing_send
        await watcher(_echo_event(env.c, "اکو .ban"))
        assert fired == [True]

        # afterwards: recognised by message id (this is what the command guard uses)
        mid = env.sent[0][0] and (await db.fetchone("SELECT message_id FROM echo_messages"))["message_id"]
        out2 = FakeEvent(env.c, ".ban", out=True, sender_id=100, reply_user=HASAN)
        out2.id = mid
        assert check(out2) is True
        before = len(env.c.calls)
        # the guarded command handler ignores it...
        await _dispatch(env.c, "ban", out2)
        assert len(env.c.calls) == before and not out2.replies
        # ...but the SAME text typed by me is a normal command
        mine = FakeEvent(env.c, ".ban", out=True, sender_id=100, reply_user=HASAN)
        mine.id = 123456
        assert check(mine) is False
        await _dispatch(env.c, "ban", mine)
        assert len(env.c.calls) == before + 1

    asyncio.run(run())


def test_echo_registry_survives_restart():
    async def run():
        env, db = await _setup_echo()
        await _allow(env)
        _, watcher = _find(env.c, "echo_watcher")
        await watcher(_echo_event(env.c, "اکو سلام"))
        mid = (await db.fetchone("SELECT message_id FROM echo_messages"))["message_id"]
        # "restart": brand new client + module state, same database
        from modules import echo

        env2 = Env(ADMIN)
        install_handler_guard(env2.c)
        echo.setup(env2.c, db)
        _, w2 = _find(env2.c, "echo_watcher")
        await w2(_echo_event(env2.c, "اکو دوباره", sender=SimpleNamespace(id=1, username=None, first_name="Z", last_name=None)))  # triggers lazy load
        probe = FakeEvent(env2.c, ".x", out=True, chat_id=-1001)
        probe.id = mid
        assert env2.c._hapoyi_echo_check(probe) is True

    asyncio.run(run())


def test_msginfo_reports_echo_source():
    async def run():
        from modules import tools

        env, db = await _setup_echo()
        await _allow(env)
        _, watcher = _find(env.c, "echo_watcher")
        await watcher(_echo_event(env.c, "اکو میو", reply_to=5))
        mid = (await db.fetchone("SELECT message_id FROM echo_messages"))["message_id"]
        tools.setup(env.c, db)

        def info(message_id):
            ev = FakeEvent(env.c, ".msginfo", reply_user=ALI, chat_id=-1001)

            async def get_reply_message():
                return SimpleNamespace(id=message_id, sender_id=100, date="d", reply_to_msg_id=None, media=None, views=0, forwards=0)

            ev.get_reply_message = get_reply_message
            return ev

        yes = info(mid)
        await _dispatch(env.c, "msginfo", yes)
        assert "Echo: بله" in yes.replies[0] and "Ali (700)" in yes.replies[0] and "میو" in yes.replies[0]
        no = info(424242)
        await _dispatch(env.c, "msginfo", no)
        assert "Echo: خیر" in no.replies[0]

    asyncio.run(run())


# ============================================================ daily helpers
def _daily(db, **fake):
    from modules import daily

    c = FakeClient(me=100)
    c._hapoyi_me_id = 100
    for k, v in fake.items():
        setattr(c, k, v)
    install_handler_guard(c)
    daily.setup(c, db)
    return c


def test_todo_flow():
    async def run():
        db = await _db()
        c = _daily(db)
        for text in (".todo add خرید نان", ".todo add زنگ بزنم"):
            await _dispatch(c, "todo", FakeEvent(c, text))
        await _dispatch(c, "todo", FakeEvent(c, ".todo done 1"))
        lst = FakeEvent(c, ".todo")
        await _dispatch(c, "todo", lst)
        assert lst.replies[0].index("#2") < lst.replies[0].index("#1")  # open items first
        assert "✅ #1" in lst.replies[0] and "⬜ #2" in lst.replies[0]
        clr = FakeEvent(c, ".todo clear")
        await _dispatch(c, "todo", clr)
        assert "1 کار" in clr.replies[0] and (await db.fetchone("SELECT COUNT(*) n FROM todos"))["n"] == 1
        bad = FakeEvent(c, ".todo done 99")
        await _dispatch(c, "todo", bad)
        assert "پیدا نشد" in bad.replies[0]

    asyncio.run(run())


def test_conv_uses_live_rates():
    async def run():
        import modules.daily as daily
        from providers.iran import Rate

        class FakeRates:
            async def usd_toman(self):
                return Rate(280_000.0, "TGJU")

            async def eur_toman(self):
                return Rate(310_000.0, "TGJU")

        daily.shared = lambda: FakeRates()
        db = await _db()
        c = _daily(db)
        e1 = FakeEvent(c, ".conv 100 usd")
        await _dispatch(c, "conv", e1)
        assert "28,000,000 تومان" in e1.replies[0]
        e2 = FakeEvent(c, ".conv 5m toman usd")
        await _dispatch(c, "conv", e2)
        assert "5,000,000 تومان = 17.86 دلار" in e2.replies[0]
        e3 = FakeEvent(c, ".conv ۲۸۰k تومان یورو")
        await _dispatch(c, "conv", e3)
        assert "280,000 تومان = 0.9032 یورو" in e3.replies[0].replace("0.903226", "0.9032") or "0.903" in e3.replies[0]
        e4 = FakeEvent(c, ".conv 10 banana")
        await _dispatch(c, "conv", e4)
        assert "ناشناخته" in e4.replies[0]

    asyncio.run(run())


def test_parse_amount():
    from modules.daily import fmt_number, parse_amount

    assert parse_amount("280k") == 280000 and parse_amount("۲۸۰,۰۰۰") == 280000 and parse_amount("1.5m") == 1_500_000
    assert fmt_number(28000000) == "28,000,000" and fmt_number(0.5) == "0.5"


def test_copy_text_with_entities_and_backup():
    async def run():
        db = await _db()
        await db.execute("INSERT INTO todos(owner_id,text,done,created_at) VALUES(100,'persist me',0,'x')")
        out = {}

        async def send_message(chat, text, **kw):
            out["msg"] = (chat, text, kw.get("formatting_entities"))
            return SimpleNamespace(id=1)

        async def send_file(chat, path, **kw):
            conn = sqlite3.connect(path)
            out["rows"] = conn.execute("SELECT text FROM todos").fetchall()
            conn.close()
            out["file"] = (chat, kw.get("file_name"))
            return SimpleNamespace(id=2)

        c = _daily(db, send_message=send_message, send_file=send_file)
        bob = SimpleNamespace(id=5, username="b", first_name="B", last_name=None)
        ev = FakeEvent(c, ".copy me", reply_user=bob)

        async def reply_msg():
            return SimpleNamespace(id=5, media=None, raw_text="متن **ضخیم**", entities=["E"], poll=None)

        ev.get_reply_message = reply_msg
        await _dispatch(c, "copy", ev)
        assert out["msg"] == ("me", "متن **ضخیم**", ["E"]) and "کپی شد" in ev.replies[0]
        bk = FakeEvent(c, ".backup")
        await _dispatch(c, "backup", bk)
        assert out["file"][0] == "me" and out["file"][1].startswith("hapoyi_") and out["rows"] == [("persist me",)]

    asyncio.run(run())


def test_ping_reports_rtt_and_uptime():
    async def run():
        db = await _db()
        c = _daily(db)

        async def call(self, req):
            return True

        c.__class__ = type("C5", (FakeClient,), {"__call__": call})
        ev = FakeEvent(c, ".ping")
        await _dispatch(c, "ping", ev)
        assert "Pong" in ev.replies[0] and "آپتایم" in ev.replies[0] and "Telethon" in ev.replies[0]

    asyncio.run(run())
