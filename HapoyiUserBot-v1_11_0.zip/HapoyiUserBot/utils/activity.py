from __future__ import annotations

import time
from collections import Counter
from typing import Any

async def scan_activity(client, chat_id: int, limit: int = 5000, ttl: float = 120.0) -> tuple[Counter, dict[int, Any]]:
    """Count messages per sender in the last `limit` messages. Returns (Counter, {id: user entity})."""
    _cache = client.__dict__.setdefault("_hapoyi_activity_cache", {}) if hasattr(client, "__dict__") else {}
    key = (int(chat_id), int(limit))
    hit = _cache.get(key)
    if hit and time.monotonic() - hit[0] < ttl:
        return hit[1], hit[2]
    counts: Counter = Counter()
    users: dict[int, Any] = {}
    async for m in client.iter_messages(chat_id, limit=limit):
        sid = getattr(m, "sender_id", None)
        if not sid or getattr(m, "action", None):
            continue
        counts[int(sid)] += 1
        if sid not in users:
            sender = getattr(m, "sender", None)
            if sender is not None:
                users[int(sid)] = sender
    _cache[key] = (time.monotonic(), counts, users)
    if len(_cache) > 50:
        for k in sorted(_cache, key=lambda x: _cache[x][0])[:25]:
            _cache.pop(k, None)
    return counts, users


def display_name(user: Any, fallback: str = "کاربر") -> str:
    name = " ".join(x for x in (getattr(user, "first_name", None), getattr(user, "last_name", None)) if x).strip()
    return name or getattr(user, "title", None) or getattr(user, "username", None) or fallback
