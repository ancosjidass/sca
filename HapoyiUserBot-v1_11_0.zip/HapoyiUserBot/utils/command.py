from __future__ import annotations

import functools
import os
from collections.abc import Awaitable, Callable
from typing import Any

from telethon import events

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
Handler = Callable[[Any], Awaitable[Any]]


def command(pattern: str):
    compiled = rf"^{__import__('re').escape(PREFIX)}{pattern}$"
    return events.NewMessage(outgoing=True, pattern=compiled)


def public_or_outgoing(event: Any) -> bool:
    """Kept for compatibility: commands are owner-only, so only outgoing messages qualify."""
    return bool(event.out)
