from __future__ import annotations

import asyncio
import json
import shutil
from pathlib import Path

from PIL import Image

FFMPEG = shutil.which("ffmpeg")
FFPROBE = shutil.which("ffprobe")


class ConvertError(Exception):
    pass


async def _run(*cmd: str, timeout: float = 120) -> tuple[int, str]:
    proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        raise ConvertError("تبدیل بیش از حد طول کشید.")
    return proc.returncode or 0, (out or b"").decode(errors="replace")[-600:]


async def probe(path: str) -> dict:
    """{'w': int, 'h': int, 'duration': float} (best effort)."""
    if not FFPROBE:
        return {}
    code, out = await _run(FFPROBE, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height:format=duration", "-of", "json", path, timeout=30)
    if code:
        return {}
    try:
        data = json.loads(out)
        st = (data.get("streams") or [{}])[0]
        return {"w": int(st.get("width") or 0), "h": int(st.get("height") or 0), "duration": float((data.get("format") or {}).get("duration") or 0)}
    except (ValueError, KeyError, json.JSONDecodeError):
        return {}


def _even(n: int) -> int:
    return max(2, n - (n % 2))


async def image_to_gif_mp4(src: str, dst: str, seconds: int = 3, width: int = 640) -> dict:
    """Still image -> looping 'GIF' (silent mp4) with a slow zoom-in."""
    if not FFMPEG:
        raise ConvertError("ffmpeg روی سرور نصب نیست (apt install ffmpeg).")
    with Image.open(src) as im:
        w0, h0 = im.size
    w = _even(min(width, w0))
    h = _even(int(round(h0 * w / w0)))
    fps = 25
    frames = seconds * fps
    vf = (
        f"scale={w * 2}:{h * 2},"
        f"zoompan=z='min(zoom+0.0012,1.25)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={frames}:s={w}x{h}:fps={fps},"
        "format=yuv420p"
    )
    code, out = await _run(FFMPEG, "-y", "-loglevel", "error", "-i", src, "-vf", vf, "-t", str(seconds), "-an",
                           "-c:v", "libx264", "-preset", "veryfast", "-movflags", "+faststart", dst)
    if code or not Path(dst).exists():
        raise ConvertError("ساخت GIF از عکس شکست خورد: " + out.strip()[-200:])
    return {"w": w, "h": h, "duration": seconds}


async def video_to_gif_mp4(src: str, dst: str, max_seconds: int = 30, max_width: int = 720) -> dict:
    """Any video / video-note / video-sticker (webm) -> silent h264 mp4 that Telegram treats as a GIF."""
    if not FFMPEG:
        raise ConvertError("ffmpeg روی سرور نصب نیست (apt install ffmpeg).")
    vf = f"scale='min({max_width},iw)':-2,format=yuv420p"
    code, out = await _run(FFMPEG, "-y", "-loglevel", "error", "-i", src, "-t", str(max_seconds), "-vf", vf, "-an",
                           "-c:v", "libx264", "-preset", "veryfast", "-movflags", "+faststart", dst)
    if code or not Path(dst).exists():
        raise ConvertError("تبدیل ویدیو به GIF شکست خورد: " + out.strip()[-200:])
    info = await probe(dst)
    return info or {}
