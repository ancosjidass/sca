from __future__ import annotations

from typing import Any

from telethon.tl.functions.messages import SendReactionRequest
from telethon.tl.types import ReactionEmoji


async def send_reaction(client: Any, chat: Any, msg_id: int, emoji: str) -> None:
    """Telethon 1.45 has no Message.react(); use the raw MTProto request."""
    await client(SendReactionRequest(peer=chat, msg_id=int(msg_id), reaction=[ReactionEmoji(emoticon=emoji)]))


async def clear_reaction(client: Any, chat: Any, msg_id: int) -> None:
    """Remove MY reaction from one message (an empty reaction list)."""
    await client(SendReactionRequest(peer=chat, msg_id=int(msg_id), reaction=[]))
