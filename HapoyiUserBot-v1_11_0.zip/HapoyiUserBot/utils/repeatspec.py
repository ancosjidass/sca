"""Parsing of repeat specs:  `5m میو`, `میو 5m`, `30s hello x10`, `x3 1h hello`."""
from __future__ import annotations

import re

from utils.formatting import parse_duration

_FA = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
_DUR = re.compile(r"^\d+(?:\.\d+)?[smhdwSMHDW]$")
_TIMES = re.compile(r"^[xX×](\d{1,6})$")


def _norm(token: str) -> str:
    return token.translate(_FA)


def parse_repeat(args: str | None) -> tuple[int, str, int | None] | None:
    """Return (interval_seconds, text, times|None) or None when `args` is not a repeat spec.

    The interval (5m, 30s, 2h ...) may be the first OR the last word; an optional `x10` ("send 10 times")
    may sit at either end too. The text keeps its original spacing/newlines.
    """
    s = (args or "").strip()
    if not s:
        return None
    interval = times = None
    for _ in range(2):
        parts_first = s.split(None, 1)
        parts_last = s.rsplit(None, 1)
        if len(parts_first) < 2:  # a single word can never be "spec + text"
            break
        first, last = _norm(parts_first[0]), _norm(parts_last[-1])
        if interval is None and _DUR.match(first):
            interval, s = first, parts_first[1].strip()
        elif interval is None and _DUR.match(last):
            interval, s = last, parts_last[0].strip()
        elif times is None and _TIMES.match(first):
            times, s = int(_TIMES.match(first).group(1)), parts_first[1].strip()
        elif times is None and _TIMES.match(last):
            times, s = int(_TIMES.match(last).group(1)), parts_last[0].strip()
        else:
            break
    if interval is None or not s:
        return None
    try:
        seconds = parse_duration(interval)
    except ValueError:
        return None
    return seconds, s, (times if times and times > 0 else None)
