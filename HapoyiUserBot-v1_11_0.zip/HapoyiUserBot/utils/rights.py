from __future__ import annotations

from datetime import datetime, timedelta, timezone

from telethon.tl.types import ChatBannedRights

# Telegram treats an until_date closer than 30s (or further than 366d) as "forever".
MIN_RESTRICT_SECONDS = 30


def _until(seconds: int | None) -> datetime | None:
    if not seconds:
        return None
    return datetime.now(timezone.utc) + timedelta(seconds=int(seconds))


def ban_rights(seconds: int | None = None) -> ChatBannedRights:
    return ChatBannedRights(until_date=_until(seconds), view_messages=True)


def mute_rights(seconds: int | None = None) -> ChatBannedRights:
    return ChatBannedRights(
        until_date=_until(seconds),
        send_messages=True,
        send_media=True,
        send_stickers=True,
        send_gifs=True,
        send_games=True,
        send_inline=True,
        embed_links=True,
        send_polls=True,
    )


def open_rights() -> ChatBannedRights:
    """No restrictions at all (used for unban / unmute)."""
    return ChatBannedRights(until_date=None)
